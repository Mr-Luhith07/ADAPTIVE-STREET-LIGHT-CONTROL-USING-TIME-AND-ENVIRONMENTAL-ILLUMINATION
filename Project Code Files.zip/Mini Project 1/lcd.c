```c
/*
 *==============================================================================
 * File Name   : lcd.c
 * Module Name : 8-Bit LCD Driver
 * Controller  : LPC2148
 * LCD Type    : HD44780-Compatible Character LCD
 *
 * Description:
 *   This source file implements the low-level LCD driver functions required
 *   to interface an 8-bit parallel character LCD with the LPC2148
 *   microcontroller.
 *
 *   The driver provides functions to:
 *       1. Initialize the LCD in 8-bit, 2-line mode.
 *       2. Send command instructions to the LCD controller.
 *       3. Send character data to the LCD.
 *       4. Display null-terminated strings.
 *       5. Display unsigned integer values.
 *       6. Display signed integer values.
 *       7. Display floating-point values with configurable decimal places.
 *       8. Create custom characters using LCD CGRAM.
 *
 * HARDWARE CONNECTIONS:
 *
 *   LCD DATA BUS:
 *       LCD D0-D7 -> LPC2148 P0.8-P0.15
 *
 *   LCD CONTROL SIGNALS:
 *       RS -> P0.4
 *       EN -> P0.17
 *       RW -> P0.18
 *
 * LCD CONTROL SIGNAL DESCRIPTION:
 *
 *   RS (Register Select):
 *       RS = 0 -> Command register selected.
 *       RS = 1 -> Data register selected.
 *
 *   RW (Read/Write):
 *       RW = 0 -> Write operation.
 *       RW = 1 -> Read operation.
 *
 *   EN (Enable):
 *       An enable pulse is used to latch the command or data
 *       presented on the LCD data bus.
 *
 * DATA TRANSFER:
 *   The LCD operates in 8-bit mode.
 *   All eight data bits are transferred simultaneously through P0.8-P0.15.
 *
 * DEPENDENCIES:
 *   LPC214x.h     -> LPC2148 hardware register definitions.
 *   types.h       -> Project-specific data type definitions.
 *   lcd.h         -> LCD driver function declarations.
 *   lcd_defines.h -> LCD pin positions and command definitions.
 *   delay.h       -> Software delay function declarations.
 *
 *==============================================================================
 */


/*------------------------------------------------------------------------------
 * HEADER FILE INCLUSIONS
 *------------------------------------------------------------------------------*/

#include <LPC214x.h>       // Provides LPC2148 hardware register definitions.
                           // GPIO registers used in this driver include:
                           // IODIR0, IOCLR0 and IOSET0.

#include "types.h"         // Provides project-specific data types such as:
                           // u8  -> Unsigned 8-bit integer.
                           // u32 -> Unsigned 32-bit integer.
                           // s8  -> Signed 8-bit integer.
                           // s32 -> Signed 32-bit integer.
                           // f32 -> Floating-point data type.

#include "lcd.h"           // Contains the public function declarations
                           // implemented by this LCD driver.

#include "lcd_defines.h"   // Contains LCD hardware pin definitions and
                           // HD44780 command macros such as:
                           // LCD_DATA, LCD_RS, LCD_RW, LCD_EN,
                           // MODE_8BIT_2LINE, DSP_ON_CUR_OFF,
                           // CLEAR_LCD and other LCD commands.

#include "delay.h"         // Provides delay_us() and delay_ms() functions.
                           // These delays are used to satisfy LCD timing
                           // requirements during command and data transfers.


/*------------------------------------------------------------------------------
 * FUNCTION NAME : WriteLCD
 *
 * DESCRIPTION:
 *   Transfers one 8-bit command or data byte to the LCD through the
 *   parallel data bus.
 *
 * PARAMETERS:
 *   dat:
 *       8-bit value to be transferred to the LCD.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Clears the previous data present on P0.8-P0.15.
 *   2. Places the new 8-bit value on the LCD data bus.
 *   3. Configures RW = 0 to select write operation.
 *   4. Generates an enable pulse to latch the byte into the LCD.
 *   5. Waits for the LCD operation to complete.
 *
 * IMPORTANT:
 *   This is a low-level data-transfer function.
 *   The RS signal must be configured by the calling function before
 *   WriteLCD() is executed.
 *
 *   RS = 0 -> The transmitted byte is interpreted as a command.
 *   RS = 1 -> The transmitted byte is interpreted as display data.
 *------------------------------------------------------------------------------*/

void WriteLCD(u8 dat)
{
    /* Clear all eight LCD data-bus bits.
       LCD_DATA represents the starting GPIO bit position P0.8.
       0xFFU selects eight consecutive bits.
       Shifting the mask by LCD_DATA positions it over P0.8-P0.15.

       IOCLR0 writes HIGH values to the selected register bits,
       causing the corresponding GPIO output pins to become LOW. */
    IOCLR0 = (0xFFU << LCD_DATA);

    /* Place the new 8-bit data value on the LCD data bus.
       The input byte is shifted to the P0.8-P0.15 positions.
       Casting dat to u32 ensures the shift operation is performed
       using an unsigned 32-bit value.

       IOSET0 sets the selected GPIO output pins HIGH.
       Bits containing zero remain LOW from the previous clear operation. */
    IOSET0 = ((u32)dat << LCD_DATA);

    /* Configure RW = 0.
       LOW on the RW pin selects the LCD write operation.
       The microcontroller sends data or commands to the LCD. */
    IOCLR0 = (1U << LCD_RW);

    /* Drive the EN pin HIGH.
       This begins the enable pulse used to latch the data or command
       currently present on the LCD data bus. */
    IOSET0 = (1U << LCD_EN);

    /* Maintain the enable signal HIGH for approximately 1 microsecond.
       The delay provides a pulse width for the LCD enable signal. */
    delay_us(1U);

    /* Drive EN LOW to complete the enable pulse.
       The LCD latches the transmitted byte according to its interface timing. */
    IOCLR0 = (1U << LCD_EN);

    /* Wait for the LCD controller to complete the operation.
       This fixed delay is used instead of reading the LCD busy flag. */
    delay_ms(2U);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : CmdLCD
 *
 * DESCRIPTION:
 *   Sends an instruction or command byte to the LCD controller.
 *
 * PARAMETERS:
 *   cmd:
 *       8-bit LCD instruction command.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Drives RS LOW to select the instruction register.
 *   2. Calls WriteLCD() to transfer the command byte.
 *
 * EXAMPLES:
 *   CLEAR_LCD          -> Clears the LCD display.
 *   MODE_8BIT_2LINE    -> Selects 8-bit, 2-line interface mode.
 *   DSP_ON_CUR_OFF     -> Enables display and disables cursor.
 *   SHIFT_CUR_RIGHT    -> Moves the cursor position to the right.
 *
 *------------------------------------------------------------------------------*/

void CmdLCD(u8 cmd)
{
    /* Drive RS LOW.
       RS = 0 selects the LCD instruction/command register.
       The next byte transferred by WriteLCD() is interpreted
       as an LCD command rather than display data. */
    IOCLR0 = (1U << LCD_RS);

    /* Transfer the command byte to the LCD using the common
       8-bit data-transfer function. */
    WriteLCD(cmd);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : CharLCD
 *
 * DESCRIPTION:
 *   Sends one ASCII character to the LCD for display.
 *
 * PARAMETERS:
 *   asciiVal:
 *       ASCII value of the character to be displayed.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Drives RS HIGH to select the LCD data register.
 *   2. Calls WriteLCD() to transfer the ASCII character.
 *   3. The LCD interprets the received byte as character data and
 *      displays the corresponding character at the current cursor position.
 *
 * EXAMPLE:
 *   CharLCD('A');
 *
 *   The ASCII value corresponding to character 'A' is transmitted
 *   to the LCD data register.
 *------------------------------------------------------------------------------*/

void CharLCD(u8 asciiVal)
{
    /* Drive RS HIGH.
       RS = 1 selects the LCD data register.
       The next byte transferred by WriteLCD() is interpreted
       as character data to be displayed. */
    IOSET0 = (1U << LCD_RS);

    /* Transfer the ASCII character value to the LCD data bus. */
    WriteLCD(asciiVal);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : InitLCD
 *
 * DESCRIPTION:
 *   Initializes the LCD hardware and configures the HD44780-compatible
 *   controller for 8-bit, 2-line display operation.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   void
 *
 * INITIALIZATION SEQUENCE:
 *   1. Configure LCD data and control pins as GPIO outputs.
 *   2. Wait for LCD power-on initialization.
 *   3. Send the initial 8-bit interface initialization commands.
 *   4. Configure the LCD for 8-bit and 2-line operation.
 *   5. Enable the display and disable the cursor.
 *   6. Clear the display.
 *   7. Set the cursor movement direction to the right.
 *
 * IMPORTANT:
 *   The initialization delays are required because the LCD controller
 *   needs time to become ready after power-up and between certain commands.
 *------------------------------------------------------------------------------*/

void InitLCD(void)
{
    /* Configure all LCD data and control pins as GPIO outputs.

       Data bus:
           (0xFFU << LCD_DATA) selects P0.8-P0.15.

       Control pins:
           (1U << LCD_RS) selects the RS pin.
           (1U << LCD_RW) selects the RW pin.
           (1U << LCD_EN) selects the EN pin.

       In the LPC2148 IODIR0 register:
           Bit = 1 -> GPIO output.
           Bit = 0 -> GPIO input. */
    IODIR0 |= (0xFFU << LCD_DATA) |
              (1U << LCD_RS) |
              (1U << LCD_RW) |
              (1U << LCD_EN);

    /* Wait 20 milliseconds after configuring the GPIO pins.
       This provides time for the LCD power-on sequence to stabilize. */
    delay_ms(20U);

    /* Send the initial 0x30 instruction.
       This is part of the HD44780 8-bit interface initialization
       sequence and establishes the 8-bit communication mode. */
    CmdLCD(0x30);

    /* Wait 5 milliseconds before sending the next initialization instruction.
       This satisfies the required power-on initialization timing. */
    delay_ms(5U);

    /* Send the 0x30 initialization instruction again.
       Repetition helps ensure that the LCD controller recognizes
       the required 8-bit interface mode. */
    CmdLCD(0x30);

    /* Wait approximately 150 microseconds before the next instruction.
       This provides the required settling time between initialization steps. */
    delay_us(150U);

    /* Send the third 0x30 initialization instruction.
       This completes the repeated 8-bit interface initialization sequence. */
    CmdLCD(0x30);

    /* Configure the LCD for 8-bit data transfer and two-line display mode.
       The exact instruction value is defined by MODE_8BIT_2LINE
       in lcd_defines.h. */
    CmdLCD(MODE_8BIT_2LINE);

    /* Enable the LCD display and disable the cursor.
       The actual instruction value is defined by DSP_ON_CUR_OFF. */
    CmdLCD(DSP_ON_CUR_OFF);

    /* Clear all displayed characters and return the cursor to the
       home position according to the LCD clear-display instruction. */
    CmdLCD(CLEAR_LCD);

    /* Configure cursor movement to the right after each character write.
       The actual instruction value is defined by SHIFT_CUR_RIGHT. */
    CmdLCD(SHIFT_CUR_RIGHT);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : StrLCD
 *
 * DESCRIPTION:
 *   Displays a null-terminated character string on the LCD.
 *
 * PARAMETERS:
 *   s:
 *       Pointer to the first character of the string to be displayed.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Reads the character pointed to by s.
 *   2. Checks whether the character is the null terminator '\0'.
 *   3. If it is not null, sends the character to the LCD.
 *   4. Increments the pointer to access the next character.
 *   5. Repeats until the null terminator is encountered.
 *
 * EXAMPLE:
 *   StrLCD("VECTOR");
 *
 *   Characters V, E, C, T, O and R are transmitted sequentially.
 *
 * IMPORTANT:
 *   The input string must be null-terminated and point to valid memory.
 *------------------------------------------------------------------------------*/

void StrLCD(s8 *s)
{
    /* Continue transmitting characters until the null terminator is found.
       In C, a null-terminated string ends with '\0', whose value is zero. */
    while(*s)

        /* Convert the current signed character to u8 and send it to the LCD.
           The post-increment operator advances the pointer to the next
           character after the current character has been accessed. */
        CharLCD((u8)*s++);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : U32LCD
 *
 * DESCRIPTION:
 *   Converts an unsigned 32-bit integer into decimal ASCII characters
 *   and displays the resulting number on the LCD.
 *
 * PARAMETERS:
 *   n:
 *       Unsigned 32-bit integer to be displayed.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Handles zero as a special case.
 *   2. Extracts decimal digits using the modulus operator.
 *   3. Converts each extracted digit into its ASCII representation.
 *   4. Stores the extracted digits in a temporary array.
 *   5. Displays the digits in reverse extraction order.
 *
 * WHY REVERSE ORDER IS REQUIRED:
 *   The modulus operation extracts digits from right to left.
 *   The LCD must display the digits from left to right.
 *
 * EXAMPLE:
 *   n = 1234
 *
 *   Extracted digits:
 *       4, 3, 2, 1
 *
 *   Stored array:
 *       digits[0] = '4'
 *       digits[1] = '3'
 *       digits[2] = '2'
 *       digits[3] = '1'
 *
 *   Display order:
 *       1, 2, 3, 4
 *
 *------------------------------------------------------------------------------*/

void U32LCD(u32 n)
{
    /* Temporary array used to store the ASCII representation of
       the decimal digits extracted from the unsigned integer.

       Ten elements are sufficient for the maximum 10 decimal digits
       of a 32-bit unsigned integer. */
    u8 digits[10];

    /* Index variable used to track the number of extracted digits
       and the next available array position. */
    s32 i = 0;

    /* Handle zero separately.
       If n is zero, the digit-extraction loop below will not execute.
       Therefore, display character '0' directly and return. */
    if(n == 0U)
    {
        /* Display ASCII character '0' on the LCD. */
        CharLCD('0');

        /* Exit the function because the complete value has been displayed. */
        return;
    }

    /* Extract decimal digits one by one while the number is greater than zero.
       The condition i < 10 ensures that the temporary array is not exceeded. */
    while(n > 0U && i < 10)
    {
        /* Extract the least significant decimal digit using modulo 10.
           Add ASCII value '0' to convert the numeric digit into a character.

           Example:
               123 % 10 = 3
               3 + '0' = '3'

           Store the resulting ASCII character in the temporary array
           and increment the array index. */
        digits[i++] = (u8)((n % 10U) + '0');

        /* Remove the least significant decimal digit using integer division.
           Example:
               123 / 10 = 12
                12 / 10 = 1
                 1 / 10 = 0 */
        n /= 10U;
    }

    /* Display the stored digits in reverse array order.
       Since digits were extracted from right to left, decrementing i
       displays them in the correct left-to-right decimal order.

       Example:
           Stored: 4, 3, 2, 1
           Displayed: 1, 2, 3, 4 */
    while(--i >= 0)

        /* Send the current stored ASCII digit to the LCD. */
        CharLCD(digits[i]);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : S32LCD
 *
 * DESCRIPTION:
 *   Displays a signed 32-bit integer on the LCD.
 *
 * PARAMETERS:
 *   n:
 *       Signed 32-bit integer to be displayed.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Checks whether the input number is negative.
 *   2. Displays the minus sign if the number is negative.
 *   3. Converts the negative value into a positive value.
 *   4. Calls U32LCD() to display the numeric digits.
 *
 * EXAMPLES:
 *   S32LCD(123)  -> Displays 123.
 *   S32LCD(-123) -> Displays -123.
 *
 * IMPORTANT:
 *   Negating the minimum signed 32-bit value can cause signed integer
 *   overflow because +2147483648 cannot be represented by s32.
 *   This implementation does not specially handle that boundary value.
 *------------------------------------------------------------------------------*/

void S32LCD(s32 n)
{
    /* Check whether the signed integer is negative. */
    if(n < 0)
    {
        /* Display the minus sign before displaying the numeric digits. */
        CharLCD('-');

        /* Convert the negative number into a positive number.
           This allows the unsigned integer display function to handle
           the remaining decimal digits. */
        n = -n;
    }

    /* Convert the signed integer to u32 and display its decimal digits.
       For a negative input, the minus sign has already been displayed. */
    U32LCD((u32)n);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : F32LCD
 *
 * DESCRIPTION:
 *   Displays a floating-point number on the LCD with a configurable
 *   number of decimal places.
 *
 * PARAMETERS:
 *   value:
 *       Floating-point value to be displayed.
 *
 *   nDP:
 *       Number of decimal digits to display after the decimal point.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Checks whether the floating-point value is negative.
 *   2. Displays the minus sign if required.
 *   3. Extracts the integer portion of the value.
 *   4. Displays the integer portion using U32LCD().
 *   5. Displays the decimal point.
 *   6. Extracts the requested number of fractional digits.
 *   7. Converts each fractional digit into an ASCII character.
 *
 * EXAMPLE:
 *   F32LCD(12.345F, 2);
 *
 *   Integer portion:
 *       12
 *
 *   Fractional extraction:
 *       0.345 * 10 = 3.45 -> digit 3
 *       0.45  * 10 = 4.5  -> digit 4
 *
 *   Displayed result:
 *       12.34
 *
 * IMPORTANT:
 *   This function truncates the fractional value rather than rounding it.
 *   Floating-point representation errors can affect the last displayed digit.
 *------------------------------------------------------------------------------*/

void F32LCD(f32 value, u8 nDP)
{
    /* Stores the integer portion of the floating-point value
       and is also reused to store each extracted fractional digit. */
    u32 whole;

    /* Loop counter used to generate the requested number of
       digits after the decimal point. */
    u8 i;

    /* Check whether the floating-point input is negative. */
    if(value < 0.0F)
    {
        /* Display the negative sign before the numeric value. */
        CharLCD('-');

        /* Convert the negative floating-point value to positive
           so that integer and fractional extraction can proceed. */
        value = -value;
    }

    /* Extract the integer portion by converting the floating-point
       value to an unsigned integer.
       The fractional part is discarded during this conversion. */
    whole = (u32)value;

    /* Display the integer portion before the decimal point. */
    U32LCD(whole);

    /* Display the decimal point separating integer and fractional parts. */
    CharLCD('.');

    /* Remove the integer portion from the original floating-point value.
       The remaining value contains only the fractional portion. */
    value -= (f32)whole;

    /* Extract and display the requested number of decimal digits. */
    for(i = 0; i < nDP; i++)
    {
        /* Multiply the fractional portion by 10.
           This shifts the next decimal digit into the integer position. */
        value *= 10.0F;

        /* Extract the integer portion.
           This represents the next decimal digit to be displayed. */
        whole = (u32)value;

        /* Convert the extracted digit into its ASCII character
           by adding the ASCII value of '0', then display it. */
        CharLCD((u8)(whole + '0'));

        /* Remove the extracted integer digit from the floating-point value.
           The remaining value contains the fractional portion for
           the next decimal digit extraction. */
        value -= (f32)whole;
    }
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : BuildCGRAM
 *
 * DESCRIPTION:
 *   Programs custom character patterns into the LCD Character Generator
 *   RAM (CGRAM).
 *
 * PARAMETERS:
 *
 *   p:
 *       Pointer to the array containing the custom character pattern bytes.
 *
 *   nBytes:
 *       Number of pattern bytes to be transferred to CGRAM.
 *
 * RETURN TYPE:
 *   void
 *
 * WORKING:
 *   1. Sends the CGRAM address command to the LCD.
 *   2. Selects the LCD data register by setting RS HIGH.
 *   3. Transfers the pattern bytes sequentially to CGRAM.
 *   4. Returns the LCD cursor address to the beginning of the first line.
 *
 * CGRAM CONCEPT:
 *   CGRAM stands for Character Generator RAM.
 *   It stores user-defined character patterns that can be displayed
 *   instead of the standard built-in character set.
 *
 *   In a typical HD44780-compatible 5x8 character configuration:
 *       - Each custom character uses 8 pattern bytes.
 *       - Each byte represents one horizontal row of the character.
 *       - The lower five bits represent the five visible pixels.
 *       - The upper bits are not used for the 5x8 pattern.
 *
 * IMPORTANT:
 *   The number of bytes, pointer validity and CGRAM address must be
 *   consistent with the intended custom-character layout.
 *------------------------------------------------------------------------------*/

void BuildCGRAM(u8 *p, u8 nBytes)
{
    /* Loop counter used to track the number of pattern bytes
       transferred into the LCD CGRAM. */
    u8 i;

    /* Send the CGRAM starting-address instruction.
       This selects the LCD Character Generator RAM address space.
       The starting address is defined by GOTO_CGRAM_START in lcd_defines.h. */
    CmdLCD(GOTO_CGRAM_START);

    /* Set RS HIGH to select the LCD data register.
       The following bytes are treated as CGRAM pattern data rather
       than LCD command instructions. */
    IOSET0 = (1U << LCD_RS);

    /* Transfer the specified number of pattern bytes to CGRAM.
       The pointer p accesses each pattern byte sequentially.
       The loop terminates after nBytes have been transferred. */
    for(i = 0; i < nBytes; i++)

        /* Send the current custom-character pattern byte to the LCD.
           WriteLCD() transfers the byte through the 8-bit data bus. */
        WriteLCD(p[i]);

    /* Select the beginning of the first display line.
       This changes the LCD address counter from CGRAM addressing
       back to the display data RAM (DDRAM) position. */
    CmdLCD(GOTO_LINE1_POS0);
}


/*
 *==============================================================================
 * END OF FILE : lcd.c
 *
 * MODULE FUNCTION SUMMARY:
 *
 *   WriteLCD()   -> Transfers one 8-bit byte to the LCD.
 *   CmdLCD()     -> Sends an instruction command.
 *   CharLCD()    -> Displays one ASCII character.
 *   InitLCD()    -> Initializes the LCD in 8-bit, 2-line mode.
 *   StrLCD()     -> Displays a null-terminated string.
 *   U32LCD()     -> Displays an unsigned 32-bit integer.
 *   S32LCD()     -> Displays a signed 32-bit integer.
 *   F32LCD()     -> Displays a floating-point value.
 *   BuildCGRAM() -> Programs custom character patterns into CGRAM.
 *
 *==============================================================================
 */
```