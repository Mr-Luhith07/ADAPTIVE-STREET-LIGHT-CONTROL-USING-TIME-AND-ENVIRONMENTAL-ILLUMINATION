```c
/***************************************************************
 * FILE NAME   : RTC.C
 * PROJECT     : ADAPTIVE STREET LIGHT CONTROL SYSTEM
 * MCU         : LPC2148
 *
 * MODULE      : REAL TIME CLOCK (RTC) DRIVER
 *
 * DESCRIPTION :
 * This module provides the low-level and application-level
 * functions required to configure and operate the internal
 * Real Time Clock peripheral of the LPC2148 microcontroller.
 *
 * The RTC maintains calendar information independently of
 * the normal application execution flow.
 *
 * This module provides the following functionalities:
 *
 * 1. RTC peripheral initialization.
 * 2. Setting and reading time (hours, minutes and seconds).
 * 3. Setting and reading date (date, month and year).
 * 4. Setting and reading the day of the week.
 * 5. Leap-year detection.
 * 6. Calculating the number of days in a given month.
 * 7. Displaying time, date and weekday information on LCD.
 *
 * CLOCK CONFIGURATION:
 * External crystal frequency : 12 MHz
 * CPU clock frequency        : 60 MHz
 * Peripheral clock frequency : 15 MHz
 * RTC reference frequency    : 32.768 kHz
 *
 * The RTC prescaler values are obtained from project_config.h.
 *
 * NOTE:
 * This driver uses LPC214x-specific RTC registers.
 ***************************************************************/


/***************************************************************
 * HEADER FILE INCLUSIONS
 ***************************************************************/

#include <LPC214x.h>
/* Includes the LPC214x device-specific register definitions.
   Provides access to RTC registers such as:
       CCR      - Clock Control Register
       PREINT   - Prescaler Integer Register
       PREFRAC  - Prescaler Fraction Register
       SEC      - Seconds Register
       MIN      - Minutes Register
       HOUR     - Hours Register
       DOM      - Day of Month Register
       MONTH    - Month Register
       YEAR     - Year Register
       DOW      - Day of Week Register

   These register names allow the application to directly
   configure and access the internal RTC hardware. */


#include "types.h"
/* Includes project-defined data type declarations.

   Common project data types:
       u8  - 8-bit unsigned integer
       u16 - 16-bit unsigned integer
       u32 - 32-bit unsigned integer

   Using these types improves readability and makes the
   intended data widths clear throughout the driver. */


#include "project_config.h"
/* Includes centralized hardware configuration parameters.

   This file provides:
       PREINT_VAL - RTC integer prescaler value
       PREFRAC_VAL - RTC fractional prescaler value
       FOSC, CCLK and PCLK - clock frequency definitions
       RTC_RST and RTC_ENB - RTC control bit definitions

   Centralized configuration avoids hardcoding hardware
   parameters in multiple source files. */


#include "rtc.h"
/* Includes the RTC module's public function declarations.

   This ensures that the function definitions in this source
   file match the function prototypes exposed through rtc.h. */


#include "lcd.h"
/* Includes the LCD driver function declarations.

   RTC display functions use:
       CmdLCD()  - sends commands to the LCD
       CharLCD() - displays an individual character
       StrLCD()  - displays a string
       U32LCD()  - displays an unsigned integer

   This allows the RTC module to display calendar information
   without directly handling the LCD hardware registers. */


#include "lcd_defines.h"
/* Includes LCD command and cursor-position macros.

   Example:
       GOTO_LINE1_POS0 - selects the first LCD line, position 0
       GOTO_LINE2_POS0 - selects the second LCD line, position 0

   These macros make LCD cursor positioning readable. */


/***************************************************************
 * FUNCTION NAME : RTC_Init
 *
 * DESCRIPTION   :
 * Initializes the internal RTC peripheral of the LPC2148.
 *
 * The function selects the RTC clock source, configures the
 * integer and fractional prescaler values, and enables RTC
 * counting.
 *
 * CLOCK SOURCE:
 * The RTC clock source is selected using bit 4 of the CCR
 * (Clock Control Register).
 *
 * PRESCALER:
 * PREINT and PREFRAC are configured to generate the required
 * RTC timekeeping frequency from the selected clock source.
 *
 * PARAMETERS    : None.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_Init(void)
{
    // CCR = RTC_RST;
    /* Alternative RTC reset operation.
       RTC_RST is defined as (1U << 1), which sets bit 1
       of the RTC Clock Control Register.

       Bit 1 = CTCRST (Counter Reset).

       When this bit is set, the RTC counters are reset.
       The bit must be cleared to allow normal counting.

       IMPORTANT:
       This statement is commented out, so the RTC counter
       reset operation is not performed by this function. */


    CCR = 1 << 4;
    /* Configures the RTC clock source through CCR bit 4.

       Bit 4 = CLKSRC (Clock Source Selection).

       Setting bit 4 to 1 selects PCLK as the RTC clock source
       on the LPC214x RTC peripheral.

       Binary value:
           0001 0000

       Hexadecimal value:
           0x10

       Bit 0 (CLKEN) is 0 in this assignment, so RTC counting
       is disabled while the prescaler is configured.

       This assignment does not reset the RTC counters. */


    PREINT = PREINT_VAL;
    /* Loads the integer portion of the RTC prescaler.

       PREINT_VAL is calculated in project_config.h.

       For PCLK = 15 MHz:

           PREINT = (15000000 / 32768) - 1

           PREINT = 456

       The integer prescaler contributes to deriving the
       required RTC timing frequency.

       PREINT is a hardware register of the RTC peripheral. */


    PREFRAC = PREFRAC_VAL;
    /* Loads the fractional portion of the RTC prescaler.

       PREFRAC_VAL is calculated in project_config.h.

       For PCLK = 15 MHz and PREINT = 456:

           PREFRAC = 15000000 - (457 * 32768)

           PREFRAC = 25024

       The fractional prescaler compensates for the remaining
       difference between the peripheral clock and the
       required RTC timekeeping frequency.

       Together, PREINT and PREFRAC configure the RTC
       prescaler for the selected clock source. */


    // CCR = RTC_ENB;
    /* Alternative RTC enable operation.

       RTC_ENB is defined as (1U << 0).

       Bit 0 = CLKEN (Clock Enable).

       Setting this bit to 1 enables RTC counting.

       This statement is commented out because the next
       assignment enables the RTC and selects its clock source
       together. */


    // CCR = 0x11;
    /* Alternative hexadecimal representation of the value
       used in the following assignment.

       0x11 = 0001 0001 (binary).

       Bit 4 = 1 : Selects PCLK as the RTC clock source.
       Bit 0 = 1 : Enables RTC counting.

       This statement is commented out because the next
       statement performs the same register assignment. */


    CCR = 1 << 0 | 1 << 4;
    /* Enables the RTC and selects PCLK as its clock source.

       Expression:
           (1 << 0) | (1 << 4)

       Binary representation:
           0000 0001
         | 0001 0000
         -------------
           0001 0001

       Hexadecimal representation:
           0x11

       Bit 0 = CLKEN = 1:
           Enables RTC counting.

       Bit 4 = CLKSRC = 1:
           Selects PCLK as the RTC clock source.

       After this assignment, the RTC is enabled with the
       configured prescaler values.

       NOTE:
       The expression is equivalent to CCR = 0x11.
       Parentheses may improve readability, but the current
       expression is valid because shift operators have higher
       precedence than the bitwise OR operator. */


    /*
    if((CCR & 0x01)==0)
    {
        CCR=1<<1;
        CCR=1<<0 | 1<<4;
    }
    else
        CCR=1<<4;
    */

    /* Alternative conditional RTC initialization logic.

       (CCR & 0x01) checks whether bit 0 of CCR is set.

       If bit 0 is clear:
           The RTC is currently disabled.
           CCR = 1 << 1 requests a counter reset.
           The next assignment enables the RTC and selects PCLK.

       Otherwise:
           CCR = 1 << 4 selects PCLK and disables the RTC.

       This entire block is commented out and is not executed.

       IMPORTANT:
       The active RTC_Init() implementation above does not
       perform this conditional check or explicitly reset
       the RTC counters. */
}


/***************************************************************
 * FUNCTION NAME : RTC_SetTime
 *
 * DESCRIPTION   :
 * Writes the user-provided time values into the RTC hardware
 * registers.
 *
 * The RTC maintains time using three separate registers:
 * HOUR, MIN and SEC.
 *
 * PARAMETERS:
 * h - Hour value (valid range: 0 to 23).
 * m - Minute value (valid range: 0 to 59).
 * s - Second value (valid range: 0 to 59).
 *
 * RETURN VALUE  : None.
 *
 * NOTE:
 * This function directly writes the supplied values.
 * Input validation must be performed by the calling application.
 ***************************************************************/

void RTC_SetTime(u32 h, u32 m, u32 s)
{
    HOUR = h;
    /* Writes the supplied hour value into the RTC HOUR register.
       The normal 24-hour format range is 0 to 23. */

    MIN = m;
    /* Writes the supplied minute value into the RTC MIN register.
       The valid minute range is 0 to 59. */

    SEC = s;
    /* Writes the supplied second value into the RTC SEC register.
       The valid second range is 0 to 59. */
}


/***************************************************************
 * FUNCTION NAME : RTC_SetDate
 *
 * DESCRIPTION   :
 * Writes the calendar date information into the RTC registers.
 *
 * PARAMETERS:
 * d - Day of the month (1 to 31, depending on the month).
 * m - Month value (1 to 12).
 * y - Year value supported by the RTC calendar register.
 *
 * RETURN VALUE  : None.
 *
 * NOTE:
 * The function does not check whether the supplied date is
 * valid for the selected month and year.
 ***************************************************************/

void RTC_SetDate(u32 d, u32 m, u32 y)
{
    DOM = d;
    /* Writes the day of the month into the DOM register.

       Example:
           DOM = 25

       Represents the 25th day of the current month. */


    MONTH = m;
    /* Writes the month value into the MONTH register.

       Example:
           MONTH = 11

       Represents November.

       The expected month range is 1 to 12. */


    YEAR = y;
    /* Writes the year value into the YEAR register.

       Example:
           YEAR = 2026

       Represents the year 2026.

       Date validation should be completed before calling
       this function. */
}


/***************************************************************
 * FUNCTION NAME : RTC_SetDay
 *
 * DESCRIPTION   :
 * Writes the day-of-week value into the RTC DOW register.
 *
 * DAY MAPPING:
 *     0 - Sunday
 *     1 - Monday
 *     2 - Tuesday
 *     3 - Wednesday
 *     4 - Thursday
 *     5 - Friday
 *     6 - Saturday
 *
 * PARAMETERS:
 * day - Day-of-week value from 0 to 6.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_SetDay(u32 day)
{
    DOW = day;
    /* Writes the supplied weekday number into the RTC
       Day of Week register.

       The application uses the 0-to-6 weekday convention.

       IMPORTANT:
       This function does not calculate the weekday from
       the date. The application must provide the correct
       weekday value separately. */
}


/***************************************************************
 * FUNCTION NAME : RTC_GetTime
 *
 * DESCRIPTION   :
 * Reads the current time from the RTC hardware registers
 * and returns the values through pointer arguments.
 *
 * PARAMETERS:
 * h - Pointer to the variable that receives the hour.
 * m - Pointer to the variable that receives the minute.
 * s - Pointer to the variable that receives the second.
 *
 * RETURN VALUE  : None.
 *
 * POINTER CONCEPT:
 * The function receives addresses of variables rather than
 * ordinary variable values.
 *
 * Using pointers allows this function to update multiple
 * caller-owned variables.
 ***************************************************************/

void RTC_GetTime(u32 *h, u32 *m, u32 *s)
{
    *h = HOUR;
    /* Reads the RTC HOUR register and stores its value in the
       memory location pointed to by h.

       *h means the value stored at the address contained in h. */


    *m = MIN;
    /* Reads the RTC MIN register and stores its value in the
       memory location pointed to by m. */


    *s = SEC;
    /* Reads the RTC SEC register and stores its value in the
       memory location pointed to by s.

       Example:
           u32 hr, min, sec;
           RTC_GetTime(&hr, &min, &sec);

       The address-of operator (&) passes the addresses of
       the three variables to this function.

       The function then updates those variables through
       the pointer dereferencing operator (*).

       NOTE:
       The caller must provide valid, non-NULL pointers.
       The three registers are read separately, so a second
       rollover during the reads can produce a mixed snapshot. */
}


/***************************************************************
 * FUNCTION NAME : RTC_GetDate
 *
 * DESCRIPTION   :
 * Reads the current calendar date from the RTC hardware
 * registers and returns the values through pointer arguments.
 *
 * PARAMETERS:
 * d - Pointer to the variable that receives the day of month.
 * m - Pointer to the variable that receives the month.
 * y - Pointer to the variable that receives the year.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_GetDate(u32 *d, u32 *m, u32 *y)
{
    *d = DOM;
    /* Reads the Day of Month register and stores the value
       in the variable whose address is passed through d. */


    *m = MONTH;
    /* Reads the Month register and stores the value
       in the variable whose address is passed through m. */


    *y = YEAR;
    /* Reads the Year register and stores the value
       in the variable whose address is passed through y.

       Example:
           u32 date, month, year;
           RTC_GetDate(&date, &month, &year);

       After execution, the variables contain the current
       RTC calendar values. */
}


/***************************************************************
 * FUNCTION NAME : RTC_GetDay
 *
 * DESCRIPTION   :
 * Reads the current weekday value from the RTC DOW register.
 *
 * PARAMETERS:
 * day - Pointer to the variable that receives the weekday.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_GetDay(u32 *day)
{
    *day = DOW;
    /* Reads the Day of Week register and stores the value
       in the memory location pointed to by day.

       Expected mapping:
           0 - Sunday
           1 - Monday
           2 - Tuesday
           3 - Wednesday
           4 - Thursday
           5 - Friday
           6 - Saturday

       Example:
           u32 weekday;
           RTC_GetDay(&weekday);

       The weekday variable receives the current DOW value. */
}


/***************************************************************
 * FUNCTION NAME : RTC_IsLeapYear
 *
 * DESCRIPTION   :
 * Checks whether the supplied calendar year is a leap year
 * according to the Gregorian calendar rules.
 *
 * LEAP YEAR RULES:
 *
 * Rule 1:
 * A year divisible by 400 is always a leap year.
 *
 * Rule 2:
 * A year divisible by 100 but not by 400 is not a leap year.
 *
 * Rule 3:
 * A year divisible by 4 but not by 100 is a leap year.
 *
 * All other years are not leap years.
 *
 * PARAMETERS:
 * year - Calendar year to be checked.
 *
 * RETURN VALUE:
 * 1U - The supplied year is a leap year.
 * 0U - The supplied year is not a leap year.
 ***************************************************************/

u8 RTC_IsLeapYear(u32 year)
{
    if((year % 400U) == 0U)
        return 1U;
    /* Checks divisibility by 400.

       The modulus operator (%) returns the remainder.

       If year % 400 equals zero, the year is divisible by 400.

       Example:
           2000 % 400 = 0

       Therefore, 2000 is a leap year.

       This condition is checked first because years divisible
       by 400 are leap years even though they are also divisible
       by 100. */


    if((year % 100U) == 0U)
        return 0U;
    /* Checks whether the year is divisible by 100.

       If this condition is true, the year is not a leap year,
       unless it was already identified as divisible by 400.

       Example:
           1900 % 100 = 0
           1900 % 400 != 0

       Therefore, 1900 is not a leap year. */


    if((year % 4U) == 0U)
        return 1U;
    /* Checks whether the year is divisible by 4.

       If true, the year is a leap year because the previous
       century-year exception has already been handled.

       Example:
           2024 % 4 = 0

       Therefore, 2024 is a leap year. */


    return 0U;
    /* If none of the above conditions is satisfied,
       the supplied year is not a leap year.

       Example:
           2025 % 4 != 0

       Therefore, 2025 is not a leap year. */
}


/***************************************************************
 * FUNCTION NAME : RTC_DaysInMonth
 *
 * DESCRIPTION   :
 * Returns the total number of calendar days available in
 * the specified month for the supplied year.
 *
 * This function is useful for validating user-entered dates.
 *
 * MONTH MAPPING:
 *     1  - January
 *     2  - February
 *     3  - March
 *     4  - April
 *     5  - May
 *     6  - June
 *     7  - July
 *     8  - August
 *     9  - September
 *     10 - October
 *     11 - November
 *     12 - December
 *
 * PARAMETERS:
 * month - Month number from 1 to 12.
 * year  - Calendar year used for February validation.
 *
 * RETURN VALUE:
 * 31U - Month contains 31 days.
 * 30U - Month contains 30 days.
 * 29U - February in a leap year.
 * 28U - February in a non-leap year.
 * 0U  - Invalid month number.
 ***************************************************************/

u8 RTC_DaysInMonth(u32 month, u32 year)
{
    switch(month)
    {
        /* The switch statement selects the appropriate
           month-specific number of days using the month value. */


        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31U;
        /* January, March, May, July, August, October and
           December contain 31 days.

           Multiple case labels share the same return statement
           because all these months have the same day count. */


        case 4: case 6: case 9: case 11:
            return 30U;
        /* April, June, September and November contain 30 days. */


        case 2:
            return RTC_IsLeapYear(year) ? 29U : 28U;
        /* February requires special handling because its
           number of days depends on whether the year is a
           leap year.

           The conditional (ternary) operator works as follows:

               condition ? value_if_true : value_if_false

           If RTC_IsLeapYear(year) returns 1:
               Returns 29U.

           If RTC_IsLeapYear(year) returns 0:
               Returns 28U.

           Example:
               February 2024 = 29 days.
               February 2025 = 28 days. */


        default:
            return 0U;
        /* Executes when the supplied month does not match
           any valid month number from 1 to 12.

           Returning zero indicates an invalid month input. */
    }
}


/***************************************************************
 * FUNCTION NAME : RTC_DisplayTime
 *
 * DESCRIPTION   :
 * Displays the supplied time on the first line of the LCD
 * in HH:MM:SS format.
 *
 * DISPLAY FORMAT:
 *     HH:MM:SS
 *
 * Example:
 *     09:05:07
 *
 * PARAMETERS:
 * h - Hour value.
 * m - Minute value.
 * s - Second value.
 *
 * RETURN VALUE  : None.
 *
 * IMPLEMENTATION:
 * Each decimal digit is extracted using division and modulus.
 * The digit is converted into its corresponding ASCII character
 * before being transmitted to the LCD.
 ***************************************************************/

void RTC_DisplayTime(u32 h, u32 m, u32 s)
{
    CmdLCD(GOTO_LINE1_POS0);
    /* Positions the LCD cursor at the first character
       of the first display line.

       GOTO_LINE1_POS0 sends the LCD DDRAM address command
       for line 1, position 0. */


    CharLCD((u8)((h / 10U) + '0'));
    /* Extracts the tens digit of the hour.

       Example:
           h = 16
           16 / 10 = 1

       Adding ASCII '0' converts numeric digit 1 into
       its corresponding ASCII character '1'.

       The character is then displayed on the LCD. */


    CharLCD((u8)((h % 10U) + '0'));
    /* Extracts the units digit of the hour.

       Example:
           h = 16
           16 % 10 = 6

       Adding ASCII '0' converts digit 6 into character '6'.

       Together, the previous two statements display 16. */


    CharLCD(':');
    /* Displays the colon separator between hours and minutes. */


    CharLCD((u8)((m / 10U) + '0'));
    /* Extracts and displays the tens digit of the minute value. */


    CharLCD((u8)((m % 10U) + '0'));
    /* Extracts and displays the units digit of the minute value. */


    CharLCD(':');
    /* Displays the colon separator between minutes and seconds. */


    CharLCD((u8)((s / 10U) + '0'));
    /* Extracts and displays the tens digit of the second value. */


    CharLCD((u8)((s % 10U) + '0'));
    /* Extracts and displays the units digit of the second value.

       Example:
           h = 9, m = 5, s = 7

       LCD output:
           09:05:07

       NOTE:
       This function expects valid two-digit time components.
       It does not perform range checking. */
}


/***************************************************************
 * FUNCTION NAME : RTC_DisplayDate
 *
 * DESCRIPTION   :
 * Displays the supplied calendar date on the second line
 * of the LCD in DD/MM/YYYY format.
 *
 * DISPLAY FORMAT:
 *     DD/MM/YYYY
 *
 * Example:
 *     25/11/2026
 *
 * PARAMETERS:
 * d - Day of the month.
 * m - Month.
 * y - Year.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_DisplayDate(u32 d, u32 m, u32 y)
{
    CmdLCD(GOTO_LINE2_POS0);
    /* Positions the LCD cursor at the beginning of the
       second display line. */


    CharLCD((u8)((d / 10U) + '0'));
    /* Extracts and displays the tens digit of the date.

       Example:
           d = 25
           25 / 10 = 2

       ASCII conversion produces character '2'. */


    CharLCD((u8)((d % 10U) + '0'));
    /* Extracts and displays the units digit of the date.

       Example:
           d = 25
           25 % 10 = 5

       Together, the previous two statements display 25. */


    CharLCD('/');
    /* Displays the separator between date and month. */


    CharLCD((u8)((m / 10U) + '0'));
    /* Extracts and displays the tens digit of the month. */


    CharLCD((u8)((m % 10U) + '0'));
    /* Extracts and displays the units digit of the month. */


    CharLCD('/');
    /* Displays the separator between month and year. */


    U32LCD(y);
    /* Displays the complete unsigned year value.

       U32LCD() is a utility function provided by the LCD driver.

       Unlike CharLCD(), which displays one character,
       U32LCD() converts and displays a multi-digit unsigned
       integer.

       Example:
           y = 2026

       LCD output:
           25/11/2026

       NOTE:
       The year is displayed as an integer. The function does
       not force a fixed four-digit width for values below 1000. */
}


/***************************************************************
 * FUNCTION NAME : RTC_DisplayDay
 *
 * DESCRIPTION   :
 * Displays the weekday name on the LCD based on the numeric
 * day-of-week value read from the RTC DOW register.
 *
 * DAY MAPPING:
 *     0 - SUN
 *     1 - MON
 *     2 - TUE
 *     3 - WED
 *     4 - THU
 *     5 - FRI
 *     6 - SAT
 *
 * PARAMETERS:
 * day - Numeric weekday value from 0 to 6.
 *
 * RETURN VALUE  : None.
 ***************************************************************/

void RTC_DisplayDay(u32 day)
{
    CmdLCD(GOTO_LINE2_POS0 + 12);
    /* Positions the LCD cursor at column 12 of the second line.

       GOTO_LINE2_POS0 represents the starting DDRAM address
       of the second LCD line.

       Adding 12 moves the cursor to the thirteenth character
       position (zero-based column index 12).

       For a typical 16x2 LCD, this position allows the
       three-character weekday abbreviation to be displayed
       in the final three columns. */


    switch(day)
    /* Selects the weekday abbreviation based on the numeric
       value received from the RTC DOW register.

       The switch statement compares day against each case
       and executes the matching display operation. */
    {
        case 0:
            StrLCD("SUN");
            break;
        /* Day value 0 represents Sunday.
           Displays SUN on the LCD.
           break prevents execution from continuing into
           the next case. */


        case 1:
            StrLCD("MON");
            break;
        /* Day value 1 represents Monday.
           Displays MON on the LCD. */


        case 2:
            StrLCD("TUE");
            break;
        /* Day value 2 represents Tuesday.
           Displays TUE on the LCD. */


        case 3:
            StrLCD("WED");
            break;
        /* Day value 3 represents Wednesday.
           Displays WED on the LCD. */


        case 4:
            StrLCD("THU");
            break;
        /* Day value 4 represents Thursday.
           Displays THU on the LCD. */


        case 5:
            StrLCD("FRI");
            break;
        /* Day value 5 represents Friday.
           Displays FRI on the LCD. */


        case 6:
            StrLCD("SAT");
            break;
        /* Day value 6 represents Saturday.
           Displays SAT on the LCD. */


        default:
            StrLCD("INVALID DAY");
            break;
        /* Executes when the supplied weekday value is outside
           the supported range of 0 to 6.

           Displays an error message instead of a weekday name. */
    }
}


/***************************************************************
 * END OF RTC DRIVER MODULE
 ***************************************************************/
```