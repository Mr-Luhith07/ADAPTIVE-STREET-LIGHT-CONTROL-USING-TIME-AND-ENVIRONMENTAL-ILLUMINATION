```c
/***************************************************************
 * FILE NAME   : PROJECT_CONFIG.H
 * PROJECT     : ADAPTIVE STREET LIGHT CONTROL SYSTEM
 * MCU         : LPC2129 / LPC2148
 *
 * DESCRIPTION :
 * This header file contains the centralized hardware and
 * application configuration parameters used throughout the
 * Adaptive Street Light Control System.
 *
 * It defines:
 * 1. Oscillator, CPU and peripheral clock frequencies.
 * 2. RTC prescaler calibration values.
 * 3. RTC reset and enable control bits.
 * 4. Street-light GPIO pin configuration.
 * 5. ADC channel selection for the LDR sensor.
 * 6. LDR darkness and brightness detection thresholds.
 * 7. VIC interrupt channel configuration for EINT0.
 *
 * Centralizing these configuration values makes the project
 * easier to maintain, modify and port between supported
 * microcontroller configurations.
 ***************************************************************/


#ifndef PROJECT_CONFIG_H
/* Header guard:
   Checks whether PROJECT_CONFIG_H has already been defined.
   Prevents repeated inclusion of this header file within
   the same source-file compilation unit. */

#define PROJECT_CONFIG_H
/* Defines the header guard after the first inclusion.
   Subsequent inclusions skip the contents of this file. */


/***************************************************************
 * 1. OSCILLATOR AND SYSTEM CLOCK CONFIGURATION
 ***************************************************************/

/* FOSC:
   Defines the external crystal oscillator frequency connected
   to the microcontroller.

   Value       : 12 MHz
   Unit        : Hertz
   Meaning     : The external crystal provides the reference
                 clock used by the PLL clock-generation system.

   The suffix U specifies an unsigned integer constant.
*/
#define FOSC             12000000U


/* CCLK:
   Defines the CPU clock frequency after PLL multiplication.

   Formula:
       CCLK = FOSC * 5

       CCLK = 12 MHz * 5
       CCLK = 60 MHz

   The PLL multiplies the oscillator frequency to generate
   the higher-frequency clock used by the ARM processor.

   Value       : 60 MHz
   Purpose     : Determines the operating frequency of the CPU.

   NOTE:
   The actual hardware PLL configuration must also be performed
   in the system initialization code. Defining this macro alone
   does not configure the PLL.
*/
#define CCLK             (FOSC * 5U)       /* 60 MHz */


/* PCLK:
   Defines the peripheral clock frequency supplied to
   peripheral modules such as the RTC, timers and other
   peripheral blocks.

   Formula:
       PCLK = CCLK / 4

       PCLK = 60 MHz / 4
       PCLK = 15 MHz

   Value       : 15 MHz
   Purpose     : Used when calculating peripheral timing
                 parameters, including RTC prescaler values.

   NOTE:
   The actual peripheral clock divider must be configured
   through the appropriate processor clock-control register.
*/
#define PCLK             (CCLK / 4U)       /* 15 MHz */


/***************************************************************
 * 2. RTC PRESCALER CONFIGURATION
 ***************************************************************/

/* PREINT_VAL:
   Defines the integer portion of the RTC prescaler value.

   The RTC requires a 32.768 kHz reference clock to maintain
   accurate one-second timekeeping.

   Formula:
       PREINT = (PCLK / 32768) - 1

   For PCLK = 15 MHz:

       PREINT = (15000000 / 32768) - 1

       PREINT = 457 - 1

       PREINT = 456

   Purpose:
       Supplies the integer prescaler calibration value used
       by the RTC peripheral.

   This value is normally written into the RTC PREINT register
   during RTC initialization.
*/
#define PREINT_VAL       ((PCLK / 32768U) - 1U)


/* PREFRAC_VAL:
   Defines the fractional portion of the RTC prescaler value.

   The fractional prescaler compensates for the difference
   between the peripheral clock frequency and the required
   32.768 kHz RTC clock.

   Formula:
       PREFRAC = PCLK - ((PREINT + 1) * 32768)

   For PCLK = 15 MHz and PREINT = 456:

       PREFRAC = 15000000 - (457 * 32768)

       PREFRAC = 15000000 - 14974976

       PREFRAC = 25024

   Purpose:
       Provides the fractional calibration value used by
       the RTC peripheral for accurate timekeeping.

   This value is normally written into the RTC PREFRAC
   register during RTC initialization.
*/
#define PREFRAC_VAL      (PCLK - ((PREINT_VAL + 1U) * 32768U))


/***************************************************************
 * 3. RTC CONTROL BIT CONFIGURATION
 ***************************************************************/

/* RTC_RST:
   Defines the bit position used to reset the RTC peripheral.

   (1U << 1) shifts binary value 1 to bit position 1.

       Binary representation : 00000010
       Hexadecimal value     : 0x02

   When this bit is written as 1 in the RTC control register,
   it requests an RTC reset according to the register's
   hardware definition.

   It is typically used during RTC initialization to reset
   the RTC counter and associated timekeeping registers.
*/
#define RTC_RST          (1U << 1)


/* RTC_ENB:
   Defines the RTC enable control bit.

   (1U << 0) shifts binary value 1 to bit position 0.

       Binary representation : 00000001
       Hexadecimal value     : 0x01

   When this bit is set in the RTC control register, it enables
   RTC operation according to the microcontroller's register
   definition.

   It is used by the RTC initialization code to start or enable
   the RTC counter.
*/
#define RTC_ENB          (1U << 0)


/***************************************************************
 * 4. STREET-LIGHT GPIO CONFIGURATION
 ***************************************************************/

/* LIGHT_PIN:
   Defines the starting GPIO bit position used for controlling
   the four street-light output lines.

   Starting pin : P1.24

   The four consecutive GPIO pins are:
       P1.24
       P1.25
       P1.26
       P1.27

   These pins are intended to control the street-light outputs.

   The value 24 represents the starting bit position, not
   the number of output pins.
*/
#define LIGHT_PIN        24U               /* P1.24 to P1.27 */


/* LIGHT_MASK:
   Generates a bit mask for the four consecutive street-light
   GPIO pins.

   Formula:
       0x0F = 0000 1111 (binary)

       LIGHT_MASK = 0x0F << 24

   Result:
       Bits 24, 25, 26 and 27 are set to 1.

   Purpose:
       Allows all four street-light GPIO pins to be configured
       or controlled together using bitwise operations.

   Example:
       IOSET1 = LIGHT_MASK;

       Sets the corresponding GPIO output latch bits HIGH.

       IOCLR1 = LIGHT_MASK;

       Clears the corresponding GPIO output latch bits LOW.

   IMPORTANT:
   The actual electrical ON/OFF state of a street light depends
   on the connected driver circuit and whether the output is
   active-HIGH or active-LOW.
*/
#define LIGHT_MASK       (0x0FU << LIGHT_PIN)


/***************************************************************
 * 5. ADC AND LDR SENSOR CONFIGURATION
 ***************************************************************/

/* ADC_CHANNEL:
   Selects the ADC input channel connected to the LDR sensor.

   Value       : 1
   ADC channel  : AD0.1
   MCU pin      : P0.28

   The ADC peripheral converts the analog voltage produced
   by the LDR voltage-divider circuit into a digital value.

   For a 10-bit ADC:
       Minimum digital value = 0
       Maximum digital value = 1023

   The ADC driver uses this macro to select the required
   ADC channel for conversion.

   NOTE:
   The corresponding pin-function selection must configure
   P0.28 as AD0.1 before performing ADC conversions.
*/
#define ADC_CHANNEL      1U                /* AD0.1 on P0.28 */


/* LDR_DARK_WHEN_HIGH:
   Defines the direction of LDR darkness detection based on
   the ADC digital output.

   Value 1:
       A higher ADC reading indicates darkness.

   Value 0:
       A lower ADC reading indicates darkness.

   This is a compile-time configuration option.

   The LDR application code uses conditional compilation
   (#if / #else) to select the appropriate detection logic.

   IMPORTANT:
   The correct value depends on the physical LDR voltage-divider
   connection and the ADC voltage response to light intensity.
   Verify it using actual ADC readings under bright and dark
   conditions before final hardware deployment.
*/
#define LDR_DARK_WHEN_HIGH 1U


/* LDR_DARK_THRESHOLD:
   Defines the ADC threshold at which the application identifies
   the surrounding environment as dark when the configured
   detection direction is HIGH.

   Value       : 650
   ADC range   : 0 to 1023

   When LDR_DARK_WHEN_HIGH is 1:
       ADC reading >= 650
       The application identifies the environment as DARK.

   This threshold is used by the LDR application logic to
   determine when the street-light system should consider
   switching into its dark-condition state.
*/
#define LDR_DARK_THRESHOLD 650U


/* LDR_BRIGHT_THRESHOLD:
   Defines the ADC threshold at which the application identifies
   the surrounding environment as bright when the configured
   detection direction is HIGH.

   Value       : 550
   ADC range   : 0 to 1023

   When LDR_DARK_WHEN_HIGH is 1:
       ADC reading <= 550
       The application identifies the environment as BRIGHT.

   HYSTERESIS:
       Dark threshold   = 650
       Bright threshold = 550

   The difference between these thresholds creates a
   hysteresis band.

   Between ADC readings 551 and 649:
       The previous LDR state is retained.

   This prevents rapid switching between DARK and BRIGHT
   states when the ADC reading fluctuates near a threshold.
*/
#define LDR_BRIGHT_THRESHOLD 550U


/***************************************************************
 * 6. EXTERNAL INTERRUPT CONFIGURATION
 ***************************************************************/

/* EINT0_CHANNEL:
   Defines the VIC (Vectored Interrupt Controller) channel
   number assigned to External Interrupt 0.

   Value       : 14
   Interrupt   : EINT0
   VIC channel : 14

   When the EINT0 input pin detects the configured interrupt
   condition, the VIC identifies the corresponding interrupt
   source using this channel number.

   The EINT driver uses this macro while enabling and configuring
   the interrupt in the VIC registers.

   IMPORTANT:
   This value represents the VIC interrupt channel number.
   It is not the physical GPIO pin number or the EINT0 pin number.
*/
#define EINT0_CHANNEL    14U


/***************************************************************
 * END OF PROJECT CONFIGURATION HEADER
 ***************************************************************/

#endif
/* Ends the PROJECT_CONFIG_H header guard. */
```