```c
/*
 *==============================================================================
 * File Name    : menu.c
 * Module Name  : RTC and Street-Light Configuration Menu
 * Project      : Adaptive Street Light Control System
 * Target MCU   : LPC2129 / LPC2148
 * Interface    : 4x4 Matrix Keypad and Character LCD
 *
 * Description:
 *   This module implements the user configuration menu for the
 *   Adaptive Street Light Control System.
 *
 *   The user enters this menu by pressing the EINT0 push-button.
 *   The main application detects the interrupt request and calls
 *   RTC_Edit_Menu() to start the menu operations.
 *
 * Main Responsibilities:
 *   1. Provide a menu for editing RTC time.
 *   2. Provide a menu for editing RTC date and day of the week.
 *   3. Provide a menu for modifying street-light operating boundaries.
 *   4. Accept numerical input through the matrix keypad.
 *   5. Support clear, backspace and accept operations through the keypad.
 *   6. Restrict the number of digits accepted for each input.
 *   7. Validate entered values before updating the RTC or boundaries.
 *   8. Display suitable status and error messages on the LCD.
 *   9. Maintain street-light operation while the user interacts with
 *      the configuration menu.
 *
 * USER INPUT KEY DEFINITIONS:
 *
 *   Numeric Keys (0-9):
 *     Used to enter menu selections and numerical configuration values.
 *
 *   C:
 *     Clears the currently entered numerical value.
 *
 *   x:
 *     Deletes the last entered digit (backspace operation).
 *
 *   =:
 *     Accepts the entered numerical value.
 *
 * MENU STRUCTURE:
 *
 *   MAIN MENU:
 *     1 - Edit RTC Time
 *     2 - Edit RTC Date
 *     3 - Edit Street-Light Boundaries
 *     4 - Exit Menu
 *
 *   TIME MENU:
 *     1 - Edit Hour
 *     2 - Edit Minute
 *     3 - Edit Second
 *     4 - Exit Time Menu
 *
 *   DATE MENU:
 *     1 - Edit Date
 *     2 - Edit Month
 *     3 - Edit Year
 *     4 - Edit Day of Week
 *     5 - Exit Date Menu
 *
 *   BOUNDARY MENU:
 *     1 - Edit Start Hour
 *     2 - Edit Start Minute
 *     3 - Edit End Hour
 *     4 - Edit End Minute
 *     5 - Exit Boundary Menu
 *
 * BACKGROUND OPERATION:
 *   BackgroundTasks() periodically:
 *     1. Reads the current RTC time.
 *     2. Reads the LDR sensor through the ADC.
 *     3. Updates the street-light output according to the RTC
 *        schedule and LDR darkness condition.
 *
 *   This allows automatic street-light control to continue while
 *   the user is entering configuration values.
 *
 * DEPENDENCIES:
 *   LPC21xx.h     - LPC21xx microcontroller register definitions.
 *   types.h       - Project-specific data type definitions.
 *   rtc.h         - RTC driver and calendar interface.
 *   lcd.h         - LCD driver interface.
 *   lcd_defines.h - LCD commands and GPIO pin definitions.
 *   kpm.h         - Matrix keypad driver interface.
 *   delay.h       - Software delay functions.
 *   ldr.h         - LDR application interface.
 *   streetlight.h - Street-light control interface.
 *   menu.h        - Menu module function declarations.
 *
 *==============================================================================
 */


/*==============================================================================
 * HEADER FILE INCLUSIONS
 *==============================================================================
 *
 * Include the required header files to access the microcontroller
 * registers, data types, peripheral drivers and application modules.
 */


/*
 * Provides LPC21xx microcontroller register definitions.
 *
 * Allows access to on-chip peripheral registers such as GPIO,
 * RTC and other hardware control registers.
 */
#include <LPC21xx.h>


/*
 * Provides project-specific data types.
 *
 * Examples:
 *   u8  - 8-bit unsigned integer.
 *   u16 - 16-bit unsigned integer.
 *   u32 - 32-bit unsigned integer.
 *   s8  - 8-bit signed integer.
 *   f32 - 32-bit floating-point type.
 */
#include "types.h"


/*
 * Provides the RTC driver interface.
 *
 * Used for:
 *   - Reading the current RTC time.
 *   - Setting the RTC time.
 *   - Setting the RTC date.
 *   - Setting the day of the week.
 *   - Accessing RTC calendar information.
 *   - Calculating the number of days in a particular month.
 *
 * The RTC driver maintains the actual time and calendar registers.
 */
#include "rtc.h"


/*
 * Provides LCD driver function declarations.
 *
 * Used to display menu options, user prompts, entered values
 * and validation messages.
 */
#include "lcd.h"


/*
 * Provides LCD command definitions.
 *
 * Examples:
 *   CLEAR_LCD
 *   GOTO_LINE1_POS0
 *   GOTO_LINE2_POS0
 *
 * These macros are used to control the LCD cursor and display.
 */
#include "lcd_defines.h"


/*
 * Provides matrix keypad driver declarations.
 *
 * Used to obtain numerical input and menu selections from the user.
 *
 * ReadNumWithService() also accepts a background service function
 * pointer so that background operations can execute during input.
 */
#include "kpm.h"


/*
 * Provides software delay function declarations.
 *
 * Used to maintain suitable display intervals for status messages
 * and error messages.
 */
#include "delay.h"


/*
 * Provides the LDR application-layer interface.
 *
 * Used by BackgroundTasks() to obtain updated ambient-light information.
 */
#include "ldr.h"


/*
 * Provides street-light control function declarations.
 *
 * Used by BackgroundTasks() to maintain automatic street-light
 * operation according to RTC and LDR conditions.
 */
#include "streetlight.h"


/*
 * Provides the menu module's public function declarations.
 *
 * Allows the main application to call RTC_Edit_Menu().
 */
#include "menu.h"


/*==============================================================================
 * GLOBAL VARIABLES
 *==============================================================================
 *
 * The following variables store the latest RTC time values used
 * by the background service routine.
 *
 * STATIC STORAGE CLASS:
 *
 *   The static keyword restricts direct access to these variables
 *   to this source file.
 *
 *   Their values are retained throughout the program execution.
 *
 *   These variables are not re-created every time BackgroundTasks()
 *   is called.
 */


/*
 * hr:
 *   Stores the current RTC hour.
 *
 * min:
 *   Stores the current RTC minute.
 *
 * sec:
 *   Stores the current RTC second.
 *
 * These variables are updated by RTC_GetTime().
 *
 * They are used by StreetLight_Control() to evaluate the current
 * street-light operating schedule.
 */
static u32 hr, min, sec;


/*==============================================================================
 * FUNCTION NAME : BackgroundTasks
 *==============================================================================
 *
 * Description:
 *   Executes the essential background operations required to maintain
 *   automatic street-light operation while the user is inside the menu.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   void - Does not return any value.
 *
 * Execution Sequence:
 *   1. Reads the current RTC time.
 *   2. Reads the LDR sensor.
 *   3. Executes the street-light control logic.
 *
 * Purpose:
 *   Normally, the main application performs RTC reading, LDR acquisition
 *   and street-light control inside its main loop.
 *
 *   However, menu functions can spend considerable time waiting for
 *   keypad input.
 *
 *   Calling BackgroundTasks() during keypad input helps prevent the
 *   automatic street-light control logic from being neglected.
 *
 * IMPORTANT:
 *   This function executes in normal application context.
 *   It is not an interrupt service routine.
 */
void BackgroundTasks(void)
{
    /*
     * Read the current RTC time.
     *
     * Arguments:
     *   &hr  - Address where the current hour is stored.
     *   &min - Address where the current minute is stored.
     *   &sec - Address where the current second is stored.
     *
     * The RTC driver updates these variables through pointers.
     */
    RTC_GetTime(&hr, &min, &sec);


    /*
     * Read the latest LDR sensor measurement.
     *
     * Internally, LDR_Read():
     *   1. Starts an ADC conversion.
     *   2. Obtains the digital ADC result.
     *   3. Calculates the corresponding sensor voltage.
     *   4. Applies the configured hysteresis thresholds.
     *   5. Updates the ldrDark status.
     */
    LDR_Read();


    /*
     * Execute automatic street-light control.
     *
     * Arguments:
     *   hr  - Latest RTC hour.
     *   min - Latest RTC minute.
     *
     * The street-light control module evaluates the current time
     * against the configured operating boundaries and checks the
     * latest LDR darkness condition.
     *
     * Operating condition:
     *
     *   RTC schedule active AND LDR darkness detected:
     *       Street lights ON.
     *
     *   Otherwise:
     *       Street lights OFF.
     */
    StreetLight_Control(hr, min);
}


/*==============================================================================
 * FUNCTION NAME : ReadValue
 *==============================================================================
 *
 * Description:
 *   Displays a user prompt on the LCD and obtains a numerical value
 *   through the keypad.
 *
 * Parameters:
 *   message   - Pointer to the null-terminated LCD prompt string.
 *   maxDigits - Maximum number of numerical digits accepted.
 *
 * Return Value:
 *   u32 - The numerical value accepted by the keypad input function.
 *
 * Working:
 *   1. Clears the LCD.
 *   2. Positions the cursor at the beginning of the first line.
 *   3. Displays the supplied message.
 *   4. Calls ReadNumWithService() to accept keypad input.
 *
 * BACKGROUND SERVICE:
 *   BackgroundTasks is passed as a function pointer to
 *   ReadNumWithService().
 *
 *   This allows RTC, LDR and street-light operations to continue
 *   while the keypad input routine waits for user input.
 */
static u32 ReadValue(s8 *message, u8 maxDigits)
{
    /*
     * Clear the LCD display.
     *
     * Removes previously displayed menu options or messages
     * before displaying the new input prompt.
     */
    CmdLCD(CLEAR_LCD);


    /*
     * Move the LCD cursor to the first position of the first line.
     *
     * Ensures that the input prompt starts from the beginning
     * of the LCD display.
     */
    CmdLCD(GOTO_LINE1_POS0);


    /*
     * Display the input prompt supplied by the calling function.
     *
     * Examples:
     *   "SET HOUR 0-23"
     *   "SET MIN 0-59"
     *   "SET YEAR 1-4095"
     *
     * message is a pointer to the string supplied by the caller.
     */
    StrLCD(message);


    /*
     * Read the numerical value from the keypad.
     *
     * Arguments:
     *   maxDigits       - Maximum number of digits permitted.
     *   BackgroundTasks - Function pointer for background operations.
     *
     * Keypad operations:
     *   Numeric keys - Enter digits.
     *   C            - Clear entered value.
     *   x            - Delete the last digit.
     *   =            - Accept the entered value.
     *
     * The accepted numerical value is returned by ReadNumWithService()
     * and returned again by ReadValue().
     */
    return ReadNumWithService(maxDigits, BackgroundTasks);
}


/*==============================================================================
 * FUNCTION NAME : ReadValueInRange
 *==============================================================================
 *
 * Description:
 *   Obtains a numerical value from the keypad and validates it
 *   against the minimum and maximum permitted limits.
 *
 * Parameters:
 *   message   - LCD prompt displayed during value entry.
 *   min_value - Minimum permitted numerical value.
 *   max_value - Maximum permitted numerical value.
 *   maxDigits - Maximum number of digits accepted.
 *
 * Return Value:
 *   u32 - A value that satisfies the specified minimum and maximum limits.
 *
 * Working:
 *   1. Requests a numerical value using ReadValue().
 *   2. Checks whether the entered value is within the permitted range.
 *   3. Returns the value if validation succeeds.
 *   4. Displays an error message if validation fails.
 *   5. Repeats the input process until a valid value is entered.
 *
 * Purpose:
 *   Prevents invalid numerical values from being passed to
 *   RTC configuration or street-light boundary variables.
 */
static u32 ReadValueInRange(s8 *message,
                            u32 min_value,
                            u32 max_value,
                            u8 maxDigits)
{
    /*
     * Stores the numerical value entered by the user.
     *
     * The value is checked against min_value and max_value
     * before being accepted.
     */
    u32 value;


    /*
     * Infinite validation loop.
     *
     * The function continues requesting input until the user
     * enters a value within the permitted range.
     */
    while(1)
    {

        /*
         * Obtain a numerical value from the keypad.
         *
         * ReadValue() displays the prompt and calls the keypad
         * input function with the required digit limit.
         */
        value = ReadValue(message, maxDigits);


        /*
         * RANGE VALIDATION:
         *
         * Check whether the entered value satisfies both conditions:
         *
         *   value >= min_value
         *   value <= max_value
         *
         * The logical AND operator (&&) ensures that both
         * comparisons must be true.
         */
        if(value >= min_value && value <= max_value)
        {

            /*
             * Return the accepted value to the calling function.
             *
             * The return statement also terminates the current function.
             */
            return value;
        }


        /*
         * INVALID INPUT HANDLING:
         *
         * Executed when the entered value is outside the permitted range.
         *
         * Clear the previous LCD contents before displaying
         * the error message.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first LCD line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Inform the user that the entered numerical value is invalid.
         */
        StrLCD("INVALID VALUE");


        /*
         * Keep the error message visible for approximately 700 ms.
         */
        delay_ms(700U);

        /*
         * After the delay, the while loop repeats and requests
         * a new numerical value.
         */
    }
}


/*==============================================================================
 * FUNCTION NAME : EditTime
 *==============================================================================
 *
 * Description:
 *   Provides the menu for editing the RTC hour, minute and second values.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   void - Does not return any value.
 *
 * Menu Options:
 *   1 - Edit Hour   (0-23).
 *   2 - Edit Minute (0-59).
 *   3 - Edit Second (0-59).
 *   4 - Exit Time Menu.
 *
 * Working:
 *   1. Reads the existing RTC time.
 *   2. Displays the time-editing menu.
 *   3. Accepts a one-digit menu selection.
 *   4. Requests the selected time component.
 *   5. Validates the entered value.
 *   6. Updates the RTC using the modified and preserved values.
 *
 * IMPORTANT:
 *   The local variables preserve the time components that the user
 *   does not select for editing.
 */
static void EditTime(void)
{
    /*
     * h      - Local hour value.
     * m      - Local minute value.
     * s      - Local second value.
     * choice - Stores the user's menu selection.
     */
    u32 h, m, s, choice;


    /*
     * Read the existing RTC time before displaying the menu.
     *
     * This is important because changing only one component must
     * not unintentionally reset the other components.
     *
     * Example:
     *   Existing time = 18:30:45.
     *
     * If the user changes only the hour to 20, the preserved values
     * should be:
     *   20:30:45.
     */
    RTC_GetTime(&h, &m, &s);


    /*
     * Keep displaying the time menu until the user selects EXIT.
     */
    while(1)
    {

        /*
         * Execute background operations before displaying the menu.
         *
         * This updates the RTC time variables used by street-light
         * control and refreshes the LDR sensor status.
         */
        BackgroundTasks();


        /*
         * Clear the LCD before displaying the time menu.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Display the first two menu options:
         *   1 - Hour.
         *   2 - Minute.
         */
        StrLCD("1.HOUR 2.MINUTE");


        /*
         * Move the cursor to the beginning of the second line.
         */
        CmdLCD(GOTO_LINE2_POS0);


        /*
         * Display the remaining menu options:
         *   3 - Second.
         *   4 - Exit.
         */
        StrLCD("3.SECOND 4.EXIT");


        /*
         * MENU SELECTION:
         *
         * Read one digit from the keypad.
         *
         * maxDigits = 1U ensures that only a single numerical
         * digit is accepted for the menu selection.
         *
         * BackgroundTasks is executed during keypad input.
         */
        choice = ReadNumWithService(1U, BackgroundTasks);


        /*
         * Select the operation corresponding to the entered value.
         *
         * The switch statement provides separate execution paths
         * for each menu option.
         */
        switch(choice)
        {

            /*
             * CASE 1:
             * Edit the RTC hour.
             */
            case 1:

                /*
                 * Request an hour value from the keypad.
                 *
                 * Permitted range:
                 *   Minimum = 0.
                 *   Maximum = 23.
                 *
                 * Maximum digits = 2.
                 *
                 * The validated value is stored in h.
                 */
                h = ReadValueInRange("SET HOUR 0-23",
                                     0U, 23U, 2U);

                /*
                 * Exit this switch case and continue the menu loop.
                 */
                break;


            /*
             * CASE 2:
             * Edit the RTC minute.
             */
            case 2:

                /*
                 * Request a minute value from the keypad.
                 *
                 * Permitted range:
                 *   Minimum = 0.
                 *   Maximum = 59.
                 *
                 * Maximum digits = 2.
                 *
                 * The validated value is stored in m.
                 */
                m = ReadValueInRange("SET MIN 0-59",
                                     0U, 59U, 2U);

                break;


            /*
             * CASE 3:
             * Edit the RTC second.
             */
            case 3:

                /*
                 * Request a second value from the keypad.
                 *
                 * Permitted range:
                 *   Minimum = 0.
                 *   Maximum = 59.
                 *
                 * Maximum digits = 2.
                 *
                 * The validated value is stored in s.
                 */
                s = ReadValueInRange("SET SEC 0-59",
                                     0U, 59U, 2U);

                break;


            /*
             * CASE 4:
             * Exit the time-editing menu.
             */
            case 4:

                /*
                 * Clear the LCD before displaying the exit message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display a message indicating that the time menu
                 * is being exited.
                 */
                StrLCD("EXIT T-MENU");


                /*
                 * Keep the exit message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Clear the LCD after displaying the message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Return from EditTime().
                 *
                 * Control returns to the function that called EditTime(),
                 * which is normally the main RTC edit menu.
                 */
                return;


            /*
             * DEFAULT CASE:
             * Handles all menu selections other than 1, 2, 3 and 4.
             */
            default:

                /*
                 * Clear the LCD before displaying the error message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Inform the user that the selected menu option is invalid.
                 */
                StrLCD("INVALID OPTION");


                /*
                 * Keep the error message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Skip the remaining statements of the current loop
                 * iteration and restart the time menu.
                 */
                continue;
        }


        /*
         * UPDATE RTC TIME:
         *
         * After a valid time component has been selected and entered,
         * update the RTC using all three local values.
         *
         * The modified component contains the new user-entered value.
         * The other two components retain their previous values.
         *
         * Example:
         *   Existing time : 18:30:45.
         *   User changes hour to 20.
         *   Updated time  : 20:30:45.
         */
        RTC_SetTime(h, m, s);


        /*
         * Clear the LCD before displaying the update confirmation.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Display confirmation that the RTC time has been updated.
         */
        StrLCD("TIME UPDATED");


        /*
         * Keep the confirmation message visible for approximately 700 ms.
         */
        delay_ms(700U);
    }
}


/*==============================================================================
 * FUNCTION NAME : EditDate
 *==============================================================================
 *
 * Description:
 *   Provides the menu for editing the RTC calendar date and day of week.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   void - Does not return any value.
 *
 * Menu Options:
 *   1 - Edit Date.
 *   2 - Edit Month.
 *   3 - Edit Year.
 *   4 - Edit Day of Week.
 *   5 - Exit Date Menu.
 *
 * Permitted Input Ranges:
 *   Date  : 1-31, followed by complete calendar validation.
 *   Month : 1-12.
 *   Year  : 1-4095.
 *   Day   : 0-6.
 *
 * Working:
 *   1. Reads the existing RTC calendar values.
 *   2. Displays the date-editing menu.
 *   3. Accepts the user's selection.
 *   4. Requests and validates the selected value.
 *   5. Checks the complete calendar date.
 *   6. Updates the RTC only when the complete date is valid.
 *
 * IMPORTANT:
 *   A date such as 31 February passes the basic date range check
 *   of 1-31 but fails the actual calendar validation.
 *
 *   RTC_DaysInMonth() is used to determine the valid number of days
 *   in the selected month and year.
 */
static void EditDate(void)
{
    /*
     * d      - Local day-of-month value.
     * m      - Local month value.
     * y      - Local calendar year.
     * dow    - Local day-of-week value.
     * choice - Stores the user's menu selection.
     */
    u32 d, m, y, dow, choice;


    /*
     * READ EXISTING RTC DATE AND DAY:
     *
     * Obtain the current calendar values from the RTC registers.
     *
     * DOM   - Day of Month register.
     * MONTH - Month register.
     * YEAR  - Year register.
     * DOW   - Day of Week register.
     *
     * These values are copied into local variables so that the user
     * can modify one field while preserving the other fields.
     *
     * Note:
     *   These identifiers must be available through the RTC header
     *   or the microcontroller register definitions.
     */

    /* Read existing date and day. */

    d   = DOM;
    m   = MONTH;
    y   = YEAR;
    dow = DOW;


    /*
     * Continue displaying the date menu until the user selects EXIT.
     */
    while(1)
    {

        /*
         * Execute background RTC, LDR and street-light operations.
         *
         * This keeps automatic street-light operation active
         * while the user is editing the calendar.
         */
        BackgroundTasks();


        /*
         * Clear the LCD before displaying the date menu.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first LCD line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Display the first three date menu options:
         *   1 - Date.
         *   2 - Month.
         *   3 - Year.
         */
        StrLCD("1.Dt 2.MON 3.Yr");


        /*
         * Move the cursor to the beginning of the second LCD line.
         */
        CmdLCD(GOTO_LINE2_POS0);


        /*
         * Display the remaining date menu options:
         *   4 - Day of week.
         *   5 - Exit.
         */
        StrLCD("4.DAY 5.EXIT");


        /*
         * MENU SELECTION:
         *
         * Accept a single numerical digit from the keypad.
         *
         * BackgroundTasks continues to execute during keypad input.
         */
        choice = ReadNumWithService(1U, BackgroundTasks);


        /*
         * Select the date field to be edited.
         */
        switch(choice)
        {

            /*
             * CASE 1:
             * Edit the day of the month.
             */
            case 1:

                /*
                 * Request the calendar date.
                 *
                 * Basic permitted range:
                 *   1 to 31.
                 *
                 * Maximum digits:
                 *   2.
                 *
                 * Additional validation against the actual month
                 * and year is performed later.
                 */
                d = ReadValueInRange("SET DATE 1-31",
                                     1U, 31U, 2U);

                break;


            /*
             * CASE 2:
             * Edit the calendar month.
             */
            case 2:

                /*
                 * Request the month value.
                 *
                 * Permitted range:
                 *   1 - January.
                 *   2 - February.
                 *   ...
                 *   12 - December.
                 *
                 * Maximum digits = 2.
                 */
                m = ReadValueInRange("SET MONTH 1-12",
                                     1U, 12U, 2U);

                break;


            /*
             * CASE 3:
             * Edit the calendar year.
             */
            case 3:

                /*
                 * Request the year value.
                 *
                 * Permitted range:
                 *   1 to 4095.
                 *
                 * Maximum digits = 4.
                 *
                 * The year range is selected according to the
                 * RTC application's supported configuration.
                 */
                y = ReadValueInRange("SET YEAR 1-4095",
                                     1U, 4095U, 4U);

                break;


            /*
             * CASE 4:
             * Edit the day of the week.
             */
            case 4:

                /*
                 * Request the weekday number.
                 *
                 * Configured mapping:
                 *   0 - Sunday.
                 *   1 - Monday.
                 *   2 - Tuesday.
                 *   3 - Wednesday.
                 *   4 - Thursday.
                 *   5 - Friday.
                 *   6 - Saturday.
                 *
                 * Maximum digits = 1.
                 *
                 * The mapping must match the convention used
                 * by the RTC driver.
                 */
                dow = ReadValueInRange("DAY 0SUN-6SAT",
                                       0U, 6U, 1U);

                break;


            /*
             * CASE 5:
             * Exit the date-editing menu.
             */
            case 5:

                /*
                 * SAVE ONLY A VALID COMPLETE DATE:
                 *
                 * Before updating the RTC, validate all calendar fields.
                 *
                 * Validation conditions:
                 *
                 *   d >= 1U:
                 *       Date must not be zero.
                 *
                 *   m >= 1U && m <= 12U:
                 *       Month must be between 1 and 12.
                 *
                 *   y >= 1U && y <= 4095U:
                 *       Year must be within the configured range.
                 *
                 *   d <= RTC_DaysInMonth(m, y):
                 *       Date must not exceed the actual number of
                 *       days in the selected month and year.
                 *
                 *   dow <= 6U:
                 *       Day-of-week value must be between 0 and 6.
                 *
                 * All conditions must be true before the RTC is updated.
                 */
                if(d >= 1U && m >= 1U && m <= 12U &&
                   y >= 1U && y <= 4095U &&
                   d <= RTC_DaysInMonth(m, y) &&
                   dow <= 6U)
                {

                    /*
                     * Update the RTC calendar date.
                     *
                     * Arguments:
                     *   d - Day of month.
                     *   m - Month.
                     *   y - Year.
                     */
                    RTC_SetDate(d, m, y);


                    /*
                     * Update the RTC day-of-week value.
                     *
                     * Argument:
                     *   dow - Day-of-week number.
                     */
                    RTC_SetDay(dow);
                }


                /*
                 * Clear the LCD before displaying the exit message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display the date-menu exit confirmation.
                 */
                StrLCD("EXIT D-MENU");


                /*
                 * Keep the exit message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Clear the LCD.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Return to the calling function.
                 *
                 * This exits the date-editing menu.
                 */
                return;


            /*
             * DEFAULT CASE:
             * Handles invalid date-menu selections.
             */
            default:

                /*
                 * Clear the LCD before displaying the error.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display the invalid menu selection message.
                 */
                StrLCD("INVALID OPTION");


                /*
                 * Keep the error message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Restart the date menu without executing
                 * the RTC update statements below.
                 */
                continue;
        }


        /*
         * COMPLETE CALENDAR VALIDATION:
         *
         * Validate the complete date after the user modifies
         * any one of its fields.
         *
         * This prevents the RTC from being updated with an
         * impossible calendar date.
         *
         * Example:
         *   Date  = 31.
         *   Month = 2.
         *   Year  = 2026.
         *
         * Since February 2026 has fewer than 31 days,
         * the date is rejected.
         */
        if(d >= 1U && m >= 1U && m <= 12U &&
           y >= 1U && y <= 4095U &&
           d <= RTC_DaysInMonth(m, y) &&
           dow <= 6U)
        {

            /*
             * Update the RTC date after successful validation.
             */
            RTC_SetDate(d, m, y);


            /*
             * Update the RTC weekday value after successful validation.
             */
            RTC_SetDay(dow);


            /*
             * Clear the LCD before displaying the confirmation.
             */
            CmdLCD(CLEAR_LCD);


            /*
             * Inform the user that the date has been updated.
             */
            StrLCD("DATE UPDATED");
        }
        else
        {

            /*
             * Clear the LCD before displaying the invalid-date message.
             */
            CmdLCD(CLEAR_LCD);


            /*
             * Inform the user that the complete calendar date
             * is not valid.
             */
            StrLCD("INVALID DATE");
        }


        /*
         * Keep the status message visible for approximately 700 ms
         * before displaying the date menu again.
         */
        delay_ms(700U);
    }
}


/*==============================================================================
 * FUNCTION NAME : EditBoundaries
 *==============================================================================
 *
 * Description:
 *   Provides the menu for modifying the street-light operating
 *   start and end time boundaries.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   void - Does not return any value.
 *
 * Menu Options:
 *   1 - Edit Start Hour.
 *   2 - Edit Start Minute.
 *   3 - Edit End Hour.
 *   4 - Edit End Minute.
 *   5 - Exit Boundary Menu.
 *
 * Permitted Input Ranges:
 *   Start Hour : 0-23.
 *   Start Min  : 0-59.
 *   End Hour   : 0-23.
 *   End Min    : 0-59.
 *
 * Working:
 *   1. Reads the existing street-light boundaries.
 *   2. Displays the boundary configuration menu.
 *   3. Accepts a one-digit menu selection.
 *   4. Requests the selected boundary value.
 *   5. Validates the entered value.
 *   6. Checks that the start and end times are not identical.
 *   7. Updates the global boundary variables when validation succeeds.
 *
 * IMPORTANT:
 *   Boundary values are stored as hour and minute components.
 *   They are converted into total minutes for the equality check.
 */
static void EditBoundaries(void)
{
    /*
     * sh - Local street-light start hour.
     * sm - Local street-light start minute.
     * eh - Local street-light end hour.
     * em - Local street-light end minute.
     *
     * choice - Stores the user's boundary-menu selection.
     */
    u32 sh, sm, eh, em, choice;


    /*
     * READ EXISTING BOUNDARY VALUES:
     *
     * Copy the currently configured global boundary values
     * into local variables.
     *
     * This allows the user to modify one component while
     * preserving the remaining boundary values.
     */

    /* Read existing boundary values. */

    sh = start_hour;
    sm = start_min;

    eh = end_hour;
    em = end_min;


    /*
     * Continue displaying the boundary menu until the user exits.
     */
    while(1)
    {

        /*
         * Execute background RTC, LDR and street-light operations.
         *
         * This helps maintain automatic street-light operation
         * while the user modifies the operating boundaries.
         */
        BackgroundTasks();


        /*
         * Clear the LCD before displaying the boundary menu.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first LCD line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Display the start-hour and start-minute options.
         *
         * 1 - Start Hour.
         * 2 - Start Minute.
         */
        StrLCD("1.S-H 2.S-M");


        /*
         * Move the cursor to the beginning of the second LCD line.
         */
        CmdLCD(GOTO_LINE2_POS0);


        /*
         * Display the end-hour, end-minute and exit options.
         *
         * 3 - End Hour.
         * 4 - End Minute.
         * 5 - Exit.
         */
        StrLCD("3.E-H 4.E-M 5.Ex");


        /*
         * MENU SELECTION:
         *
         * Read a single numerical digit from the keypad.
         *
         * BackgroundTasks continues to execute during input.
         */
        choice = ReadNumWithService(1U, BackgroundTasks);


        /*
         * Select the boundary parameter to modify.
         */
        switch(choice)
        {

            /*
             * CASE 1:
             * Edit street-light start hour.
             */
            case 1:

                /*
                 * Request the hour at which the street-light
                 * operating schedule should begin.
                 *
                 * Permitted range:
                 *   0 to 23.
                 *
                 * Maximum digits:
                 *   2.
                 */
                sh = ReadValueInRange("ON HOUR 0-23",
                                      0U, 23U, 2U);

                break;


            /*
             * CASE 2:
             * Edit street-light start minute.
             */
            case 2:

                /*
                 * Request the start minute.
                 *
                 * Permitted range:
                 *   0 to 59.
                 *
                 * Maximum digits:
                 *   2.
                 */
                sm = ReadValueInRange("ON MIN 0-59",
                                      0U, 59U, 2U);

                break;


            /*
             * CASE 3:
             * Edit street-light end hour.
             */
            case 3:

                /*
                 * Request the hour at which the street-light
                 * operating schedule should end.
                 *
                 * Permitted range:
                 *   0 to 23.
                 *
                 * Maximum digits:
                 *   2.
                 */
                eh = ReadValueInRange("OFF HOUR 0-23",
                                      0U, 23U, 2U);

                break;


            /*
             * CASE 4:
             * Edit street-light end minute.
             */
            case 4:

                /*
                 * Request the end minute.
                 *
                 * Permitted range:
                 *   0 to 59.
                 *
                 * Maximum digits:
                 *   2.
                 */
                em = ReadValueInRange("OFF MIN 0-59",
                                      0U, 59U, 2U);

                break;


            /*
             * CASE 5:
             * Exit the boundary configuration menu.
             */
            case 5:

                /*
                 * Clear the LCD before displaying the exit message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display the boundary-menu exit confirmation.
                 */
                StrLCD("EXIT B-MENU");


                /*
                 * Keep the exit message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Clear the LCD after displaying the message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Return to the calling function.
                 */
                return;


            /*
             * DEFAULT CASE:
             * Handles all invalid boundary-menu selections.
             */
            default:

                /*
                 * Clear the LCD.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display an invalid-option message.
                 */
                StrLCD("INVALID OPTION");


                /*
                 * Keep the message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Restart the boundary menu without updating
                 * the global boundary variables.
                 */
                continue;
        }


        /*
         * VALIDATE STREET-LIGHT BOUNDARIES:
         *
         * Check whether all four local boundary values are valid.
         *
         * Conditions:
         *
         *   sh <= 23U:
         *       Start hour must be within 0-23.
         *
         *   eh <= 23U:
         *       End hour must be within 0-23.
         *
         *   sm <= 59U:
         *       Start minute must be within 0-59.
         *
         *   em <= 59U:
         *       End minute must be within 0-59.
         *
         *   ((sh * 60U + sm) != (eh * 60U + em)):
         *       Start and end times must not represent the same
         *       time of day.
         *
         * TIME-TO-MINUTES CONVERSION:
         *
         *   Total minutes = (Hour * 60) + Minute.
         *
         * Example:
         *   Start time = 18:30.
         *
         *   Total minutes = (18 * 60) + 30
         *                 = 1110.
         *
         *   This makes it possible to compare two times
         *   using a single numerical value.
         */
        if(sh <= 23U && eh <= 23U &&
           sm <= 59U && em <= 59U &&
           ((sh * 60U + sm) != (eh * 60U + em)))
        {

            /*
             * UPDATE GLOBAL START BOUNDARY:
             *
             * Store the validated local start-hour value
             * in the global street-light configuration variable.
             */
            start_hour = sh;


            /*
             * Store the validated local start-minute value
             * in the global street-light configuration variable.
             */
            start_min  = sm;


            /*
             * UPDATE GLOBAL END BOUNDARY:
             *
             * Store the validated local end-hour value.
             */
            end_hour = eh;


            /*
             * Store the validated local end-minute value.
             */
            end_min  = em;


            /*
             * Clear the LCD before displaying the confirmation.
             */
            CmdLCD(CLEAR_LCD);


            /*
             * Inform the user that the new street-light boundaries
             * have been accepted and saved in the global variables.
             */
            StrLCD("BOUNDARY SAVED");
        }
        else
        {

            /*
             * INVALID BOUNDARY HANDLING:
             *
             * Executed when one or more boundary values are invalid
             * or when the start and end times are identical.
             *
             * The global boundary variables are not updated in this
             * branch, so the previous valid configuration is retained.
             */


            /*
             * Clear the LCD before displaying the error message.
             */
            CmdLCD(CLEAR_LCD);


            /*
             * Display the invalid-boundary message.
             */
            StrLCD("INVALID BOUNDARY");
        }


        /*
         * Keep the success or error message visible for approximately
         * 700 ms before displaying the boundary menu again.
         */
        delay_ms(700U);
    }
}


/*==============================================================================
 * FUNCTION NAME : RTC_Edit_Menu
 *==============================================================================
 *
 * Description:
 *   Implements the main RTC/settings menu of the Adaptive Street
 *   Light Control System.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   void - Does not return any value.
 *
 * MAIN MENU OPTIONS:
 *   1 - Edit RTC Time.
 *   2 - Edit RTC Date.
 *   3 - Edit Street-Light Boundaries.
 *   4 - Exit Main Menu.
 *
 * Working:
 *   1. Executes background operations.
 *   2. Displays the main configuration menu.
 *   3. Accepts a one-digit menu selection.
 *   4. Calls the corresponding submenu.
 *   5. Handles invalid menu selections.
 *   6. Returns to the main application when the user exits.
 *
 * APPLICATION INTEGRATION:
 *   This function is called by the main application after an EINT0
 *   menu request is detected.
 *
 *   After this function returns, control goes back to the main()
 *   application loop.
 */
void RTC_Edit_Menu(void)
{
    /*
     * Stores the numerical option selected by the user.
     *
     * The value is obtained from the matrix keypad.
     */
    u32 choice;


    /*
     * Main menu loop.
     *
     * Continues displaying the menu until the user selects
     * option 4 to exit.
     */
    while(1)
    {

        /*
         * Execute background operations before displaying
         * the main menu.
         *
         * This keeps the RTC, LDR and street-light control
         * functions active while the menu is being used.
         */
        BackgroundTasks();


        /*
         * Clear the LCD before displaying the main menu.
         */
        CmdLCD(CLEAR_LCD);


        /*
         * Position the cursor at the beginning of the first line.
         */
        CmdLCD(GOTO_LINE1_POS0);


        /*
         * Display the first two main menu options:
         *
         *   1 - TIME.
         *   2 - DATE.
         */
        StrLCD("1.TIME 2.DATE");


        /*
         * Move the cursor to the beginning of the second LCD line.
         */
        CmdLCD(GOTO_LINE2_POS0);


        /*
         * Display the remaining main menu options:
         *
         *   3 - BOUNDARY CONFIGURATION.
         *   4 - EXIT.
         */
        StrLCD("3.BOUND 4.EXIT");


        /*
         * MAIN MENU INPUT:
         *
         * Accept a single-digit menu selection.
         *
         * Maximum digits = 1U.
         *
         * BackgroundTasks is executed while the keypad input
         * function waits for the user's selection.
         */
        choice = ReadNumWithService(1U, BackgroundTasks);


        /*
         * Execute the operation corresponding to the user's selection.
         */
        switch(choice)
        {

            /*
             * CASE 1:
             * Enter the RTC time-editing submenu.
             */
            case 1:

                /*
                 * Call EditTime() to modify hour, minute or second.
                 *
                 * When EditTime() returns, execution continues
                 * from the next statement in this main menu loop.
                 */
                EditTime();

                break;


            /*
             * CASE 2:
             * Enter the RTC date-editing submenu.
             */
            case 2:

                /*
                 * Call EditDate() to modify date, month, year
                 * or day of the week.
                 */
                EditDate();

                break;


            /*
             * CASE 3:
             * Enter the street-light boundary configuration submenu.
             */
            case 3:

                /*
                 * Call EditBoundaries() to modify the operating
                 * start and end time boundaries.
                 */
                EditBoundaries();

                break;


            /*
             * CASE 4:
             * Exit the complete RTC/settings menu.
             */
            case 4:

                /*
                 * Clear the LCD before displaying the exit message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display the main-menu exit confirmation.
                 */
                StrLCD("EXIT MENU");


                /*
                 * Keep the exit message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * Clear the LCD after displaying the exit message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Return from RTC_Edit_Menu().
                 *
                 * Control returns to main(), where the normal
                 * monitoring and street-light control loop continues.
                 */
                return;


            /*
             * DEFAULT CASE:
             * Handles all invalid main-menu selections.
             */
            default:

                /*
                 * Clear the LCD before displaying the error message.
                 */
                CmdLCD(CLEAR_LCD);


                /*
                 * Display an invalid-option message.
                 */
                StrLCD("INVALID OPTION");


                /*
                 * Keep the error message visible for approximately 700 ms.
                 */
                delay_ms(700U);


                /*
                 * The break statement exits the switch statement.
                 *
                 * The surrounding while loop then starts another
                 * main-menu iteration.
                 */
                break;
        }
    }
}
```