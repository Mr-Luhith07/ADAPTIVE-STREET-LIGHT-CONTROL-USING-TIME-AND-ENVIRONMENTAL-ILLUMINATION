```c
/*
 *==============================================================================
 * File Name   : kpm_defines.h
 * Module Name : 4x4 Matrix Keypad - Hardware Definitions
 * Controller  : LPC2148
 *
 * Description:
 *   This header file contains the hardware-specific pin definitions required
 *   for interfacing a 4x4 matrix keypad with the LPC2148 microcontroller.
 *
 *   It defines the GPIO pin numbers assigned to the four keypad row lines
 *   and four keypad column lines.
 *
 * Hardware Port:
 *   GPIO Port 1 (P1)
 *
 * Pin Configuration:
 *
 *   ROW LINES:
 *       ROW0 -> P1.16
 *       ROW1 -> P1.17
 *       ROW2 -> P1.18
 *       ROW3 -> P1.19
 *
 *   COLUMN LINES:
 *       COL0 -> P1.20
 *       COL1 -> P1.21
 *       COL2 -> P1.22
 *       COL3 -> P1.23
 *
 * GPIO Direction:
 *   - Row pins    : Output pins.
 *   - Column pins : Input pins.
 *
 * Functional Purpose:
 *   These macros provide meaningful symbolic names for the keypad GPIO pins.
 *   They avoid repeatedly using numerical pin positions throughout the
 *   keypad driver source code.
 *
 *   For example:
 *       (1U << ROW0)
 *
 *   Instead of writing:
 *       (1U << 16)
 *
 *   This improves code readability, maintainability and hardware portability.
 *
 *==============================================================================
 */


/*------------------------------------------------------------------------------
 * HEADER GUARD
 *
 * Purpose:
 *   Prevents multiple inclusion of this header file within the same
 *   compilation unit.
 *
 * Working:
 *   1. Checks whether KPM_DEFINES_H has already been defined.
 *   2. If not defined, the header contents are processed.
 *   3. Defines KPM_DEFINES_H to indicate that this file has been included.
 *   4. Subsequent inclusions skip the protected contents.
 *
 * Importance:
 *   Prevents repeated macro definitions and protects the header against
 *   multiple-inclusion problems.
 *------------------------------------------------------------------------------*/

#ifndef KPM_DEFINES_H
#define KPM_DEFINES_H


/*------------------------------------------------------------------------------
 * KEYPAD ROW PIN DEFINITIONS
 *
 * Description:
 *   Defines the GPIO Port 1 pin numbers connected to the four row lines
 *   of the 4x4 matrix keypad.
 *
 * Configuration:
 *   All four row pins are configured as GPIO outputs by InitKPM().
 *
 * Working:
 *   During keypad scanning, the software activates one row at a time
 *   by driving its output LOW while keeping the other rows HIGH.
 *
 * Bit Numbering:
 *   The numerical value represents the GPIO bit position within IODIR1,
 *   IOPIN1, IOSET1 and IOCLR1.
 *------------------------------------------------------------------------------*/


/* ROW0:
 *   Assigns keypad row 0 to GPIO pin P1.16.
 *
 *   Used to select the first row during keypad scanning.
 *
 *   16U represents bit position 16.
 *   The U suffix specifies an unsigned integer constant.
 */
#define ROW0 16U       /* P1.16 */


/* ROW1:
 *   Assigns keypad row 1 to GPIO pin P1.17.
 *
 *   Used to select the second row during keypad scanning.
 *
 *   17U represents bit position 17.
 */
#define ROW1 17U       /* P1.17 */


/* ROW2:
 *   Assigns keypad row 2 to GPIO pin P1.18.
 *
 *   Used to select the third row during keypad scanning.
 *
 *   18U represents bit position 18.
 */
#define ROW2 18U       /* P1.18 */


/* ROW3:
 *   Assigns keypad row 3 to GPIO pin P1.19.
 *
 *   Used to select the fourth row during keypad scanning.
 *
 *   19U represents bit position 19.
 */
#define ROW3 19U       /* P1.19 */


/*------------------------------------------------------------------------------
 * KEYPAD COLUMN PIN DEFINITIONS
 *
 * Description:
 *   Defines the GPIO Port 1 pin numbers connected to the four column lines
 *   of the 4x4 matrix keypad.
 *
 * Configuration:
 *   All four column pins are configured as GPIO inputs by InitKPM().
 *
 * Working:
 *   During keypad scanning, the software monitors these input pins.
 *
 *   When a pressed key connects an activated LOW row to a column,
 *   the corresponding column input becomes LOW.
 *
 *   The driver identifies the pressed column by reading IOPIN1.
 *
 * Electrical Requirement:
 *   The column inputs must have appropriate pull-up arrangements so that
 *   unpressed column inputs remain HIGH.
 *------------------------------------------------------------------------------*/


/* COL0:
 *   Assigns keypad column 0 to GPIO pin P1.20.
 *
 *   Used to detect a pressed key in the first column.
 *
 *   20U represents bit position 20.
 */
#define COL0 20U       /* P1.20 */


/* COL1:
 *   Assigns keypad column 1 to GPIO pin P1.21.
 *
 *   Used to detect a pressed key in the second column.
 *
 *   21U represents bit position 21.
 */
#define COL1 21U       /* P1.21 */


/* COL2:
 *   Assigns keypad column 2 to GPIO pin P1.22.
 *
 *   Used to detect a pressed key in the third column.
 *
 *   22U represents bit position 22.
 */
#define COL2 22U       /* P1.22 */


/* COL3:
 *   Assigns keypad column 3 to GPIO pin P1.23.
 *
 *   Used to detect a pressed key in the fourth column.
 *
 *   23U represents bit position 23.
 */
#define COL3 23U       /* P1.23 */


/*------------------------------------------------------------------------------
 * END OF HEADER GUARD
 *
 * Closes the conditional compilation block opened by #ifndef.
 *
 * This completes the keypad hardware pin definition section.
 *------------------------------------------------------------------------------*/

#endif


/*
 *==============================================================================
 * END OF FILE : kpm_defines.h
 *
 * HARDWARE CONFIGURATION SUMMARY:
 *
 *   Microcontroller : LPC2148
 *   GPIO Port       : Port 1
 *
 *   Row outputs:
 *       P1.16 -> ROW0
 *       P1.17 -> ROW1
 *       P1.18 -> ROW2
 *       P1.19 -> ROW3
 *
 *   Column inputs:
 *       P1.20 -> COL0
 *       P1.21 -> COL1
 *       P1.22 -> COL2
 *       P1.23 -> COL3
 *
 *   Total GPIO pins used: 8
 *
 *==============================================================================
 */
```