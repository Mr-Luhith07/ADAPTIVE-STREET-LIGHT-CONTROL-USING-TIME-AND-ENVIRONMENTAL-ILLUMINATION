
/*******************************************************************************
 * FILE NAME    : types.h
 *
 * MODULE       : Project Data Type Definitions
 *
 * DESCRIPTION  :
 *                This header file defines project-specific aliases for
 *                fundamental C data types.
 *
 *                These aliases provide a consistent naming convention
 *                for integer and floating-point variables throughout
 *                the embedded application.
 *
 * PURPOSE      :
 *                1. Improves code readability.
 *                2. Establishes a common data type naming convention.
 *                3. Simplifies maintenance of embedded software.
 *                4. Makes variable declarations easier to understand.
 *                5. Provides a centralized location for project data types.
 *
 * DATA TYPES PROVIDED :
 *
 *                u32 - Unsigned integer type.
 *                u16 - Unsigned short integer type.
 *                u8  - Unsigned character type.
 *                s32 - Signed integer type.
 *                s8  - Signed character type.
 *                f32 - Floating-point type.
 *
 * TARGET MCU   : LPC2148 (ARM7TDMI-S)
 *
 * LANGUAGE     : Embedded C
 *
 * DEPENDENCIES : Standard C compiler data type definitions.
 *
 * NOTE         :
 *                The actual bit width of these aliases depends on the
 *                C implementation and compiler.
 *
 *******************************************************************************/


#ifndef TYPES_H
/*
 * HEADER GUARD - BEGINNING
 *
 * Checks whether the TYPES_H macro has already been defined.
 *
 * If it has not been defined, the preprocessor processes the
 * declarations present in this header file.
 *
 * This prevents multiple inclusion of types.h within the same
 * compilation unit.
 *
 * It avoids potential duplicate declaration and redefinition
 * problems when multiple driver header files include types.h.
 */
#define TYPES_H


/*******************************************************************************
 * TYPE DEFINITION : u32
 *
 * DESCRIPTION :
 *                Defines u32 as an alias for unsigned int.
 *
 * PURPOSE :
 *                Used for storing non-negative integer values such as
 *                counters, register configurations, timer values,
 *                arithmetic results, and peripheral data.
 *
 * SIGNEDNESS :
 *                Unsigned - Cannot represent negative values.
 *
 * TYPICAL SIZE :
 *                32 bits on the LPC2148 ARM7 compiler toolchain.
 *
 * VALUE RANGE ON LPC2148 :
 *                0 to 4,294,967,295.
 *
 * EXAMPLE :
 *                u32 frequency = 60000000U;
 *
 * NOTE :
 *                ISO C does not guarantee that unsigned int is always
 *                exactly 32 bits. Verify the compiler's data model.
 *******************************************************************************/
typedef unsigned int u32;


/*******************************************************************************
 * TYPE DEFINITION : u16
 *
 * DESCRIPTION :
 *                Defines u16 as an alias for unsigned short int.
 *
 * PURPOSE :
 *                Used for storing non-negative integer values that
 *                require a 16-bit representation on the target compiler.
 *
 * TYPICAL APPLICATIONS :
 *                - ADC conversion values.
 *                - Smaller counters.
 *                - Sensor measurement values.
 *                - 16-bit data fields.
 *                - Peripheral configuration values.
 *
 * SIGNEDNESS :
 *                Unsigned - Cannot represent negative values.
 *
 * TYPICAL SIZE :
 *                16 bits on the LPC2148 ARM7 compiler toolchain.
 *
 * VALUE RANGE ON LPC2148 :
 *                0 to 65,535.
 *
 * EXAMPLE :
 *                u16 adc_value = 1023U;
 *
 * NOTE :
 *                Confirm the width using the compiler documentation
 *                or sizeof operator.
 *******************************************************************************/
typedef unsigned short int u16;


/*******************************************************************************
 * TYPE DEFINITION : u8
 *
 * DESCRIPTION :
 *                Defines u8 as an alias for unsigned char.
 *
 * PURPOSE :
 *                Used for storing small non-negative integer values
 *                and individual byte-sized data.
 *
 * TYPICAL APPLICATIONS :
 *                - LCD character data.
 *                - Keypad key values.
 *                - Boolean-style status flags.
 *                - Single-byte sensor data.
 *                - Communication buffers.
 *                - Bitwise operations.
 *
 * SIGNEDNESS :
 *                Unsigned - Cannot represent negative values.
 *
 * SIZE :
 *                Exactly 8 bits because CHAR_BIT is 8 on the target.
 *
 * VALUE RANGE :
 *                0 to 255.
 *
 * EXAMPLE :
 *                u8 ldrDark = 1U;
 *
 *                1U - Darkness detected.
 *                0U - Darkness not detected.
 *
 * NOTE :
 *                In C, unsigned char is guaranteed to occupy one byte.
 *                The LPC2148 toolchain uses 8-bit bytes.
 *******************************************************************************/
typedef unsigned char u8;


/*******************************************************************************
 * TYPE DEFINITION : s32
 *
 * DESCRIPTION :
 *                Defines s32 as an alias for signed int.
 *
 * PURPOSE :
 *                Used for storing both positive and negative integer values.
 *
 * TYPICAL APPLICATIONS :
 *                - Signed arithmetic calculations.
 *                - Positive and negative offsets.
 *                - Error calculations.
 *                - Sensor calibration values.
 *                - Mathematical expressions requiring negative values.
 *
 * SIGNEDNESS :
 *                Signed - Can represent both positive and negative values.
 *
 * TYPICAL SIZE :
 *                32 bits on the LPC2148 ARM7 compiler toolchain.
 *
 * VALUE RANGE :
 *                -2,147,483,648 to 2,147,483,647.
 *
 * EXAMPLE :
 *                s32 temperature_offset = -10;
 *
 * NOTE :
 *                The exact width must be verified for the target compiler.
 *******************************************************************************/
typedef int s32;


/*******************************************************************************
 * TYPE DEFINITION : s8
 *
 * DESCRIPTION :
 *                Defines s8 as an alias for char.
 *
 * PURPOSE :
 *                Used for storing signed character-sized values when
 *                the target compiler implements plain char as signed.
 *
 * TYPICAL APPLICATIONS :
 *                - Small signed values.
 *                - Character processing.
 *                - Signed byte calculations.
 *
 * TYPICAL SIZE :
 *                8 bits on the LPC2148 ARM7 compiler toolchain.
 *
 * TYPICAL VALUE RANGE :
 *                -128 to 127 when char is signed.
 *
 * IMPORTANT NOTE :
 *                Unlike signed char, plain char can be either signed
 *                or unsigned depending on the compiler implementation.
 *
 *                Therefore, this typedef does not strictly guarantee
 *                signed 8-bit behaviour on every compiler.
 *
 * EXAMPLE :
 *                s8 correction = -5;
 *
 * RECOMMENDATION :
 *                For guaranteed signed 8-bit behaviour across
 *                implementations, signed char or int8_t may be used.
 *******************************************************************************/
typedef char s8;


/*******************************************************************************
 * TYPE DEFINITION : f32
 *
 * DESCRIPTION :
 *                Defines f32 as an alias for float.
 *
 * PURPOSE :
 *                Used for storing floating-point values that require
 *                fractional or decimal precision.
 *
 * TYPICAL APPLICATIONS :
 *                - Sensor calibration calculations.
 *                - Voltage and current calculations.
 *                - ADC voltage conversions.
 *                - Mathematical calculations involving fractions.
 *                - Physical parameter measurements.
 *
 * DATA REPRESENTATION :
 *                Typically IEEE 754 single-precision floating-point
 *                representation on the ARM7 toolchain.
 *
 * TYPICAL SIZE :
 *                32 bits on the LPC2148 ARM7 compiler toolchain.
 *
 * EXAMPLE :
 *                f32 sensor_voltage = 3.30f;
 *
 * NOTE :
 *                Floating-point operations may require additional
 *                execution time and code space compared with integer
 *                arithmetic on embedded processors.
 *
 *                Consider fixed-point arithmetic when performance,
 *                memory, or deterministic execution time is critical.
 *******************************************************************************/
typedef float f32;


/*
 * HEADER GUARD - ENDING
 *
 * Marks the end of the TYPES_H conditional compilation block.
 *
 * Prevents repeated processing of the type definitions if this
 * header file is included multiple times.
 */
#endif


/*******************************************************************************
 * END OF FILE : types.h
 *
 * TYPE DEFINITION SUMMARY :
 *
 *                u32 - Unsigned integer.
 *                u16 - Unsigned short integer.
 *                u8  - Unsigned character.
 *                s32 - Signed integer.
 *                s8  - Character type (signedness compiler-dependent).
 *                f32 - Floating-point type.
 *
 *                These aliases are shared across the project to maintain
 *                a consistent data type naming convention.
 *
 *******************************************************************************/
