```c
/*
 * File Name   : delay.h
 * Description : Header file for software delay routines used in
 *               the LPC2148 embedded application.
 *
 * Purpose:
 * This header file provides the function declarations required
 * to generate approximate software delays in different time units.
 *
 * Available Delay Functions:
 *
 * 1. delay_us() : Generates a delay in microseconds.
 * 2. delay_ms() : Generates a delay in milliseconds.
 * 3. delay_s()  : Generates a delay in seconds.
 *
 * Functional Overview:
 * The delay routines use software-based counting loops to consume
 * processor execution cycles and generate approximate time intervals.
 *
 * Usage:
 * Include this header file in application modules or peripheral
 * drivers that require software-based timing delays.
 *
 * Implementation:
 * The corresponding function definitions are available in delay.c.
 *
 * Design Considerations:
 * 1. These functions generate blocking software delays.
 * 2. Their timing accuracy depends on processor clock frequency,
 *    compiler optimization and generated machine instructions.
 * 3. They are intended for approximate timing requirements.
 * 4. Hardware timers should be preferred for accurate timing operations.
 */


/*
 * Header Guard:
 *
 * Prevents multiple inclusions of this header file within the
 * same compilation unit.
 *
 * During the first inclusion, DELAY_H is defined and the contents
 * of this header file are processed by the compiler.
 *
 * During subsequent inclusions, the preprocessor skips the protected
 * section, preventing repeated declarations.
 */

#ifndef DELAY_H
#define DELAY_H


/*
 * Include user-defined data types.
 *
 * Provides the u32 (unsigned 32-bit integer) data type used
 * in the delay function parameters.
 *
 * Using a fixed-width project-specific data type helps maintain
 * consistency across the embedded software modules.
 */

#include "types.h"


/*
 * Function Name : delay_us
 *
 * Description:
 * Generates an approximate software delay for the specified
 * duration in microseconds.
 *
 * Parameter:
 * dlyUS : Requested delay duration in microseconds.
 *
 * Data Type:
 * u32 : Unsigned 32-bit integer representing the delay count.
 *
 * Return Type:
 * void : Does not return any value.
 *
 * Implementation:
 * The function uses nested software counting loops to consume
 * processor execution cycles.
 *
 * Usage Example:
 * delay_us(100U);
 *
 * Note:
 * Actual execution time depends on the processor clock,
 * compiler settings and generated machine instructions.
 */

void delay_us(u32 dlyUS);


/*
 * Function Name : delay_ms
 *
 * Description:
 * Generates an approximate software delay for the specified
 * duration in milliseconds.
 *
 * Parameter:
 * dlyMS : Requested delay duration in milliseconds.
 *
 * Data Type:
 * u32 : Unsigned 32-bit integer representing the delay count.
 *
 * Return Type:
 * void : Does not return any value.
 *
 * Implementation:
 * The function internally reuses delay_us() by requesting
 * 1000 microseconds for each millisecond iteration.
 *
 * Time Conversion:
 * 1 millisecond = 1000 microseconds.
 *
 * Usage Example:
 * delay_ms(10U);
 *
 * Note:
 * This is a blocking software delay and does not guarantee
 * an exact millisecond timing interval.
 */

void delay_ms(u32 dlyMS);


/*
 * Function Name : delay_s
 *
 * Description:
 * Generates an approximate software delay for the specified
 * duration in seconds.
 *
 * Parameter:
 * dlyS : Requested delay duration in seconds.
 *
 * Data Type:
 * u32 : Unsigned 32-bit integer representing the delay count.
 *
 * Return Type:
 * void : Does not return any value.
 *
 * Implementation:
 * The function internally reuses delay_ms() by requesting
 * 1000 milliseconds for each second iteration.
 *
 * Time Conversion:
 * 1 second = 1000 milliseconds.
 *
 * Usage Example:
 * delay_s(2U);
 *
 * Note:
 * This function occupies the processor during execution.
 * It should not be used for timing-critical operations
 * or applications requiring continuous peripheral monitoring.
 */

void delay_s(u32 dlyS);


/*
 * End of DELAY_H header guard.
 *
 * Marks the end of the protected header-file section.
 * Prevents repeated inclusion of delay function declarations.
 */

#endif
```