```c
/*
 *==============================================================================
 * File Name    : lcd.h
 * Module Name  : LCD Interface Header File
 * Target MCU   : LPC2148
 * Display      : HD44780-Compatible Character LCD
 * Interface    : 8-Bit Parallel Interface
 *
 * Hardware Connections:
 *   LCD Data Pins  D0-D7  -> P0.8  - P0.15
 *   LCD RS Pin            -> P0.4
 *   LCD EN Pin            -> P0.17
 *   LCD RW Pin            -> P0.18
 *
 * Description:
 *   This header file provides the function declarations required to
 *   interface an 8-bit character LCD with the LPC2148 microcontroller.
 *
 *   It acts as the public interface between the LCD driver implementation
 *   (lcd.c) and other application modules that need to display information.
 *
 *   The functions declared in this file support:
 *     1. Sending commands to the LCD.
 *     2. Displaying individual characters.
 *     3. Displaying null-terminated strings.
 *     4. Displaying unsigned and signed integer values.
 *     5. Displaying floating-point values with a specified decimal precision.
 *     6. Creating custom characters using the LCD CGRAM.
 *
 * Dependencies:
 *   types.h - Provides user-defined data types such as u8, s8, u32, s32 and f32.
 *
 *==============================================================================
 */


/*==============================================================================
 * HEADER GUARD
 *==============================================================================
 *
 * The header guard prevents this file from being included multiple times
 * during the same compilation unit.
 *
 * First inclusion:
 *   LCD_H is not defined, so the compiler defines it and processes the file.
 *
 * Subsequent inclusions:
 *   LCD_H is already defined, so the declarations are skipped.
 *
 * This prevents duplicate declaration-related compilation problems.
 */

#ifndef LCD_H
#define LCD_H


/*==============================================================================
 * DEPENDENCY HEADER
 *==============================================================================
 *
 * Includes the project-specific data type definitions.
 *
 * The LCD driver uses:
 *   u8  - 8-bit unsigned integer.
 *   s8  - 8-bit signed integer.
 *   u32 - 32-bit unsigned integer.
 *   s32 - 32-bit signed integer.
 *   f32 - 32-bit floating-point type.
 *
 * These types must be defined in types.h before they are used below.
 */

#include "types.h"


/*==============================================================================
 * LCD FUNCTION DECLARATIONS
 *==============================================================================
 *
 * These are function prototypes for the LCD driver functions implemented
 * in lcd.c.
 *
 * They inform the compiler about each function's name, return type and
 * parameter types before the functions are called by other source files.
 */


/*
 * Function Name : WriteLCD
 *
 * Description:
 *   Sends an 8-bit data value to the LCD through its 8-bit parallel data bus.
 *
 * Parameter:
 *   dat - 8-bit value to be transferred to the LCD.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Note:
 *   The LCD RS signal must be configured by the calling function to select
 *   either the instruction register or the data register.
 *
 *   RS = 0 : Command/instruction transfer.
 *   RS = 1 : Character/data transfer.
 */
void WriteLCD(u8 dat);


/*
 * Function Name : CmdLCD
 *
 * Description:
 *   Sends a command or instruction to the LCD controller.
 *
 * Parameter:
 *   cmd - 8-bit LCD instruction.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Examples:
 *   Clear display, configure display mode, position the cursor and
 *   configure the LCD entry mode.
 *
 * Note:
 *   The function selects the LCD instruction register before transferring
 *   the command.
 */
void CmdLCD(u8 cmd);


/*
 * Function Name : CharLCD
 *
 * Description:
 *   Displays a single character at the current LCD cursor position.
 *
 * Parameter:
 *   asciiVal - ASCII value of the character to be displayed.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Note:
 *   The function selects the LCD data register before transferring
 *   the character.
 *
 * Example:
 *   CharLCD('A');
 *
 *   Displays the character A at the current cursor position.
 */
void CharLCD(u8 asciiVal);


/*
 * Function Name : InitLCD
 *
 * Description:
 *   Initializes the LCD hardware and configures the LCD controller
 *   for the required operating mode.
 *
 * Parameter:
 *   void - No input parameters.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Typical Initialization Operations:
 *   1. Configures LCD data and control pins as GPIO outputs.
 *   2. Waits for the LCD power-on initialization period.
 *   3. Performs the required LCD initialization sequence.
 *   4. Configures the LCD for 8-bit, two-line operation.
 *   5. Enables the display and configures cursor visibility.
 *   6. Clears the display.
 *   7. Configures cursor movement.
 *
 * Note:
 *   This function should be called before using the other LCD functions.
 */
void InitLCD(void);


/*
 * Function Name : StrLCD
 *
 * Description:
 *   Displays a complete null-terminated string on the LCD.
 *
 * Parameter:
 *   s - Pointer to the first character of the string to be displayed.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Working:
 *   The function reads characters sequentially from the supplied memory
 *   address and displays them until the null terminator ('\0') is reached.
 *
 * Example:
 *   StrLCD("WELCOME");
 *
 *   Displays WELCOME on the LCD.
 *
 * Note:
 *   The input string must be valid and null-terminated.
 */
void StrLCD(s8 *s);


/*
 * Function Name : U32LCD
 *
 * Description:
 *   Converts and displays an unsigned 32-bit integer on the LCD.
 *
 * Parameter:
 *   n - Unsigned 32-bit integer value to be displayed.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Working:
 *   The integer is converted into individual decimal digits.
 *   Each digit is converted into its corresponding ASCII character
 *   and displayed on the LCD.
 *
 * Example:
 *   U32LCD(12345);
 *
 *   Displays 12345 on the LCD.
 *
 * Note:
 *   Supports unsigned values within the range of the u32 data type.
 */
void U32LCD(u32 n);


/*
 * Function Name : S32LCD
 *
 * Description:
 *   Displays a signed 32-bit integer on the LCD, including its sign.
 *
 * Parameter:
 *   n - Signed 32-bit integer value to be displayed.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Working:
 *   If the supplied number is negative, the minus sign is displayed first.
 *   The magnitude of the number is then passed for decimal digit display.
 *
 * Example:
 *   S32LCD(-123);
 *
 *   Displays -123 on the LCD.
 *
 * Note:
 *   The implementation should handle the minimum signed 32-bit value
 *   carefully because its positive magnitude cannot be represented by s32.
 */
void S32LCD(s32 n);


/*
 * Function Name : F32LCD
 *
 * Description:
 *   Displays a floating-point number on the LCD with a specified number
 *   of digits after the decimal point.
 *
 * Parameters:
 *   n   - Floating-point value to be displayed.
 *   nDP - Number of decimal places to display.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Example:
 *   F32LCD(12.345F, 2);
 *
 *   Displays approximately 12.34 when the implementation truncates
 *   the fractional part rather than rounding it.
 *
 * Note:
 *   The displayed precision depends on the implementation and
 *   floating-point representation.
 */
void F32LCD(f32 n, u8 nDP);


/*
 * Function Name : BuildCGRAM
 *
 * Description:
 *   Writes custom character pattern data into the LCD Character
 *   Generator RAM (CGRAM).
 *
 * Parameters:
 *   p      - Pointer to the memory containing custom character pattern data.
 *   nBytes - Number of pattern bytes to be transferred to the LCD.
 *
 * Return Type:
 *   void - Does not return any value.
 *
 * Working:
 *   1. Selects the CGRAM address in the LCD controller.
 *   2. Transfers the supplied character pattern bytes.
 *   3. Allows the LCD to store the custom pattern in its CGRAM.
 *
 * Application:
 *   Used to create custom symbols, icons and graphical characters
 *   that are not available in the LCD's built-in character set.
 *
 * Note:
 *   For a typical HD44780-compatible 5x8 character configuration,
 *   each custom character uses 8 pattern bytes, with the lower five
 *   bits of each byte representing the character pixels.
 *
 *   The pattern size and CGRAM address must follow the LCD controller's
 *   memory organization.
 */
void BuildCGRAM(u8 *p, u8 nBytes);


/*==============================================================================
 * END OF LCD HEADER GUARD
 *==============================================================================
 *
 * Marks the end of the LCD header file.
 */

#endif
```