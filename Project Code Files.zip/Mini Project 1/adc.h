```c
/*
 * File Name   : adc.h
 * Description : Header file for the ADC0 driver of the LPC2148 microcontroller.
 *
 * Purpose:
 * This header file provides the function declarations required to
 * initialize the ADC peripheral and perform analog-to-digital conversion.
 *
 * The ADC driver supports:
 * 1. ADC peripheral initialization.
 * 2. Selection of ADC input channels.
 * 3. Reading 10-bit digital conversion results.
 * 4. Calculation of equivalent analog input voltage.
 *
 * Usage:
 * Include this header file in application modules that require
 * ADC initialization or analog input measurement.
 *
 * Note:
 * The corresponding function implementations are available in adc.c.
 */


/*
 * Header Guard:
 *
 * Prevents multiple inclusions of this header file within the same
 * source file or compilation unit.
 *
 * When ADC_H is not defined, it is defined and the contents of
 * this header file are included.
 *
 * If this header file is included again, the preprocessor skips
 * its contents, preventing duplicate declarations.
 */

#ifndef ADC_H
#define ADC_H


/*
 * Include user-defined data types.
 *
 * Provides the required type definitions used by the ADC driver:
 *
 * u8  : Unsigned 8-bit integer, used for ADC channel number and
 *       function return status.
 *
 * u16 : Unsigned 16-bit integer, used to store the ADC digital result.
 *
 * f32 : 32-bit floating-point data type, used to store the
 *       equivalent analog voltage.
 */

#include "types.h"


/*
 * Function Name : Init_ADC
 *
 * Description:
 * Initializes the ADC0 peripheral and configures the required
 * ADC input pin for analog-to-digital conversion.
 *
 * Functionality:
 * 1. Configures the ADC input pin using the appropriate PINSEL register.
 * 2. Configures the ADC peripheral clock.
 * 3. Powers up the ADC peripheral.
 *
 * Parameters : None.
 *
 * Return Type : void.
 *
 * Note:
 * This function must be called before performing ADC conversions.
 */

void Init_ADC(void);


/*
 * Function Name : Read_ADC
 *
 * Description:
 * Performs analog-to-digital conversion on the specified ADC channel
 * and provides both the digital conversion result and the equivalent
 * analog input voltage.
 *
 * Parameters:
 *
 * chNo:
 * Specifies the ADC input channel number.
 * Valid channel numbers range from 0 to 7.
 *
 * dVal:
 * Pointer to an unsigned 16-bit variable.
 * Stores the 10-bit digital ADC conversion result.
 * Valid result range: 0 to 1023.
 *
 * eAR:
 * Pointer to a floating-point variable.
 * Stores the calculated equivalent analog input voltage.
 * Voltage is calculated using the ADC reference voltage.
 *
 * Return Type : u8.
 *
 * Return Status:
 * 1U : Conversion completed successfully.
 * 0U : Invalid input arguments or ADC conversion timeout.
 *
 * Working:
 * 1. Validates the channel number and output pointers.
 * 2. Selects the requested ADC input channel.
 * 3. Starts the ADC conversion process.
 * 4. Waits for conversion completion using polling.
 * 5. Extracts the 10-bit conversion result.
 * 6. Calculates the corresponding analog voltage.
 * 7. Stores the results through the provided pointers.
 *
 * Note:
 * The calling function must provide valid memory locations for
 * both output pointers before invoking this function.
 */

u8 Read_ADC(u8 chNo, u16 *dVal, f32 *eAR);


/*
 * End of header guard.
 *
 * Indicates the end of the ADC_H protected section.
 * Prevents repeated inclusion of this header file.
 */

#endif
```