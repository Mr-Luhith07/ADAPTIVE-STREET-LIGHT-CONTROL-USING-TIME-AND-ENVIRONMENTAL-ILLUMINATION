```c
/*
 * File Name   : adc.c
 * Description : ADC0 driver implementation for LPC2148 microcontroller.
 * Peripheral  : 10-bit Analog-to-Digital Converter (ADC0).
 * ADC Channel : AD0.1 (ADC Channel 1).
 * ADC Pin     : P0.28.
 *
 * Clock Configuration:
 * PCLK        : 15 MHz (assumed).
 * ADC Clock   : 3 MHz.
 * ADC_CLKDIV  : 4 (PCLK / (ADC_CLKDIV + 1) = 3 MHz).
 *
 * Functional Description:
 * This driver initializes the ADC0 peripheral and provides a function
 * to read analog input voltage from a selected ADC channel.
 *
 * The ADC conversion result is returned in two formats:
 * 1. Digital ADC value (10-bit resolution: 0 to 1023).
 * 2. Equivalent analog voltage calculated using the reference voltage.
 *
 * The driver uses polling with a timeout mechanism to avoid indefinite
 * waiting for ADC conversion completion.
 */

#include <LPC214x.h>       // Includes LPC2148 register definitions and hardware-specific declarations.
#include "types.h"         // Includes user-defined data types such as u8, u16, u32 and f32.
#include "adc.h"           // Includes ADC driver function declarations and function prototypes.
#include "adc_defines.h"   // Includes ADC configuration macros, bit positions and constant definitions.


/*
 * Function Name : Init_ADC
 * Description   : Initializes the ADC0 peripheral and configures
 *                 the corresponding ADC input pin.
 * Arguments     : None.
 * Return Type   : void.
 *
 * Working:
 * 1. Configures P0.28 as ADC0 channel 1 (AD0.1).
 * 2. Configures the ADC clock divider.
 * 3. Powers up the ADC peripheral by setting the PDN bit.
 *
 * Note:
 * This initialization function configures the hardware required
 * for ADC operation before starting any conversion.
 */

void Init_ADC(void)
{
    // Clear PINSEL1 bits [25:24] to remove the previous pin-function configuration of P0.28.
    // Each pin has two function-selection bits in the PINSEL register.
    // Clearing both bits initially ensures a known pin configuration.

    PINSEL1 &= ~(3U << 24);

    // Set PINSEL1 bit 24 to select the ADC0 channel 1 alternate function (AD0.1) on P0.28.
    // PINSEL1[25:24] = 01 selects the required ADC functionality.

    PINSEL1 |=  (1U << 24);

    // Configure the ADC0 Control Register (AD0CR).
    // ADC_CLKDIV is shifted to bits [15:8] to configure the ADC peripheral clock.
    // Setting the PDN bit powers up the ADC hardware.
    // Other fields are initialized to zero, including the channel selection
    // and conversion-start control fields.

    AD0CR = (ADC_CLKDIV << 8) | (1U << ADC_PDN_BIT);
}


/*
 * Function Name : Read_ADC
 * Description   : Performs ADC conversion on the selected ADC0 channel
 *                 and returns the digital value and corresponding voltage.
 *
 * Arguments:
 * chNo          : ADC channel number (0 to 7).
 * dVal          : Pointer to store the 10-bit digital ADC conversion result.
 * eAR           : Pointer to store the equivalent analog voltage.
 *
 * Return Value:
 * 1U            : ADC conversion completed successfully.
 * 0U            : Invalid arguments or ADC conversion timeout occurred.
 *
 * Working:
 * 1. Validates the input arguments.
 * 2. Selects the required ADC channel.
 * 3. Configures the ADC clock and enables the ADC peripheral.
 * 4. Starts ADC conversion.
 * 5. Waits for conversion completion using polling.
 * 6. Checks for timeout conditions.
 * 7. Extracts the 10-bit ADC result.
 * 8. Calculates the equivalent analog voltage.
 * 9. Stops the conversion-start control field and returns success.
 */

u8 Read_ADC(u8 chNo, u16 *dVal, f32 *eAR)
{
    // Local variable used as a software timeout counter.
    // Prevents the processor from waiting indefinitely if ADC conversion
    // completion is not indicated by the hardware.

    u32 timeout;

    // Local variable used to hold the raw ADC conversion result
    // extracted from the ADC Global Data Register.

    u32 result;


    // Validate the input parameters before accessing hardware registers.
    // ADC0 supports channel numbers from 0 to 7.
    // dVal must point to a valid memory location for storing the digital result.
    // eAR must point to a valid memory location for storing the calculated voltage.
    // Return 0U if any argument is invalid.

    if(chNo > 7U || dVal == 0 || eAR == 0)
        return 0U;


    // Configure the ADC0 Control Register (AD0CR).
    // (1U << chNo) selects the required ADC input channel.
    // (ADC_CLKDIV << 8) configures the ADC clock divider in bits [15:8].
    // (1U << ADC_PDN_BIT) powers up the ADC peripheral.
    // Assigning AD0CR also clears the previous channel selection
    // and conversion control configuration.

    AD0CR = (1U << chNo) |
            (ADC_CLKDIV << 8) |
            (1U << ADC_PDN_BIT);


    // Clear the START field (bits [26:24]) before initiating a new conversion.
    // This ensures that no previous conversion-start command remains active.
    // A value of 000 in the START field indicates that no software-triggered
    // conversion is requested.

    AD0CR &= ~(7U << ADC_START_BIT);


    // Set the START field to 001 to initiate ADC conversion immediately.
    // The ADC hardware starts converting the analog input selected by chNo.
    // The conversion process is performed by the internal successive
    // approximation ADC circuitry.

    AD0CR |=  (1U << ADC_START_BIT);


    // Initialize the software timeout counter.
    // ADC_TIMEOUT defines the maximum number of polling iterations
    // allowed for the conversion to complete.

    timeout = ADC_TIMEOUT;


    // Poll the ADC Global Data Register (AD0GDR) until the DONE bit is set.
    // ADC_DONE_BIT identifies the conversion-completion status bit.
    // When DONE = 1, the ADC hardware has completed the conversion
    // and the conversion result is available.
    // The timeout condition ensures that polling terminates even if
    // the ADC hardware does not report conversion completion.

    while(((AD0GDR & (1U << ADC_DONE_BIT)) == 0U) && timeout > 0U)
        timeout--;


    // Check whether the timeout counter reached zero.
    // If timeout becomes zero, the conversion was not detected as completed
    // within the permitted polling period.
    // Clear the START field to stop the software-triggered conversion request.
    // Return 0U to indicate conversion failure.

    if(timeout == 0U)
    {
        // Clear the ADC START field to remove the conversion-start command.
        AD0CR &= ~(7U << ADC_START_BIT);

        // Return failure status to the calling function.
        return 0U;
    }


    // Extract the 10-bit ADC conversion result from AD0GDR.
    // Right-shifting by ADC_RESULT_SHIFT moves the result field
    // into the least significant bit positions.
    // Bitwise AND with ADC_RESULT_MASK removes all unwanted bits.
    // The resulting value ranges from 0 to 1023 for a 10-bit ADC.

    result = (AD0GDR >> ADC_RESULT_SHIFT) & ADC_RESULT_MASK;


    // Store the extracted digital conversion result in the memory
    // location pointed to by dVal.
    // Type casting converts the 32-bit temporary result into a 16-bit value.
    // Since the ADC result is only 10 bits, it safely fits within u16.

    *dVal = (u16)result;


    // Calculate the equivalent analog input voltage.
    // ADC conversion formula:
    //
    // Analog Voltage = (Digital ADC Value * Reference Voltage) / 1023
    //
    // ADC_VREF represents the ADC reference voltage.
    // 1023 is the maximum digital count for a 10-bit ADC.
    // Type casting to f32 ensures floating-point multiplication and division.
    // The calculated voltage is stored at the memory location pointed to by eAR.

    *eAR = ((f32)result * ADC_VREF) / 1023.0F;


    // Clear the START field after successful conversion.
    // This removes the software conversion-start command and leaves
    // the ADC ready for a subsequent conversion request.

    AD0CR &= ~(7U << ADC_START_BIT);


    // Return 1U to indicate successful ADC conversion.
    // The digital result and equivalent analog voltage have been stored
    // in the caller-provided memory locations.

    return 1U;
}
```