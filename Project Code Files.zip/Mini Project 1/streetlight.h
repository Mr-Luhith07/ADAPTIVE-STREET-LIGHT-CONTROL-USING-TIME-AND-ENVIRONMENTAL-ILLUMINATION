
/*******************************************************************************
 * FILE NAME    : streetlight.h
 *
 * MODULE       : Street Light Control Module
 *
 * DESCRIPTION  :
 *                This header file provides the public interface for the
 *                automatic street light control module.
 *
 *                It contains the external declarations of schedule
 *                configuration variables and function prototypes required
 *                to initialize, evaluate, and control the street light
 *                hardware.
 *
 * MODULE RESPONSIBILITIES :
 *
 *                1. Provides access to the configured street light
 *                   activation and deactivation schedule.
 *
 *                2. Determines whether the current RTC time falls within
 *                   the configured operating schedule.
 *
 *                3. Initializes the GPIO pins assigned to street light
 *                   control.
 *
 *                4. Controls the street light outputs based on RTC
 *                   scheduling and LDR darkness detection.
 *
 * SYSTEM OPERATION :
 *
 *                Street lights are switched ON only when:
 *
 *                - ADC measurement is valid.
 *                - LDR driver is initialized.
 *                - Current RTC time is within the configured schedule.
 *                - Ambient light condition indicates darkness.
 *
 *                If any required condition is not satisfied, the street
 *                light outputs are switched OFF.
 *
 * TARGET MCU   : LPC2148
 *
 * DEPENDENCIES : types.h
 *
 * IMPLEMENTATION FILE :
 *                streetlight.c
 *
 *******************************************************************************/


#ifndef STREETLIGHT_H
/*
 * HEADER GUARD - BEGINNING
 *
 * Prevents multiple inclusion of this header file during compilation.
 *
 * The preprocessor checks whether STREETLIGHT_H has already been defined.
 *
 * If it is not defined, the compiler processes the contents of this
 * header file and defines the macro.
 *
 * This avoids duplicate declaration problems when multiple source
 * files include streetlight.h directly or indirectly.
 */
#define STREETLIGHT_H


/*
 * Include the project-specific data type definitions.
 *
 * Provides standardized integer data types used throughout the
 * street light control module.
 *
 * u8  - Unsigned 8-bit integer.
 * u32 - Unsigned 32-bit integer.
 *
 * These types improve consistency and portability across the
 * embedded application.
 */
#include "types.h"


/*******************************************************************************
 * EXTERNAL GLOBAL SCHEDULE CONFIGURATION VARIABLES
 *
 * DESCRIPTION :
 *                These variables represent the configured operating
 *                schedule of the street light control system.
 *
 *                They are defined and initialized in streetlight.c.
 *
 *                The extern keyword declares that the actual storage
 *                for these variables exists in another source file.
 *
 * PURPOSE :
 *                Allows other application modules, such as main.c,
 *                to access or modify the street light operating schedule.
 *
 * VARIABLES :
 *
 *                start_hour - Scheduled activation hour.
 *
 *                start_min  - Scheduled activation minute.
 *
 *                end_hour   - Scheduled deactivation hour.
 *
 *                end_min    - Scheduled deactivation minute.
 *
 * TIME FORMAT :
 *                24-hour clock format.
 *
 * EXAMPLE :
 *
 *                start_hour = 18U;
 *                start_min  = 30U;
 *
 *                end_hour   = 6U;
 *                end_min    = 0U;
 *
 *                Operating schedule: 18:30 to 06:00.
 *
 * NOTE :
 *                Since these variables are externally accessible,
 *                any modification should ensure valid hour and
 *                minute values.
 *
 *                The schedule evaluation logic is implemented
 *                in StreetLight_IsScheduled().
 *******************************************************************************/
extern u32 start_hour, start_min, end_hour, end_min;


/*******************************************************************************
 * FUNCTION PROTOTYPE : StreetLight_IsScheduled
 *
 * DESCRIPTION :
 *                Determines whether the supplied RTC time falls within
 *                the configured street light operating schedule.
 *
 * PURPOSE :
 *                Provides the time-based decision required by the
 *                street light control module.
 *
 * PARAMETERS :
 *
 *                hour   - Current hour obtained from the RTC.
 *                         Valid 24-hour format: 0 to 23.
 *
 *                minute - Current minute obtained from the RTC.
 *                         Valid range: 0 to 59.
 *
 * RETURN VALUE :
 *
 *                u8 - Boolean-style status value.
 *
 *                     1U - Current time is within the active schedule.
 *
 *                     0U - Current time is outside the active schedule
 *                          or the configured schedule is disabled.
 *
 * SUPPORTED SCHEDULE TYPES :
 *
 *                1. Normal schedule:
 *                   Example: 08:00 to 18:00.
 *
 *                2. Overnight schedule:
 *                   Example: 18:30 to 06:00.
 *
 *                3. Disabled schedule:
 *                   Start time and end time are equal.
 *
 * BOUNDARY CONDITION :
 *
 *                Start time is inclusive.
 *                End time is exclusive.
 *
 * IMPLEMENTATION :
 *                streetlight.c
 *******************************************************************************/
u8 StreetLight_IsScheduled(u32 hour, u32 minute);


/*******************************************************************************
 * FUNCTION PROTOTYPE : StreetLight_Init
 *
 * DESCRIPTION :
 *                Initializes the GPIO hardware resources required
 *                for street light control.
 *
 * PURPOSE :
 *                Configures the designated microcontroller GPIO pins
 *                and establishes a known initial output state.
 *
 * OPERATIONS :
 *
 *                1. Configures the required pin functions for GPIO.
 *
 *                2. Configures the street light GPIO pins as outputs.
 *
 *                3. Clears the corresponding GPIO output bits to
 *                   initialize all street lights in the OFF state.
 *
 * PARAMETERS :
 *                None.
 *
 * RETURN VALUE :
 *                void - Does not return any value.
 *
 * HARDWARE DEPENDENCY :
 *                LPC2148 GPIO peripheral.
 *
 * IMPLEMENTATION :
 *                streetlight.c
 *******************************************************************************/
void StreetLight_Init(void);


/*******************************************************************************
 * FUNCTION PROTOTYPE : StreetLight_Control
 *
 * DESCRIPTION :
 *                Controls the street light hardware according to
 *                the current RTC time and ambient light condition.
 *
 * PURPOSE :
 *                Implements the final street light activation and
 *                deactivation decision.
 *
 * PARAMETERS :
 *
 *                hour   - Current hour obtained from the RTC.
 *                         Valid 24-hour format: 0 to 23.
 *
 *                minute - Current minute obtained from the RTC.
 *                         Valid range: 0 to 59.
 *
 * ACTIVATION CONDITIONS :
 *
 *                The street lights are switched ON only when all
 *                the following conditions are satisfied:
 *
 *                1. ADC measurement is valid.
 *
 *                2. LDR driver initialization is completed.
 *
 *                3. Current RTC time falls within the configured
 *                   operating schedule.
 *
 *                4. LDR sensor indicates darkness.
 *
 * OUTPUT BEHAVIOUR :
 *
 *                All conditions TRUE:
 *                Configured GPIO outputs are driven HIGH.
 *
 *                Any condition FALSE:
 *                Configured GPIO outputs are driven LOW.
 *
 * FAIL-SAFE BEHAVIOUR :
 *
 *                If the ADC measurement is invalid or the LDR driver
 *                is not initialized, the street lights remain OFF.
 *
 * PARAMETERS ARE PASSED BY VALUE :
 *
 *                The hour and minute values are passed directly
 *                to the function.
 *
 *                Changes to these local parameter variables inside
 *                the function do not modify the original variables
 *                supplied by the calling function.
 *
 * RETURN VALUE :
 *                void - Does not return any value.
 *
 * IMPLEMENTATION :
 *                streetlight.c
 *******************************************************************************/
void StreetLight_Control(u32 hour, u32 minute);


/*
 * HEADER GUARD - ENDING
 *
 * Marks the end of the STREETLIGHT_H conditional compilation block.
 *
 * Prevents the declarations in this header file from being processed
 * repeatedly during the same compilation unit.
 */
#endif


/*******************************************************************************
 * END OF FILE : streetlight.h
 *
 * PUBLIC INTERFACE SUMMARY :
 *
 *                External configuration variables:
 *
 *                start_hour, start_min, end_hour, end_min
 *
 *                Public functions:
 *
 *                StreetLight_IsScheduled()
 *                StreetLight_Init()
 *                StreetLight_Control()
 *
 *                The actual function implementations and global variable
 *                definitions are maintained in streetlight.c.
 *
 *******************************************************************************/
