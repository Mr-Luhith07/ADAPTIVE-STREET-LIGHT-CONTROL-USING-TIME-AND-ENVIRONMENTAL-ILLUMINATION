```c
/*
 *==============================================================================
 * Module Name : KPM.c
 * Description : 4x4 Matrix Keypad Driver
 * Controller  : LPC2148
 *
 * Hardware Connections:
 *
 * ROW LINES:
 *   ROW0 -> P1.16 (Output)
 *   ROW1 -> P1.17 (Output)
 *   ROW2 -> P1.18 (Output)
 *   ROW3 -> P1.19 (Output)
 *
 * COLUMN LINES:
 *   COL0 -> P1.20 (Input)
 *   COL1 -> P1.21 (Input)
 *   COL2 -> P1.22 (Input)
 *   COL3 -> P1.23 (Input)
 *
 * Keypad Operation:
 *   - The four row lines are configured as GPIO outputs.
 *   - The four column lines are configured as GPIO inputs.
 *   - One row is activated at a time during row scanning.
 *   - The column inputs are monitored to identify the pressed key.
 *   - The KpmLUT lookup table converts the detected row and column
 *     positions into their corresponding key characters.
 *
 * Supported Keys:
 *   - Numeric keys : 0 to 9
 *   - Clear key    : C
 *   - Backspace    : x
 *   - Enter key    : =
 *   - Other keys   : /, +, -
 *
 * Additional Functionality:
 *   - Software debouncing.
 *   - Single-key detection with press-release rearming.
 *   - Numeric input with a configurable digit limit.
 *   - Background service execution during numeric input.
 *
 *==============================================================================
 */


/*------------------------------------------------------------------------------
 * HEADER FILE INCLUSIONS
 *------------------------------------------------------------------------------*/

#include <LPC214x.h>       // Provides LPC2148 register definitions such as IODIR1,
                           // IOPIN1, IOSET1 and IOCLR1.

#include "types.h"         // Provides user-defined data types such as u8, u32,
                           // ensuring consistent data-width usage.

#include "kpm.h"           // Contains function declarations for keypad-related
                           // functions implemented in this source file.

#include "kpm_defines.h"   // Contains keypad-related macros such as ROW0, ROW1,
                           // ROW2, ROW3, COL0, COL1, COL2 and COL3.

#include "lcd.h"           // Provides LCD function declarations used to display
                           // numeric input and keypad-related information.

#include "lcd_defines.h"   // Provides LCD command and cursor-position definitions
                           // such as CLEAR_LCD, GOTO_LINE1_POS0 and GOTO_LINE2_POS0.

#include "delay.h"         // Provides software delay functions used for keypad
                           // switch debouncing and timing control.


/*------------------------------------------------------------------------------
 * KEYPAD LOOKUP TABLE
 *
 * Purpose:
 *   Converts the detected row and column positions into the corresponding
 *   character of the pressed keypad button.
 *
 * Explanation:
 *   KpmLUT[4][4] represents a two-dimensional array containing 16 key values.
 *
 *   First index  -> Represents the row number (0 to 3).
 *   Second index -> Represents the column number (0 to 3).
 *
 *   Example:
 *     KpmLUT[0][0] = '1'
 *     KpmLUT[0][1] = '2'
 *     KpmLUT[1][2] = '6'
 *     KpmLUT[3][0] = 'C'
 *
 *   The 'static' keyword restricts access to this lookup table to this source
 *   file. The 'const' keyword prevents modification of its contents at runtime.
 *------------------------------------------------------------------------------*/

static const u8 KpmLUT[4][4] =
{
    {'1','2','3','/'},     // Row 0: Keys connected to ROW0.
    {'4','5','6','x'},     // Row 1: Keys connected to ROW1.
    {'7','8','9','-'},     // Row 2: Keys connected to ROW2.
    {'C','0','=','+'}      // Row 3: Keys connected to ROW3.
};


/*------------------------------------------------------------------------------
 * FUNCTION NAME : InitKPM
 *
 * DESCRIPTION:
 *   Initializes the GPIO pins required for interfacing the 4x4 matrix keypad
 *   with the LPC2148 microcontroller.
 *
 * INPUT:
 *   None.
 *
 * RETURN:
 *   None.
 *
 * WORKING:
 *   1. Configures P1.16 to P1.19 as output pins for keypad row selection.
 *   2. Configures P1.20 to P1.23 as input pins for keypad column detection.
 *   3. Initially drives all row output pins LOW.
 *
 * NOTE:
 *   This configuration assumes the keypad columns are externally pulled HIGH
 *   or have suitable pull-up arrangements. A pressed key connects an active
 *   LOW row to its corresponding column.
 *------------------------------------------------------------------------------*/

void InitKPM(void)
{
    /* Configure all four row pins, P1.16 to P1.19, as GPIO outputs.
       IODIR1 bit = 1 means output.
       0x0F represents four consecutive bits: 0000 1111.
       Shifting by ROW0 positions these four bits at the row pin locations. */
    IODIR1 |=  (0x0FU << ROW0);

    /* Configure all four column pins, P1.20 to P1.23, as GPIO inputs.
       IODIR1 bit = 0 means input.
       The bitwise complement clears the four column direction bits. */
    IODIR1 &= ~(0x0FU << COL0);

    /* Drive all four row output pins LOW initially.
       This establishes the initial row output condition before scanning. */
    IOCLR1 = (0x0FU << ROW0);
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : ColScan
 *
 * DESCRIPTION:
 *   Checks whether any keypad column is being pulled LOW.
 *
 * INPUT:
 *   None.
 *
 * RETURN:
 *   0 -> At least one column is LOW, indicating a possible key press.
 *   1 -> All four columns are HIGH, indicating no detected key press.
 *
 * WORKING:
 *   1. Creates a bit mask for the four column pins.
 *   2. Reads the current GPIO input register using IOPIN1.
 *   3. Masks out all bits except the keypad column bits.
 *   4. Compares the resulting column states with the expected HIGH state.
 *
 * IMPORTANT:
 *   This function uses active-LOW key detection.
 *   A pressed key connects an activated LOW row to a column input.
 *------------------------------------------------------------------------------*/

u8 ColScan(void)
{
    /* Construct a mask representing all four keypad column pins.
       Each shifted bit selects one column input pin. */
    u32 mask = (1U << COL0) | (1U << COL1) |
               (1U << COL2) | (1U << COL3);

    /* Read the column input states.
       IOPIN1 & mask extracts only the four column pin values.
       If the result equals mask, all four columns are HIGH.
       Otherwise, at least one column is LOW.
       Return 1 for no detected press and 0 for a possible key press. */
    return ((IOPIN1 & mask) == mask) ? 1U : 0U;
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : RowCheck
 *
 * DESCRIPTION:
 *   Identifies which keypad row contains the pressed key.
 *
 * INPUT:
 *   None.
 *
 * RETURN:
 *   0 -> Key detected in ROW0.
 *   1 -> Key detected in ROW1.
 *   2 -> Key detected in ROW2.
 *   3 -> Key detected in ROW3.
 *   0xFF -> No valid row detected.
 *
 * WORKING:
 *   1. Activates ROW0 LOW and keeps the remaining rows HIGH.
 *   2. Checks whether any column becomes LOW using ColScan().
 *   3. If no key is detected, activates ROW1 LOW.
 *   4. Repeats the same procedure for ROW2 and ROW3.
 *   5. Returns the row number corresponding to the detected key.
 *
 * SCANNING PRINCIPLE:
 *   Only one row is driven LOW at a time. When a key is pressed, the LOW
 *   signal reaches the corresponding column through the keypad switch.
 *   This allows the software to identify the active row.
 *------------------------------------------------------------------------------*/

u8 RowCheck(void)
{
    /* Initialize the row result to 0xFF.
       This value represents an invalid row or no detected row. */
    u8 r = 0xFFU;

    /* Activate ROW0 by driving it LOW.
       Keep ROW1, ROW2 and ROW3 HIGH.
       This selects ROW0 for the first row-scanning operation. */
    IOCLR1 = (1U << ROW0);

    /* Drive the remaining three row pins HIGH.
       IOSET1 sets the selected GPIO output bits HIGH. */
    IOSET1 = (1U << ROW1) | (1U << ROW2) |
             (1U << ROW3);

    /* Check whether any column becomes LOW.
       If ColScan() returns 0, a key is detected in the currently
       activated ROW0. */
    if(ColScan() == 0U)
        r = 0U;

    /* If ROW0 does not contain the pressed key, scan ROW1. */
    else
    {
        /* Deactivate ROW0 by driving it HIGH.
           This prevents ROW0 from participating in the next scan. */
        IOSET1 = (1U << ROW0);

        /* Activate ROW1 by driving it LOW. */
        IOCLR1 = (1U << ROW1);

        /* Keep ROW2 and ROW3 HIGH while scanning ROW1. */
        IOSET1 = (1U << ROW2) | (1U << ROW3);

        /* Check whether any column becomes LOW while ROW1 is active.
           If detected, the pressed key belongs to ROW1. */
        if(ColScan() == 0U)
            r = 1U;

        /* If ROW1 does not contain the pressed key, scan ROW2. */
        else
        {
            /* Keep ROW0 and ROW1 HIGH.
               This deactivates the previously scanned rows. */
            IOSET1 = (1U << ROW0) | (1U << ROW1);

            /* Activate ROW2 by driving it LOW. */
            IOCLR1 = (1U << ROW2);

            /* Keep ROW3 HIGH during ROW2 scanning. */
            IOSET1 = (1U << ROW3);

            /* Check whether any column becomes LOW while ROW2 is active.
               If detected, the pressed key belongs to ROW2. */
            if(ColScan() == 0U)
                r = 2U;

            /* If ROW2 does not contain the pressed key, scan ROW3. */
            else
            {
                /* Keep ROW0, ROW1 and ROW2 HIGH.
                   This deactivates all previously scanned rows. */
                IOSET1 = (1U << ROW0) |
                         (1U << ROW1) |
                         (1U << ROW2);

                /* Activate ROW3 by driving it LOW.
                   ROW3 is the final row in the scanning sequence. */
                IOCLR1 = (1U << ROW3);

                /* Check whether any column becomes LOW while ROW3 is active.
                   If detected, the pressed key belongs to ROW3. */
                if(ColScan() == 0U)
                    r = 3U;
            }
        }
    }

    /* Do not reset the row outputs here.
       The selected row must remain active until ColCheck() identifies
       which column contains the pressed key.
       Resetting the rows before column identification could make the
       pressed key disappear from the column input readings. */

    /* Return the detected row number to the calling function. */
    return r;
}


/*------------------------------------------------------------------------------
 * FUNCTION NAME : ColCheck
 *
 * DESCRIPTION:
 *   Identifies which keypad column contains the pressed key.
 *
 * INPUT:
 *   None.
 *
 * RETURN:
 *   0 -> COL0 contains the pressed key.
 *   1 -> COL1 contains the pressed key.
 *   2 -> COL2 contains the pressed key.
 *   3 -> COL3 contains the pressed key.
 *   0xFF -> No valid column detected.
 *
 * WORKING:
 *   Checks the four column input pins individually.
 *   Since the keypad uses active-LOW detection, a LOW input indicates
 *   the column connected to the pressed key.
 *
 * IMPORTANT:
 *   RowCheck() must activate the correct row before this function is called.
 *------------------------------------------------------------------------------*/

u8 ColCheck(void)
{
    /* Check COL0.
       If P1.COL0 is LOW, return column index 0. */
    if((IOPIN1 & (1U << COL0)) == 0U) return 0U;

    /* Check COL1.
       If P1.COL1 is LOW, return column index 1. */
    if((IOPIN1 & (1U << COL1)) == 0U) return 1U;

    /* Check COL2.
       If P1.COL2 is LOW, return column index 2. */
    if((IOPIN1 & (1U << COL2)) == 0U) return 2U;

    /* Check COL3.
       If P1.COL3 is LOW, return column index 3. */
    if((IOPIN1 & (1U << COL3)) == 0U) return 3U;

    /* If none of the four columns is LOW, return 0xFF
       to indicate that no valid column was identified. */
    return 0xFFU;
}


/*------------------------------------------------------------------------------
 * LOCAL DRIVER DESIGN NOTE
 *
 * READBIT is kept local to this driver to avoid a dependency on defines.h.
 * The present implementation directly uses bit masks and register operations,
 * so no external READBIT macro is required.
 *------------------------------------------------------------------------------*/

/* READBIT is kept local to this driver to avoid a dependency on defines.h. */


/*------------------------------------------------------------------------------
 * FUNCTION NAME : KeyScan_NB
 *
 * DESCRIPTION:
 *   Performs keypad scanning with software debouncing and single-key
 *   press-release detection.
 *
 *   NB stands for Non-Blocking.
 *
 * INPUT:
 *   None.
 *
 * RETURN:
 *   0       -> No new valid key press is available.
 *   Key code -> ASCII character corresponding to the pressed key.
 *
 * WORKING:
 *   1. Checks whether any keypad column is LOW.
 *   2. Rearms key detection when all columns return HIGH.
 *   3. Prevents repeated reporting while the same key remains pressed.
 *   4. Applies a 20 ms software debounce delay.
 *   5. Checks the keypad again to confirm that the key press is stable.
 *   6. Identifies the pressed row using RowCheck().
 *   7. Identifies the pressed column using ColCheck().
 *   8. Retrieves the corresponding key character from KpmLUT.
 *   9. Marks the key as processed until the keypad is released.
 *
 * DEBOUNCING:
 *   Mechanical keypad switches may produce multiple rapid electrical
 *   transitions when pressed or released.
 *   The delay_ms(20U) provides a settling period before confirming the press.
 *
 * KEY REARMING:
 *   keyReady is a static variable, so its value is retained between function
 *   calls. A key is reported once and another key press is accepted only
 *   after all columns return to their HIGH idle state.
 *
 * LIMITATION:
 *   This implementation is designed for single-key detection. It does not
 *   implement multi-key rollover or ghost-key detection.
 *------------------------------------------------------------------------------*/

u8 KeyScan_NB(void)
{
    /* Static variable retains its value across multiple function calls.
       1 -> A new key press is allowed.
       0 -> A key has already been reported; wait for complete release. */
    static u8 keyReady = 1U;

    /* Local variables used to store the detected row, column and key value. */
    u8 row, col, key;

    /* Check whether all columns are HIGH.
       ColScan() returns 1 when no key is detected.
       This indicates that the keypad has returned to its idle state. */
    if(ColScan() != 0U)
    {
        /* Rearm the keypad so that the next key press can be detected. */
        keyReady = 1U;

        /* Return 0 because there is no currently pressed key. */
        return 0U;
    }

    /* If keyReady is 0, a previous key press has already been reported.
       Do not report the same continuously held key again. */
    if(keyReady == 0U)
        return 0U;

    /* Wait for 20 milliseconds to allow mechanical switch bounce
       to settle before confirming the key press. */
    delay_ms(20U);

    /* Recheck the keypad after the debounce delay.
       If all columns are HIGH, the initial LOW signal was not stable.
       Rearm the keypad and reject this possible false key press. */
    if(ColScan() != 0U)
    {
        /* Allow a future key press to be detected. */
        keyReady = 1U;

        /* Return 0 because the key press was not confirmed. */
        return 0U;
    }

    /* Identify which row contains the pressed key.
       RowCheck() activates the rows one at a time and returns
       the row index where a LOW column signal is detected. */
    row = RowCheck();

    /* Validate the returned row number.
       Valid row indices are 0, 1, 2 and 3.
       Values greater than 3 indicate an invalid row result. */
    if(row > 3U)
    {
        /* Return all four row output pins to LOW.
           This restores the initial row output condition used by this driver. */
        IOCLR1 = (0x0FU << ROW0);

        /* Reject the invalid row result. */
        return 0U;
    }

    /* Identify which column contains the pressed key.
       The row selected by RowCheck() is still active at this point.
       ColCheck() reads the four column inputs and returns the column index. */
    col = ColCheck();

    /* Restore the idle row condition by driving all four row pins LOW.
       This is performed after the column has been identified. */
    IOCLR1 = (0x0FU << ROW0);

    /* Validate the column index.
       Valid column indices are 0, 1, 2 and 3.
       If the result is invalid, reject the key press. */
    if(col > 3U)
        return 0U;

    /* Convert the detected row and column positions into the actual
       keypad character using the two-dimensional lookup table.
       Example: row = 0 and col = 0 gives key = '1'. */
    key = KpmLUT[row][col];

    /* Mark the current key press as processed.
       The same key will not be reported again until all columns
       return HIGH and the keypad is rearmed. */
    keyReady = 0U;

    /* Return the detected ASCII key character to the calling application. */
    return key;
}


/*==============================================================================
 * FUNCTION NAME : ReadNumWithService
 *
 * DESCRIPTION:
 *   Reads a multi-digit unsigned decimal number from the keypad and displays
 *   the entered value on the LCD.
 *
 *   This function also supports:
 *     - Maximum digit limitation.
 *     - Backspace operation.
 *     - Clear operation.
 *     - Enter/accept operation.
 *     - Background service execution while waiting for keypad input.
 *
 * INPUT PARAMETERS:
 *
 *   maxDigits:
 *     Maximum number of numeric digits permitted in the input.
 *
 *   service:
 *     Function pointer to a background service function.
 *     If service is not NULL (0), it is called repeatedly while the
 *     function waits for keypad input.
 *
 * RETURN VALUE:
 *     Returns the final unsigned integer value when '=' is pressed.
 *
 * KEYPAD OPERATIONS:
 *
 *     0-9 -> Append the pressed digit to the current number.
 *     x   -> Remove the last entered digit (Backspace).
 *     C   -> Clear the complete entered number.
 *     =   -> Accept the entered number and return it.
 *
 * NUMERIC CONVERSION:
 *     value = (value * 10) + digit
 *
 *     Example:
 *       Entered key sequence: 1, 2, 3
 *
 *       Initial value = 0
 *       Press '1' -> (0 * 10) + 1 = 1
 *       Press '2' -> (1 * 10) + 2 = 12
 *       Press '3' -> (12 * 10) + 3 = 123
 *
 * BACKSPACE:
 *     Integer division by 10 removes the last decimal digit.
 *
 *       123 / 10 = 12
 *        12 / 10 = 1
 *         1 / 10 = 0
 *
 * CLEAR:
 *     Resets both the numeric value and the digit counter to zero.
 *
 * ACCEPT:
 *     Returns the current value to the calling function.
 *
 * BACKGROUND SERVICE:
 *     The service function allows other application activities to continue
 *     while numeric input is being collected.
 *
 * IMPORTANT:
 *     The function uses a blocking while loop until '=' is pressed.
 *     The service callback is therefore important when background operations
 *     must continue during numeric input.
 *
 *==============================================================================*/

u32 ReadNumWithService(u8 maxDigits, void (*service)(void))
{
    /* Stores the decimal number entered through the keypad.
       Initialized to zero because no digits have been entered yet. */
    u32 value = 0U;

    /* Stores the ASCII character returned by KeyScan_NB(). */
    u8 key;

    /* Tracks the number of numeric digits entered by the user.
       This counter is used to enforce the maximum digit limit. */
    u8 digitCount = 0U;

    /* Clear only the second LCD line.
       First line contains the message/menu. */

    /*CmdLCD(GOTO_LINE2_POS0);
    StrLCD("                ");
    CmdLCD(GOTO_LINE2_POS0);  */

    /* Position the LCD cursor at the beginning of the first LCD line.
       Subsequent numeric display operations begin from this position. */
    CmdLCD(GOTO_LINE1_POS0);

    /* Continue collecting keypad input until the user presses '='.
       This is an intentional blocking input loop. */
    while(1)
    {
        /* Execute background operations while waiting for keypad input.
           The function pointer allows the application to supply its own
           background service routine without hard-coding that functionality
           inside the keypad driver. */
        if(service != 0)
            service();

        /* Scan the keypad for a newly pressed and debounced key.
           Returns 0 if no new valid key is available. */
        key = KeyScan_NB();

        /* If no valid key is detected, wait briefly and restart the loop.
           The service function will be called again on the next iteration. */
        if(key == 0U)
        {
            /* Small delay reduces unnecessary rapid polling of the keypad. */
            delay_ms(10U);

            /* Continue with the next iteration of the input loop. */
            continue;
        }

        /*--------------------------------
                NUMERIC KEY PRESSED
        --------------------------------*/

        /* Check whether the received ASCII character is between '0' and '9'.
           Only numeric characters are accepted for number construction. */
        if(key >= '0' && key <= '9')
        {
            /* Accept a new digit only if the current digit count is less
               than the maximum permitted number of digits. */
            if(digitCount < maxDigits)
            {
                /* Append the newly entered digit to the existing number.
                   Subtracting ASCII '0' converts the key character into
                   its corresponding numeric value.
                   Example: '5' - '0' = 5. */
                value = (value * 10U) +
                        (u32)(key - '0');

                /* Increment the digit counter after successfully
                   accepting the new numeric digit. */
                digitCount++;

                /* Clear and redraw the current numeric value on the LCD. */

                /*CmdLCD(GOTO_LINE2_POS0);
                StrLCD("                ");
                CmdLCD(GOTO_LINE2_POS0); */

                /* Clear the complete LCD display.
                   This command clears both LCD lines and returns the cursor
                   to the home position. */
                CmdLCD(CLEAR_LCD);

                /* Display the updated unsigned integer value on the LCD.
                   U32LCD() converts the numeric value into decimal characters
                   and sends them to the LCD. */
                U32LCD(value);
            }
        }

        /*--------------------------------
                    BACKSPACE
        --------------------------------*/

        /* Check whether the pressed key is 'x'.
           The 'x' key is assigned as the backspace operation. */
        else if(key == 'x')
        {
            /* Backspace is performed only when at least one digit exists.
               This prevents the digit counter from becoming negative
               and avoids removing digits from an empty number. */
            if(digitCount > 0U)
            {
                /* Remove the last decimal digit using integer division.
                   Example: 123 / 10 = 12.
                   The fractional part is discarded during integer division. */
                value = value / 10U;

                /* Decrease the digit counter because one digit was removed. */
                digitCount--;

                /* Move the LCD cursor to the beginning of the first line. */
                CmdLCD(GOTO_LINE1_POS0);

                /* Write 16 spaces to erase the previously displayed value.
                   This prevents old digits from remaining visible when
                   the newly entered number contains fewer digits. */
                StrLCD("                ");

                /* Return the cursor to the beginning of the first line
                   before displaying the updated number. */
                CmdLCD(GOTO_LINE1_POS0);

                //StrLCD("     ");

                /* Display the updated number only when at least one digit
                   remains after the backspace operation.
                   If the final digit is removed, the LCD remains blank. */
                if(digitCount > 0U)
                    U32LCD(value);
            }
        }

        /*--------------------------------
                     CLEAR
        --------------------------------*/

        /* Check whether the pressed key is 'C'.
           The 'C' key clears the complete numeric input. */
        else if(key == 'C')
        {
            /* Reset the stored numeric value.
               The next numeric key will start a new number. */
            value = 0U;

            /* Reset the digit counter.
               This allows the user to enter up to maxDigits digits again. */
            digitCount = 0U;

            /* Move the LCD cursor to the beginning of the first line. */
            CmdLCD(GOTO_LINE1_POS0);

            /* Clear the previously displayed numeric characters by
               writing 16 blank spaces to the first LCD line. */
            StrLCD("                ");

            /* Return the cursor to the first position of the first line.
               The next entered digit will be displayed from this position. */
            CmdLCD(GOTO_LINE1_POS0);
        }

        /*--------------------------------
                     ACCEPT
        --------------------------------*/

        /* Check whether the pressed key is '='.
           The '=' key indicates that the user has completed numeric entry. */
        else if(key == '=')
        {
            /* Return the completed numeric value to the calling function.
               Returning from this function also terminates the while loop.
               The calling application can then use the entered value. */
            return value;
        }
    }
}

/*
 *==============================================================================
 * END OF FILE
 *
 * MODULE SUMMARY:
 *
 *   InitKPM()
 *       Initializes keypad GPIO directions and initial row states.
 *
 *   ColScan()
 *       Detects whether any keypad column is LOW.
 *
 *   RowCheck()
 *       Identifies the row containing the pressed key.
 *
 *   ColCheck()
 *       Identifies the column containing the pressed key.
 *
 *   KeyScan_NB()
 *       Performs debounced single-key detection and returns the key character.
 *
 *   ReadNumWithService()
 *       Collects a multi-digit number with digit limitation, backspace,
 *       clear, accept and background service support.
 *
 *==============================================================================
 */
```