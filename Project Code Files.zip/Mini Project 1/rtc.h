
/********************************************************************************
 * File Name    : rtc.h
 *
 * Description  : Real-Time Clock (RTC) Driver Header File.
 *
 * Purpose      : This header file provides the public function declarations
 *                required to initialize, configure, read, and display the
 *                Real-Time Clock (RTC) information.
 *
 *                It provides an interface between the application layer and
 *                the RTC driver implementation.
 *
 *                The RTC driver supports the following operations:
 *
 *                1. RTC initialization and configuration.
 *                2. Setting the current time (hours, minutes, seconds).
 *                3. Setting the current date (day, month, year).
 *                4. Setting the day of the week.
 *                5. Reading the current time and date.
 *                6. Reading the current day of the week.
 *                7. Identifying leap years.
 *                8. Calculating the number of days in a given month.
 *                9. Displaying time, date, and day information.
 *
 * Target MCU   : LPC2148
 * Module       : RTC (Real-Time Clock)
 *
 * Dependencies : types.h
 *
 * Author       : Project Development Team
 *
 ********************************************************************************/


#ifndef RTC_H
/*
 * Header Guard - Beginning
 *
 * Prevents multiple inclusion of this header file within a single
 * source file compilation unit.
 *
 * Without a header guard, repeated inclusion may cause compiler errors
 * due to duplicate declarations or definitions.
 *
 * RTC_H is a unique preprocessor macro identifying this header file.
 */
#define RTC_H


#include "types.h"
/*
 * Includes the project-specific data type definitions.
 *
 * Provides standardized integer data types such as:
 * u8  - Unsigned 8-bit integer.
 * u32 - Unsigned 32-bit integer.
 *
 * These types are used in RTC function declarations to maintain
 * consistent data representation across the project.
 */


/*******************************************************************************
 * FUNCTION    : RTC_Init
 *
 * DESCRIPTION : Initializes and configures the RTC peripheral.
 *
 * PURPOSE     : Prepares the RTC hardware for timekeeping operation.
 *
 * OPERATIONS  :
 *               - Configures the RTC clock source.
 *               - Loads the required prescaler values.
 *               - Configures the RTC control register.
 *               - Enables the RTC peripheral.
 *
 * PARAMETERS  : None.
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : Actual hardware configuration is implemented in rtc.c.
 ******************************************************************************/
void RTC_Init(void);


/*******************************************************************************
 * FUNCTION    : RTC_SetTime
 *
 * DESCRIPTION : Sets the RTC time using the specified hour, minute,
 *               and second values.
 *
 * PARAMETERS  :
 *               h - Hour value.
 *               m - Minute value.
 *               s - Second value.
 *
 * PURPOSE     : Allows the application to configure the RTC with
 *               the required time.
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : The caller must provide values within the valid time
 *               ranges supported by the RTC hardware.
 ******************************************************************************/
void RTC_SetTime(u32 h, u32 m, u32 s);


/*******************************************************************************
 * FUNCTION    : RTC_SetDate
 *
 * DESCRIPTION : Sets the calendar date in the RTC peripheral.
 *
 * PARAMETERS  :
 *               d - Day of the month.
 *               m - Month of the year.
 *               y - Year value.
 *
 * PURPOSE     : Updates the RTC calendar registers with the specified
 *               date information.
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : Valid date ranges depend on the month and year.
 *               Leap-year conditions must be considered while validating
 *               February dates.
 ******************************************************************************/
void RTC_SetDate(u32 d, u32 m, u32 y);


/*******************************************************************************
 * FUNCTION    : RTC_SetDay
 *
 * DESCRIPTION : Configures the day-of-week value in the RTC peripheral.
 *
 * PARAMETERS  :
 *               day - Numeric representation of the day of the week.
 *
 * PURPOSE     : Updates the RTC day-of-week register.
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : The numeric mapping of weekdays must be consistent
 *               throughout the application.
 ******************************************************************************/
void RTC_SetDay(u32 day);


/*******************************************************************************
 * FUNCTION    : RTC_GetTime
 *
 * DESCRIPTION : Retrieves the current time from the RTC peripheral.
 *
 * PARAMETERS  :
 *               h - Pointer to store the retrieved hour value.
 *               m - Pointer to store the retrieved minute value.
 *               s - Pointer to store the retrieved second value.
 *
 * PURPOSE     : Provides the application with the latest RTC time.
 *
 * POINTER USAGE:
 *               Addresses of variables are passed to this function.
 *               The function writes the retrieved RTC values into
 *               the memory locations pointed to by these pointers.
 *
 * RETURN      : void - The retrieved values are returned through pointers.
 *
 * NOTE        : The caller must pass valid, writable memory addresses.
 ******************************************************************************/
void RTC_GetTime(u32 *h, u32 *m, u32 *s);


/*******************************************************************************
 * FUNCTION    : RTC_GetDate
 *
 * DESCRIPTION : Retrieves the current calendar date from the RTC.
 *
 * PARAMETERS  :
 *               d - Pointer to store the day-of-month value.
 *               m - Pointer to store the month value.
 *               y - Pointer to store the year value.
 *
 * PURPOSE     : Allows the application to obtain the current RTC date.
 *
 * POINTER USAGE:
 *               The function writes the retrieved date components into
 *               the memory locations provided by the caller.
 *
 * RETURN      : void - Date information is returned through pointers.
 *
 * NOTE        : The caller must pass valid, writable memory addresses.
 ******************************************************************************/
void RTC_GetDate(u32 *d, u32 *m, u32 *y);


/*******************************************************************************
 * FUNCTION    : RTC_GetDay
 *
 * DESCRIPTION : Retrieves the current day-of-week value from the RTC.
 *
 * PARAMETERS  :
 *               day - Pointer to store the retrieved weekday value.
 *
 * PURPOSE     : Provides the application with the current weekday
 *               information.
 *
 * POINTER USAGE:
 *               The function writes the RTC weekday value into the
 *               memory location pointed to by day.
 *
 * RETURN      : void - The weekday value is returned through a pointer.
 ******************************************************************************/
void RTC_GetDay(u32 *day);


/*******************************************************************************
 * FUNCTION    : RTC_IsLeapYear
 *
 * DESCRIPTION : Determines whether the specified year is a leap year.
 *
 * PARAMETERS  :
 *               year - Calendar year to be checked.
 *
 * PURPOSE     : Supports calendar date validation and February day
 *               calculations.
 *
 * LEAP YEAR RULE:
 *               - A year divisible by 400 is a leap year.
 *               - A year divisible by 100 but not by 400 is not a leap year.
 *               - A year divisible by 4 but not by 100 is a leap year.
 *
 * RETURN      :
 *               u8 - Returns a Boolean-style result.
 *                    1 indicates a leap year.
 *                    0 indicates a non-leap year.
 ******************************************************************************/
u8 RTC_IsLeapYear(u32 year);


/*******************************************************************************
 * FUNCTION    : RTC_DaysInMonth
 *
 * DESCRIPTION : Determines the total number of days in the specified month.
 *
 * PARAMETERS  :
 *               month - Month number (1 to 12).
 *               year  - Calendar year used to determine leap-year conditions.
 *
 * PURPOSE     : Provides the correct number of days for calendar validation.
 *
 * OPERATION  :
 *               - January, March, May, July, August, October, December:
 *                 31 days.
 *               - April, June, September, November:
 *                 30 days.
 *               - February:
 *                 28 days in a non-leap year.
 *                 29 days in a leap year.
 *
 * RETURN      :
 *               u8 - Number of days in the specified month.
 *
 * NOTE        : Invalid month handling must be implemented in rtc.c.
 ******************************************************************************/
u8 RTC_DaysInMonth(u32 month, u32 year);


/*******************************************************************************
 * FUNCTION    : RTC_DisplayTime
 *
 * DESCRIPTION : Displays the specified time on the LCD.
 *
 * PARAMETERS  :
 *               h - Hour value to be displayed.
 *               m - Minute value to be displayed.
 *               s - Second value to be displayed.
 *
 * PURPOSE     : Presents the RTC time in a human-readable format.
 *
 * DISPLAY FORMAT:
 *               HH:MM:SS
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : LCD communication and formatting are implemented in rtc.c.
 ******************************************************************************/
void RTC_DisplayTime(u32 h, u32 m, u32 s);


/*******************************************************************************
 * FUNCTION    : RTC_DisplayDate
 *
 * DESCRIPTION : Displays the specified calendar date on the LCD.
 *
 * PARAMETERS  :
 *               d - Day of the month.
 *               m - Month of the year.
 *               y - Calendar year.
 *
 * PURPOSE     : Presents the RTC date in a human-readable format.
 *
 * DISPLAY FORMAT:
 *               DD/MM/YYYY
 *
 * RETURN      : void - Does not return any value.
 *
 * NOTE        : The actual LCD positioning and formatting are handled
 *               by the function implementation in rtc.c.
 ******************************************************************************/
void RTC_DisplayDate(u32 d, u32 m, u32 y);


/*******************************************************************************
 * FUNCTION    : RTC_DisplayDay
 *
 * DESCRIPTION : Displays the day-of-week information on the LCD.
 *
 * PARAMETERS  :
 *               day - Numeric weekday value to be displayed.
 *
 * PURPOSE     : Converts or uses the supplied weekday value to display
 *               the corresponding day name.
 *
 * EXAMPLE     :
 *               SUN, MON, TUE, WED, THU, FRI, SAT.
 *
 * RETURN      : void - Does not return any value.
 ******************************************************************************/
void RTC_DisplayDay(u32 day);


/*
 * Header Guard - Ending
 *
 * Marks the end of the RTC header file.
 * Prevents the declarations in this file from being processed
 * multiple times during compilation.
 */
#endif
