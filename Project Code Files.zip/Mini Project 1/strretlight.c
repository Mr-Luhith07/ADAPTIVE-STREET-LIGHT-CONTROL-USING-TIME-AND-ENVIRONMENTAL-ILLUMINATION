
/*******************************************************************************
 * FILE NAME    : streetlight.c
 *
 * MODULE       : Street Light Control Module
 *
 * DESCRIPTION  :
 *                This module implements the decision-making logic for
 *                automatic street light operation based on RTC scheduling
 *                and ambient light intensity detected through an LDR sensor.
 *
 * FUNCTIONAL OVERVIEW :
 *
 *                The street lights are switched ON only when both of the
 *                following conditions are satisfied:
 *
 *                1. RTC SCHEDULE CONDITION:
 *                   The current RTC time must fall within the configured
 *                   street light operating interval.
 *
 *                2. AMBIENT LIGHT CONDITION:
 *                   The LDR sensor must indicate darkness.
 *
 *                Additionally, the ADC measurement and LDR initialization
 *                status must be valid before enabling the street lights.
 *
 *                If any required condition is not satisfied, the street
 *                lights are switched OFF.
 *
 * SCHEDULE SUPPORT :
 *
 *                - Normal schedule:
 *                  Example: 18:30 to 23:00.
 *
 *                - Overnight schedule:
 *                  Example: 18:30 to 06:00.
 *
 *                - Equal start and end times:
 *                  Treated as a disabled schedule.
 *
 * HARDWARE       : LPC2148
 *
 * PERIPHERALS    :
 *                - RTC : Provides the current time.
 *                - ADC : Acquires the LDR sensor measurement.
 *                - GPIO: Controls the street light output pins.
 *
 * DEPENDENCIES   :
 *                LPC214x.h     - Microcontroller register definitions.
 *                types.h       - Project-specific data types.
 *                project_config.h - Hardware and project configuration.
 *                streetlight.h - Street light module interface.
 *                ldr.h         - LDR sensor driver interface.
 *
 * FAIL-SAFE BEHAVIOUR :
 *                If ADC data is invalid or the LDR driver is not initialized,
 *                the street lights remain OFF.
 *
 *******************************************************************************/


/*
 * Include the LPC214x microcontroller-specific header file.
 *
 * Provides the hardware register definitions required to access
 * the GPIO ports, pin selection registers, and other peripherals.
 *
 * Registers used in this module:
 *
 * PINSEL2 - Configures the pin functions.
 * IODIR1  - Configures Port 1 pins as input or output.
 * IOSET1  - Sets Port 1 output pins HIGH.
 * IOCLR1  - Clears Port 1 output pins LOW.
 */
#include <LPC214x.h>


/*
 * Include project-specific data type definitions.
 *
 * u8  - Unsigned 8-bit integer.
 * u32 - Unsigned 32-bit integer.
 *
 * These types provide consistent integer representation
 * throughout the embedded application.
 */
#include "types.h"


/*
 * Include the project configuration header.
 *
 * Provides project-level hardware configuration and commonly
 * shared macros, including the street light output mask.
 *
 * LIGHT_MASK:
 * Represents the GPIO pins assigned to control the street lights.
 *
 * The actual pin mapping and mask definition are maintained
 * in the project configuration.
 */
#include "project_config.h"


/*
 * Include the street light module interface.
 *
 * Contains the public function declarations and related definitions
 * required to access the street light control module.
 */
#include "streetlight.h"


/*
 * Include the LDR driver interface.
 *
 * Provides access to the LDR sensor status variables used by
 * the street light decision-making logic.
 *
 * Variables used in this module:
 *
 * adcValid       - Indicates whether the latest ADC measurement
 *                  is valid.
 *
 * ldrInitialized - Indicates whether the LDR driver has been
 *                  initialized successfully.
 *
 * ldrDark        - Indicates whether the ambient light condition
 *                  represents darkness.
 */
#include "ldr.h"


/*******************************************************************************
 * GLOBAL CONFIGURATION VARIABLES
 *
 * DESCRIPTION :
 *                These variables define the default street light operating
 *                schedule.
 *
 *                They are declared globally so that the schedule can be
 *                accessed by the street light module functions.
 *
 * NOTE :
 *                These variables are initialized with default values.
 *                If the project supports runtime schedule modification,
 *                the application can update these variables accordingly.
 *******************************************************************************/


/*
 * Default street light activation start hour.
 *
 * Value 18 represents 6:00 PM in the 24-hour clock format.
 *
 * U suffix indicates an unsigned integer constant.
 */
u32 start_hour = 18U;


/*
 * Default street light activation start minute.
 *
 * Value 30 represents the 30th minute.
 *
 * Combined start time: 18:30 (6:30 PM).
 */
u32 start_min  = 30U;


/*
 * Default street light deactivation end hour.
 *
 * Value 6 represents 6:00 AM in the 24-hour clock format.
 *
 * Since the end time is earlier than the start time,
 * this configuration represents an overnight schedule.
 */
u32 end_hour   = 6U;


/*
 * Default street light deactivation end minute.
 *
 * Value 0 represents the beginning of the 6th hour.
 *
 * Combined end time: 06:00 AM.
 */
u32 end_min    = 0U;


/*******************************************************************************
 * FUNCTION NAME : StreetLight_Init
 *
 * DESCRIPTION   :
 *                 Initializes the GPIO hardware used to control the
 *                 street light output lines.
 *
 * FUNCTIONALITY :
 *
 *                 1. Selects GPIO functionality for P1.24 to P1.27.
 *                 2. Configures the selected pins as output pins.
 *                 3. Initializes all street light outputs to LOW.
 *
 * PARAMETERS    : None.
 *
 * RETURN VALUE  : void
 *
 * HARDWARE REGISTERS :
 *
 *                 PINSEL2 - Pin function selection register.
 *                 IODIR1  - Port 1 direction register.
 *                 IOCLR1  - Port 1 output clear register.
 *
 * INITIAL STATE :
 *                 All street light outputs are initialized to OFF.
 *
 *******************************************************************************/
void StreetLight_Init(void)
{
    /*
     * Configure P1.24 to P1.27 as GPIO pins.
     *
     * PINSEL2 controls the alternate functions of Port 1 pins.
     *
     * Each pin function is selected using a 2-bit field.
     *
     * For GPIO operation, the corresponding 2-bit field must be 00.
     *
     * 0xFFU represents eight consecutive bits:
     *
     * 0xFF = 11111111 (binary).
     *
     * Shifting by 16 positions:
     *
     * 0xFFU << 16
     *
     * Produces a mask covering bits 16 to 23.
     *
     * Bitwise NOT (~) inverts this mask.
     *
     * Bitwise AND (&=) clears bits 16 to 23 in PINSEL2
     * while preserving all other register bits.
     *
     * IMPORTANT HARDWARE NOTE:
     * Verify the LPC2148 datasheet for the actual pin-function
     * selection register and pin mapping. PINSEL2 does not generally
     * configure P1.24-P1.27 on the LPC2148; these pins require
     * verification against the device pin-multiplexing table.
     */
    PINSEL2 &= ~(0xFFU << 16);


    /*
     * Configure the street light GPIO pins as OUTPUT.
     *
     * IODIR1 is the Port 1 direction control register.
     *
     * For each GPIO pin:
     *
     * Bit = 0 : Input mode.
     * Bit = 1 : Output mode.
     *
     * LIGHT_MASK identifies the GPIO pins assigned to the street lights.
     *
     * Bitwise OR assignment (|=) sets the selected direction bits
     * without modifying the configuration of other Port 1 pins.
     */
    IODIR1 |= LIGHT_MASK;


    /*
     * Initialize all street light output pins to LOW.
     *
     * IOCLR1 is the Port 1 output clear register.
     *
     * Writing 1 to a corresponding bit clears that output LOW.
     *
     * LIGHT_MASK ensures that only the designated street light
     * output pins are cleared.
     *
     * This establishes a safe initial state in which all
     * street lights are OFF.
     */
    IOCLR1 = LIGHT_MASK;
}


/*******************************************************************************
 * FUNCTION NAME : StreetLight_IsScheduled
 *
 * DESCRIPTION   :
 *                 Determines whether the supplied RTC time falls within
 *                 the configured street light operating schedule.
 *
 * PURPOSE       :
 *                 Evaluates the time-based activation condition independently
 *                 of the LDR sensor and GPIO control logic.
 *
 * PARAMETERS    :
 *                 hour   - Current RTC hour in 24-hour format.
 *                 minute - Current RTC minute.
 *
 * RETURN VALUE  :
 *                 1U - Current time is inside the configured schedule.
 *                 0U - Current time is outside the configured schedule
 *                      or the schedule is disabled.
 *
 * ALGORITHM     :
 *
 *                 Step 1: Convert current time into total minutes.
 *                 Step 2: Convert schedule start time into total minutes.
 *                 Step 3: Convert schedule end time into total minutes.
 *                 Step 4: Check whether the schedule is disabled.
 *                 Step 5: Handle overnight or normal schedules.
 *
 * TIME CONVERSION :
 *
 *                 Total Minutes = (Hour * 60) + Minute
 *
 *                 Example:
 *
 *                 18:30 = (18 * 60) + 30 = 1110 minutes.
 *                 06:00 = (6 * 60) + 0   = 360 minutes.
 *
 * SCHEDULE TYPES :
 *
 *                 Normal:
 *                 Start < End
 *
 *                 Overnight:
 *                 Start > End
 *
 *                 Disabled:
 *                 Start == End
 *
 *******************************************************************************/
u8 StreetLight_IsScheduled(u32 hour, u32 minute)
{
    /*
     * Convert the current RTC time into total minutes from midnight.
     *
     * hour   - Current hour.
     * minute - Current minute.
     * 60U    - Number of minutes in one hour.
     *
     * Example:
     *
     * hour   = 20
     * minute = 15
     *
     * now = (20 * 60) + 15
     *     = 1215 minutes.
     *
     * Converting the time into a single numerical value simplifies
     * time comparisons and eliminates the need for separate
     * hour and minute comparison logic.
     */
    u32 now = (hour * 60U) + minute;


    /*
     * Convert the configured schedule start time into total minutes.
     *
     * Uses the global configuration variables:
     *
     * start_hour - Scheduled activation hour.
     * start_min  - Scheduled activation minute.
     *
     * Example:
     *
     * Start time = 18:30
     *
     * start = (18 * 60) + 30
     *       = 1110 minutes.
     */
    u32 start = (start_hour * 60U) + start_min;


    /*
     * Convert the configured schedule end time into total minutes.
     *
     * Uses the global configuration variables:
     *
     * end_hour - Scheduled deactivation hour.
     * end_min  - Scheduled deactivation minute.
     *
     * Example:
     *
     * End time = 06:00
     *
     * end = (6 * 60) + 0
     *     = 360 minutes.
     */
    u32 end = (end_hour * 60U) + end_min;


    /*
     * Check whether the schedule start and end boundaries are equal.
     *
     * If start == end, the schedule is treated as disabled.
     *
     * Example:
     *
     * Start = 18:30
     * End   = 18:30
     *
     * Both values represent the same time.
     *
     * Therefore, the function returns 0U, indicating that
     * the street light schedule is inactive.
     *
     * IMPORTANT:
     * This is a project-specific scheduling rule.
     * Equal boundaries are not interpreted as a 24-hour schedule.
     */
    if(start == end)
        return 0U;


    /*
     * Check whether the configured schedule crosses midnight.
     *
     * Condition:
     * start > end
     *
     * This indicates an overnight schedule.
     *
     * Example:
     *
     * Start = 18:30 = 1110 minutes.
     * End   = 06:00 = 360 minutes.
     *
     * Since 1110 > 360, the schedule crosses midnight.
     *
     * Overnight schedule logic:
     *
     * The current time must satisfy either:
     *
     * Condition 1:
     * now >= start
     *
     * Meaning:
     * Current time is after or equal to the start boundary.
     *
     * OR
     *
     * Condition 2:
     * now < end
     *
     * Meaning:
     * Current time is before the end boundary.
     *
     * The logical OR operator (||) combines these conditions.
     *
     * Ternary operator:
     *
     * condition ? 1U : 0U
     *
     * Returns:
     * 1U if the overnight schedule is active.
     * 0U otherwise.
     *
     * Boundary behaviour:
     * Start time is inclusive.
     * End time is exclusive.
     *
     * Example:
     *
     * 20:00 -> Active.
     * 23:00 -> Active.
     * 02:00 -> Active.
     * 05:59 -> Active.
     * 06:00 -> Inactive.
     * 12:00 -> Inactive.
     */
    if(start > end)
        return ((now >= start) || (now < end)) ? 1U : 0U;


    /*
     * Handle a normal same-day operating schedule.
     *
     * This condition executes when:
     *
     * start < end
     *
     * Example:
     *
     * Start = 08:00 = 480 minutes.
     * End   = 18:00 = 1080 minutes.
     *
     * The current time must satisfy both conditions:
     *
     * Condition 1:
     * now >= start
     *
     * Current time must be greater than or equal to
     * the configured start time.
     *
     * Condition 2:
     * now < end
     *
     * Current time must be earlier than the configured end time.
     *
     * Logical AND operator (&&):
     * Both conditions must be TRUE for the schedule to be active.
     *
     * Ternary operator:
     *
     * condition ? 1U : 0U
     *
     * Returns:
     * 1U if the current time is within the schedule.
     * 0U if the current time is outside the schedule.
     *
     * Boundary behaviour:
     * Start time is inclusive.
     * End time is exclusive.
     *
     * Example:
     *
     * 08:00 -> Active.
     * 12:00 -> Active.
     * 17:59 -> Active.
     * 18:00 -> Inactive.
     * 20:00 -> Inactive.
     *
     * This is the final return statement because all possible
     * schedule configurations have already been handled.
     */
    return ((now >= start) && (now < end)) ? 1U : 0U;
}


/*******************************************************************************
 * FUNCTION NAME : StreetLight_Control
 *
 * DESCRIPTION   :
 *                 Controls the street light GPIO outputs based on
 *                 RTC scheduling, LDR darkness detection, and sensor
 *                 initialization/data validity status.
 *
 * PURPOSE       :
 *                 Implements the final decision-making logic of the
 *                 adaptive street light control system.
 *
 * PARAMETERS    :
 *                 hour   - Current RTC hour in 24-hour format.
 *                 minute - Current RTC minute.
 *
 * RETURN VALUE  :
 *                 void - Does not return any value.
 *
 * ACTIVATION CONDITIONS :
 *
 *                 1. adcValid must be TRUE.
 *                 2. ldrInitialized must be TRUE.
 *                 3. RTC schedule must be active.
 *                 4. LDR must indicate darkness.
 *
 * OUTPUT CONTROL :
 *
 *                 All conditions TRUE:
 *                 Street lights ON.
 *
 *                 Any condition FALSE:
 *                 Street lights OFF.
 *
 * FAIL-SAFE STRATEGY :
 *
 *                 Invalid ADC measurement or an uninitialized LDR
 *                 driver results in the street lights being switched OFF.
 *
 *******************************************************************************/
void StreetLight_Control(u32 hour, u32 minute)
{
    /*
     * Evaluate all conditions required to activate the street lights.
     *
     * Logical AND operator (&&):
     * Every condition must evaluate to TRUE.
     *
     * CONDITION 1:
     *
     * adcValid
     *
     * Indicates whether the ADC conversion result is valid.
     *
     * A valid ADC result is required before trusting the LDR
     * darkness detection decision.
     *
     * CONDITION 2:
     *
     * ldrInitialized
     *
     * Confirms that the LDR driver has been initialized.
     *
     * Prevents the street light control logic from using
     * sensor information before driver initialization.
     *
     * CONDITION 3:
     *
     * StreetLight_IsScheduled(hour, minute)
     *
     * Checks whether the current RTC time falls within
     * the configured street light operating schedule.
     *
     * Returns:
     * 1U - Schedule active.
     * 0U - Schedule inactive.
     *
     * CONDITION 4:
     *
     * ldrDark
     *
     * Indicates whether the LDR driver has detected darkness.
     *
     * TRUE  - Ambient light level represents darkness.
     * FALSE - Ambient light level represents sufficient brightness.
     *
     * FINAL DECISION:
     *
     * adcValid && ldrInitialized &&
     * StreetLight_IsScheduled(hour, minute) && ldrDark
     *
     * Only when all four conditions are TRUE will the street lights
     * be switched ON.
     *
     * NOTE:
     * C evaluates logical AND expressions from left to right
     * with short-circuit behaviour.
     *
     * Therefore, later conditions are not evaluated when an
     * earlier condition is FALSE.
     */
    if(adcValid && ldrInitialized &&
       StreetLight_IsScheduled(hour, minute) && ldrDark)
    {
        /*
         * Switch ON all street light output pins.
         *
         * IOSET1 is the Port 1 output set register.
         *
         * Writing 1 to the corresponding bits drives the selected
         * GPIO output pins HIGH.
         *
         * LIGHT_MASK selects only the pins connected to the
         * street light control circuit.
         *
         * Other Port 1 output pins remain unaffected.
         *
         * This operation is executed only when:
         *
         * - ADC measurement is valid.
         * - LDR driver is initialized.
         * - RTC schedule is active.
         * - Darkness is detected.
         *
         * HARDWARE NOTE:
         * Whether HIGH switches a physical lamp ON depends on
         * the external driver circuit and its active-HIGH/
         * active-LOW configuration.
         */
        IOSET1 = LIGHT_MASK;
    }
    else
    {
        /*
         * Switch OFF all street light output pins.
         *
         * IOCLR1 is the Port 1 output clear register.
         *
         * Writing 1 to the corresponding bits drives the selected
         * GPIO output pins LOW.
         *
         * This branch executes if even one activation condition
         * evaluates to FALSE.
         *
         * Possible reasons:
         *
         * - ADC measurement is invalid.
         * - LDR driver is not initialized.
         * - RTC schedule is inactive.
         * - Ambient light condition indicates brightness.
         *
         * This implements the project's fail-safe decision:
         * Do not energize the street lights when the required
         * sensor or scheduling conditions are not satisfied.
         */
        IOCLR1 = LIGHT_MASK;
    }
}


/*******************************************************************************
 * END OF FILE : streetlight.c
 *
 * MODULE SUMMARY :
 *
 *                 StreetLight_Init()
 *                 Initializes GPIO pins and establishes the OFF state.
 *
 *                 StreetLight_IsScheduled()
 *                 Determines whether the current time falls within
 *                 the configured operating schedule.
 *
 *                 StreetLight_Control()
 *                 Combines RTC scheduling and LDR sensor conditions
 *                 to control the street light outputs.
 *
 *                 Overall Decision:
 *
 *                 LIGHTS_ON =
 *                 ADC_VALID AND
 *                 LDR_INITIALIZED AND
 *                 RTC_SCHEDULE_ACTIVE AND
 *                 DARKNESS_DETECTED
 *
 *******************************************************************************/
