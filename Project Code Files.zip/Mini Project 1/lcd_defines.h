```c
/*
 *==============================================================================
 * File Name    : lcd_defines.h
 * Module Name  : LCD Configuration and Command Definitions
 * Target MCU   : LPC2148
 * LCD Type     : HD44780-Compatible Character LCD
 * Interface    : 8-Bit Parallel Interface
 *
 * Description:
 *   This header file contains the predefined LCD controller instruction
 *   commands and GPIO pin-position definitions required by the LCD driver.
 *
 *   It provides a centralized location for LCD configuration values so
 *   that the driver source file (lcd.c) can use meaningful macro names
 *   instead of directly using hexadecimal command values and pin numbers.
 *
 * Main Responsibilities:
 *   1. Define LCD clear-display and cursor-control commands.
 *   2. Define display ON/OFF and cursor configuration commands.
 *   3. Define cursor and display shifting commands.
 *   4. Define LCD operating mode configuration.
 *   5. Define LCD DDRAM and CGRAM address commands.
 *   6. Define LPC2148 GPIO pin positions connected to the LCD.
 *
 * Hardware Connections:
 *   LCD D0-D7  -> LPC2148 P0.8-P0.15
 *   LCD RS     -> LPC2148 P0.4
 *   LCD EN     -> LPC2148 P0.17
 *   LCD RW     -> LPC2148 P0.18
 *
 * Dependencies:
 *   This file is included by lcd.c and other modules that require
 *   LCD command or pin definitions.
 *
 *==============================================================================
 */


/*==============================================================================
 * HEADER GUARD
 *==============================================================================
 *
 * Prevents multiple inclusions of this header file within the same
 * compilation unit.
 *
 * LCD_DEFINES_H is defined during the first inclusion.
 * Subsequent inclusions skip the contents of this file.
 *
 * This avoids repeated macro definitions during compilation.
 */

#ifndef LCD_DEFINES_H
#define LCD_DEFINES_H


/*==============================================================================
 * LCD INSTRUCTION COMMAND DEFINITIONS
 *==============================================================================
 *
 * The following macros represent instruction codes understood by an
 * HD44780-compatible LCD controller.
 *
 * These commands are transferred to the LCD through the 8-bit data bus
 * while the RS pin is LOW (RS = 0).
 *
 * The LCD controller interprets each command and performs the
 * corresponding display, cursor or memory operation.
 */


/*
 * Command Name : CLEAR_LCD
 * Command Value: 0x01
 *
 * Description:
 *   Clears all characters currently displayed on the LCD.
 *
 * Operation:
 *   1. Clears the display contents.
 *   2. Sets the DDRAM address counter to address 0.
 *   3. Returns the cursor to the first position of the first line.
 *
 * Note:
 *   This command requires a longer execution time than most ordinary
 *   LCD instructions. The driver must provide the required delay.
 */
#define CLEAR_LCD          0x01


/*
 * Command Name : RET_CUR_HOME
 * Command Value: 0x02
 *
 * Description:
 *   Returns the LCD cursor to its home position.
 *
 * Operation:
 *   1. Sets the DDRAM address counter to address 0.
 *   2. Moves the cursor to the first character position of the display.
 *
 * Note:
 *   Unlike CLEAR_LCD, this command does not erase the displayed characters.
 */
#define RET_CUR_HOME       0x02


/*
 * Command Name : SHIFT_CUR_RIGHT
 * Command Value: 0x06
 *
 * Description:
 *   Configures the LCD entry mode so that the cursor automatically
 *   moves one position to the right after each character is written.
 *
 * Operation:
 *   Sets the Entry Mode Set instruction with:
 *     I/D = 1 : Increment the DDRAM address after writing.
 *     S   = 0 : Do not shift the entire display.
 *
 * Note:
 *   This is commonly used when displaying strings from left to right.
 */
#define SHIFT_CUR_RIGHT    0x06


/*
 * Command Name : SHIFT_CUR_LEFT
 * Command Value: 0x07
 *
 * Description:
 *   Configures the LCD entry mode so that the cursor automatically
 *   moves one position to the left after each character is written.
 *
 * Operation:
 *   Sets the Entry Mode Set instruction with:
 *     I/D = 0 : Decrement the DDRAM address after writing.
 *     S   = 1 : Shift the display according to the entry-mode setting.
 *
 * Note:
 *   Despite the macro name, this command also enables display shifting.
 */
#define SHIFT_CUR_LEFT     0x07


/*
 * Command Name : DSP_OFF
 * Command Value: 0x08
 *
 * Description:
 *   Turns OFF the LCD display output.
 *
 * Operation:
 *   Sends the Display ON/OFF Control instruction with:
 *     D = 0 : Display OFF.
 *     C = 0 : Cursor OFF.
 *     B = 0 : Cursor blinking OFF.
 *
 * Note:
 *   Turning the display OFF does not erase the contents stored in DDRAM.
 *   The stored characters can become visible again when the display
 *   is enabled.
 */
#define DSP_OFF            0x08


/*
 * Command Name : DSP_ON_CUR_OFF
 * Command Value: 0x0C
 *
 * Description:
 *   Turns ON the LCD display while keeping the cursor invisible.
 *
 * Operation:
 *   Sends the Display ON/OFF Control instruction with:
 *     D = 1 : Display ON.
 *     C = 0 : Cursor OFF.
 *     B = 0 : Cursor blinking OFF.
 *
 * Application:
 *   Useful when displaying messages, sensor values, time and date
 *   without showing the cursor.
 */
#define DSP_ON_CUR_OFF     0x0C


/*
 * Command Name : DSP_ON_CUR_BLK
 * Command Value: 0x0E
 *
 * Description:
 *   Turns ON the LCD display and enables the cursor.
 *
 * Operation:
 *   Sends the Display ON/OFF Control instruction with:
 *     D = 1 : Display ON.
 *     C = 1 : Cursor ON.
 *     B = 0 : Cursor blinking OFF.
 *
 * Application:
 *   Useful when indicating the current editing position while entering
 *   time, date or other values through the keypad.
 */
#define DSP_ON_CUR_BLK     0x0E


/*
 * Command Name : SHIFT_DSP_LEFT
 * Command Value: 0x10
 *
 * Description:
 *   Shifts the entire displayed contents one position to the left.
 *
 * Operation:
 *   Sends the Cursor/Display Shift instruction with:
 *     S/C = 1 : Shift the display.
 *     R/L = 0 : Shift the display to the left.
 *
 * Note:
 *   The cursor position is not moved independently by this command.
 *   Instead, the visible display window shifts.
 */
#define SHIFT_DSP_LEFT     0x10


/*
 * Command Name : SHIFT_DSP_RIGHT
 * Command Value: 0x14
 *
 * Description:
 *   Shifts the entire displayed contents one position to the right.
 *
 * Operation:
 *   Sends the Cursor/Display Shift instruction with:
 *     S/C = 1 : Shift the display.
 *     R/L = 1 : Shift the display to the right.
 *
 * Note:
 *   This command changes the visible display position rather than
 *   simply moving the cursor.
 */
#define SHIFT_DSP_RIGHT    0x14


/*
 * Command Name : MODE_8BIT_2LINE
 * Command Value: 0x38
 *
 * Description:
 *   Configures the LCD controller for 8-bit data communication
 *   and two-line display operation.
 *
 * Operation:
 *   Sends the Function Set instruction with:
 *     DL = 1 : 8-bit interface mode.
 *     N  = 1 : Two-line display mode.
 *     F  = 0 : 5x8 dot character font.
 *
 * Hardware Requirement:
 *   All eight LCD data lines D0-D7 must be connected and configured
 *   correctly for 8-bit communication.
 *
 * Note:
 *   This configuration is used during LCD initialization.
 */
#define MODE_8BIT_2LINE    0x38


/*
 * Command Name : GOTO_LINE1_POS0
 * Command Value: 0x80
 *
 * Description:
 *   Sets the LCD cursor to the first character position of the first line.
 *
 * Operation:
 *   Sends the Set DDRAM Address instruction.
 *   The command sets the DDRAM address counter to address 0x00.
 *
 * Application:
 *   Used to position the cursor at the beginning of the first LCD line.
 */
#define GOTO_LINE1_POS0    0x80


/*
 * Command Name : GOTO_LINE2_POS0
 * Command Value: 0xC0
 *
 * Description:
 *   Sets the LCD cursor to the first character position of the second line.
 *
 * Operation:
 *   Sends the Set DDRAM Address instruction.
 *   The command sets the DDRAM address counter to address 0x40.
 *
 * Application:
 *   Used to display information on the second line of a typical
 *   16x2 character LCD.
 *
 * Note:
 *   This address is commonly used by standard HD44780-compatible
 *   16x2 LCD modules.
 */
#define GOTO_LINE2_POS0    0xC0


/*
 * Command Name : GOTO_CGRAM_START
 * Command Value: 0x40
 *
 * Description:
 *   Selects the starting address of the LCD Character Generator RAM
 *   (CGRAM).
 *
 * Operation:
 *   Sends the Set CGRAM Address instruction.
 *   The command selects CGRAM address 0x00.
 *
 * Application:
 *   Used before writing custom character pattern data into CGRAM.
 *
 * Note:
 *   CGRAM stores user-defined character patterns.
 *   A typical HD44780-compatible LCD supports eight custom 5x8 characters.
 */
#define GOTO_CGRAM_START   0x40


/*==============================================================================
 * LCD HARDWARE PIN DEFINITIONS
 *==============================================================================
 *
 * The following macros define the LPC2148 GPIO bit positions connected
 * to the LCD data and control signals.
 *
 * These values represent GPIO bit positions, not complete port numbers.
 *
 * Port Used:
 *   GPIO Port 0 (IOPIN0, IOSET0, IOCLR0, IODIR0).
 *
 * The LCD driver uses these definitions to configure the GPIO direction
 * and control the LCD through the microcontroller.
 */


/*
 * Macro Name : LCD_DATA
 * Value      : 8U
 *
 * Description:
 *   Defines the starting GPIO bit position of the LCD 8-bit data bus.
 *
 * Hardware Mapping:
 *   LCD D0 -> P0.8
 *   LCD D1 -> P0.9
 *   LCD D2 -> P0.10
 *   LCD D3 -> P0.11
 *   LCD D4 -> P0.12
 *   LCD D5 -> P0.13
 *   LCD D6 -> P0.14
 *   LCD D7 -> P0.15
 *
 * Usage:
 *   (0xFFU << LCD_DATA)
 *
 *   Selects GPIO Port 0 bits 8 through 15.
 *
 *   The LCD data byte is shifted left by LCD_DATA before being
 *   written to the GPIO output register.
 *
 * Note:
 *   U indicates that the constant is unsigned.
 */
#define LCD_DATA 8U


/*
 * Macro Name : LCD_RS
 * Value      : 4U
 *
 * Description:
 *   Defines the GPIO bit position connected to the LCD Register Select pin.
 *
 * Hardware Mapping:
 *   LCD RS -> P0.4
 *
 * Function:
 *   RS = 0 : Selects the instruction/command register.
 *   RS = 1 : Selects the data register.
 *
 * Usage:
 *   (1U << LCD_RS)
 *
 *   Generates a bit mask for GPIO Port 0 bit 4.
 */
#define LCD_RS   4U


/*
 * Macro Name : LCD_EN
 * Value      : 17U
 *
 * Description:
 *   Defines the GPIO bit position connected to the LCD Enable pin.
 *
 * Hardware Mapping:
 *   LCD EN -> P0.17
 *
 * Function:
 *   The Enable signal controls the transfer of commands and data
 *   between the microcontroller and the LCD controller.
 *
 * Operation:
 *   The LCD accepts the data or command using the required Enable
 *   signal transition, subject to the controller timing specifications.
 *
 * Usage:
 *   (1U << LCD_EN)
 *
 *   Generates a bit mask for GPIO Port 0 bit 17.
 */
#define LCD_EN   17U


/*
 * Macro Name : LCD_RW
 * Value      : 18U
 *
 * Description:
 *   Defines the GPIO bit position connected to the LCD Read/Write pin.
 *
 * Hardware Mapping:
 *   LCD RW -> P0.18
 *
 * Function:
 *   RW = 0 : Selects write operation.
 *   RW = 1 : Selects read operation.
 *
 * Application:
 *   In the current LCD driver, RW is driven LOW before writing commands
 *   or character data to the LCD.
 *
 * Note:
 *   The LCD driver uses fixed delays instead of reading the LCD busy flag.
 *   Therefore, RW remains LOW during normal write operations.
 */
#define LCD_RW   18U


/*==============================================================================
 * END OF LCD CONFIGURATION HEADER
 *==============================================================================
 *
 * All LCD command values and hardware pin definitions are declared above.
 *
 * These definitions are shared with the LCD driver and application modules.
 */

#endif
```