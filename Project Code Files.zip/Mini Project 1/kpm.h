```c
/*
 *==============================================================================
 * File Name   : kpm.h
 * Module Name : 4x4 Matrix Keypad Driver - Header File
 * Controller  : LPC2148
 *
 * Description:
 *   This header file provides the public interface for the 4x4 matrix keypad
 *   driver.
 *
 *   It contains function declarations required by the application program
 *   and other software modules to interact with the keypad driver.
 *
 *   The actual function implementations are available in kpm.c.
 *
 * Hardware Configuration:
 *
 *   ROW PINS (GPIO OUTPUTS):
 *       ROW0 -> P1.16
 *       ROW1 -> P1.17
 *       ROW2 -> P1.18
 *       ROW3 -> P1.19
 *
 *   COLUMN PINS (GPIO INPUTS):
 *       COL0 -> P1.20
 *       COL1 -> P1.21
 *       COL2 -> P1.22
 *       COL3 -> P1.23
 *
 * Driver Functionalities:
 *   1. Keypad GPIO initialization.
 *   2. Column scanning.
 *   3. Row identification.
 *   4. Column identification.
 *   5. Debounced keypad key detection.
 *   6. Numeric input with a configurable digit limit.
 *   7. Background service execution during numeric input.
 *
 *==============================================================================
 */


/*------------------------------------------------------------------------------
 * HEADER GUARD
 *
 * Purpose:
 *   Prevents this header file from being included multiple times within
 *   the same compilation unit.
 *
 * Working:
 *   1. The preprocessor checks whether KPM_H has already been defined.
 *   2. If it has not been defined, the contents of this header are processed.
 *   3. The #define directive marks KPM_H as defined.
 *   4. If this header is included again, its contents are skipped.
 *
 * Importance:
 *   Prevents duplicate declarations and related compilation problems
 *   caused by repeated header-file inclusion.
 *------------------------------------------------------------------------------*/

#ifndef KPM_H
#define KPM_H


/*------------------------------------------------------------------------------
 * HEADER FILE DEPENDENCY
 *
 * types.h:
 *   Provides project-specific data type definitions.
 *
 *   Data types used in this interface:
 *       u8  -> Unsigned 8-bit integer.
 *       u32 -> Unsigned 32-bit integer.
 *
 *   These types are used in function parameters and return declarations
 *   to maintain consistent data-width definitions throughout the project.
 *------------------------------------------------------------------------------*/

#include "types.h"


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : InitKPM
 *
 * DESCRIPTION:
 *   Initializes the GPIO pins required for interfacing the 4x4 matrix keypad
 *   with the LPC2148 microcontroller.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   void
 *
 *   No value is returned.
 *
 * USAGE:
 *   Called once during system initialization before using the keypad.
 *
 * NOTE:
 *   The function declaration informs the compiler about the function
 *   interface. Its implementation is available in kpm.c.
 *------------------------------------------------------------------------------*/

void InitKPM(void);


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : ColScan
 *
 * DESCRIPTION:
 *   Checks the electrical states of all four keypad column input pins
 *   to determine whether a key press is present.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   u8
 *
 * RETURN VALUES:
 *   0 -> At least one column is LOW; a possible key press is detected.
 *   1 -> All four columns are HIGH; no key press is detected.
 *
 * USAGE:
 *   Used during keypad scanning to detect a possible key press.
 *------------------------------------------------------------------------------*/

u8 ColScan(void);


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : RowCheck
 *
 * DESCRIPTION:
 *   Identifies the keypad row corresponding to the pressed key by
 *   activating the row output pins one at a time and checking the
 *   column input states.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   u8
 *
 * RETURN VALUES:
 *   0    -> ROW0 is detected.
 *   1    -> ROW1 is detected.
 *   2    -> ROW2 is detected.
 *   3    -> ROW3 is detected.
 *   0xFF -> Invalid row or no valid row detected.
 *
 * USAGE:
 *   Called during key identification after a possible key press
 *   has been detected.
 *------------------------------------------------------------------------------*/

u8 RowCheck(void);


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : ColCheck
 *
 * DESCRIPTION:
 *   Identifies the keypad column corresponding to the pressed key by
 *   examining the four column input pins.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   u8
 *
 * RETURN VALUES:
 *   0    -> COL0 is detected.
 *   1    -> COL1 is detected.
 *   2    -> COL2 is detected.
 *   3    -> COL3 is detected.
 *   0xFF -> Invalid column or no valid column detected.
 *
 * USAGE:
 *   Called after RowCheck() has identified and activated the corresponding
 *   keypad row.
 *------------------------------------------------------------------------------*/

u8 ColCheck(void);


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : KeyScan_NB
 *
 * DESCRIPTION:
 *   Scans the keypad and returns the ASCII character corresponding to
 *   a newly pressed and debounced key.
 *
 *   NB represents Non-Blocking key scanning.
 *
 * PARAMETERS:
 *   None.
 *
 * RETURN TYPE:
 *   u8
 *
 * RETURN VALUES:
 *   0       -> No new valid key press is available.
 *   Non-zero -> ASCII character corresponding to the detected keypad key.
 *
 * SUPPORTED KEY VALUES:
 *   '0' to '9' -> Numeric keys.
 *   'C'        -> Clear key.
 *   'x'        -> Backspace key.
 *   '='        -> Enter/accept key.
 *   Other characters depend on the keypad lookup table.
 *
 * FEATURES:
 *   - Software switch debouncing.
 *   - Single-key press detection.
 *   - Prevents repeated reporting while a key remains pressed.
 *   - Rearms key detection after the keypad is released.
 *
 * USAGE:
 *   Called repeatedly by the application whenever keypad input is required.
 *------------------------------------------------------------------------------*/

u8 KeyScan_NB(void);


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : ReadNumWithService1
 *
 * DESCRIPTION:
 *   Declares an additional numeric-input function that accepts a background
 *   service callback.
 *
 * PARAMETERS:
 *   service:
 *       Pointer to a function that takes no arguments and returns no value.
 *
 *       The callback can be used to execute background application operations
 *       while numeric keypad input is being collected.
 *
 * RETURN TYPE:
 *   u32
 *
 *   Returns an unsigned 32-bit integer representing the entered number.
 *
 * IMPORTANT:
 *   This prototype does not specify a maximum digit parameter.
 *   Its exact behaviour depends on the implementation provided in kpm.c.
 *
 * NOTE:
 *   A function pointer allows one software module to execute a function
 *   supplied by another module without directly depending on its implementation.
 *------------------------------------------------------------------------------*/

u32 ReadNumWithService1(void (*service)(void));


/*------------------------------------------------------------------------------
 * FUNCTION PROTOTYPE : ReadNumWithService
 *
 * DESCRIPTION:
 *   Declares the numeric keypad input function with a configurable
 *   maximum digit limit and a background service callback.
 *
 * PARAMETERS:
 *
 *   maxDigits:
 *       Specifies the maximum number of numeric digits that can be entered.
 *
 *       Example:
 *           maxDigits = 2 -> Accepts at most two digits.
 *           maxDigits = 4 -> Accepts at most four digits.
 *
 *   service:
 *       Function pointer to a background service function.
 *
 *       Function pointer declaration:
 *           void (*service)(void)
 *
 *       Explanation:
 *           void     -> The callback returns no value.
 *           (*service) -> service is a pointer to a function.
 *           (void)   -> The callback accepts no arguments.
 *
 *       If a valid callback is supplied, the numeric-input function can
 *       execute that callback while waiting for keypad input.
 *
 * RETURN TYPE:
 *   u32
 *
 *   Returns the final unsigned 32-bit decimal number when the user
 *   presses the '=' key.
 *
 * SUPPORTED OPERATIONS:
 *   Numeric keys -> Append digits to the current number.
 *   'x'          -> Remove the last entered digit.
 *   'C'          -> Clear the complete numeric input.
 *   '='          -> Accept the entered number and return it.
 *
 * USAGE EXAMPLE:
 *
 *   value = ReadNumWithService(4, RTC_Service);
 *
 *   The function accepts a maximum of four digits and calls RTC_Service()
 *   while waiting for keypad input.
 *
 * NOTE:
 *   Passing 0 as the service argument indicates that no background
 *   callback is supplied.
 *------------------------------------------------------------------------------*/

u32 ReadNumWithService(u8 maxDigits,void (*service)(void));


/*------------------------------------------------------------------------------
 * END OF HEADER GUARD
 *
 * Closes the conditional compilation block opened by #ifndef KPM_H.
 *
 * This completes the protected declaration section of kpm.h.
 *------------------------------------------------------------------------------*/

#endif


/*
 *==============================================================================
 * END OF FILE : kpm.h
 *
 * MODULE INTERFACE SUMMARY:
 *
 *   InitKPM()             -> Initializes keypad GPIO pins.
 *   ColScan()             -> Detects a possible key press.
 *   RowCheck()            -> Identifies the pressed row.
 *   ColCheck()            -> Identifies the pressed column.
 *   KeyScan_NB()          -> Returns a newly detected keypad character.
 *   ReadNumWithService1() -> Declares numeric input with a service callback.
 *   ReadNumWithService()  -> Declares numeric input with digit limitation
 *                            and a service callback.
 *
 *==============================================================================
 */
```