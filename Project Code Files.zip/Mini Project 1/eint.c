```c
/*
 * File Name   : eint.c
 * Description : External Interrupt 0 (EINT0) driver implementation
 *               for the LPC2148 microcontroller.
 *
 * Hardware Peripheral:
 * External Interrupt 0 (EINT0).
 *
 * Interrupt Configuration:
 * Interrupt Source : EINT0.
 * GPIO Pin         : P0.1.
 * Pin Function     : 11 (EINT0 alternate function).
 * VIC Channel      : 14.
 * Trigger Mode     : Edge-sensitive.
 * Trigger Edge     : Falling edge.
 *
 * Purpose:
 * This driver configures and handles the external interrupt
 * generated through the EINT0 input pin.
 *
 * In the Adaptive Street Light application, the EINT0 push-button
 * is used to generate a menu request when the user wants to enter
 * the RTC/settings menu.
 *
 * Functional Overview:
 * 1. Configures P0.1 as the EINT0 alternate function.
 * 2. Configures the interrupt as falling-edge triggered.
 * 3. Clears any previously pending external interrupt flag.
 * 4. Configures the Vectored Interrupt Controller (VIC).
 * 5. Registers the EINT0 Interrupt Service Routine.
 * 6. Enables the corresponding interrupt channel.
 * 7. Sets a software request flag when the interrupt occurs.
 *
 * Design Considerations:
 * The Interrupt Service Routine (ISR) performs only the minimum
 * required operations to reduce interrupt servicing time.
 *
 * The main application can monitor menuRequest and perform
 * the actual menu-processing operations outside the ISR.
 */


/*
 * Include LPC2148 device-specific register definitions.
 *
 * Provides access to the microcontroller's hardware registers,
 * including:
 *
 * PINSEL0       : Pin function selection register.
 * EXTMODE       : External interrupt trigger mode register.
 * EXTPOLAR      : External interrupt polarity selection register.
 * EXTINT        : External interrupt flag register.
 * VICIntSelect  : Interrupt type selection register.
 * VICVectAddr0  : VIC vector address register for slot 0.
 * VICVectCntl0  : VIC vector control register for slot 0.
 * VICIntEnable  : VIC interrupt enable register.
 * VICVectAddr   : VIC vector address/current interrupt service register.
 */

#include <LPC214x.h>


/*
 * Include external interrupt driver declarations.
 *
 * Provides the function prototype for EINT0_Init()
 * and allows other application modules to access
 * the external interrupt initialization interface.
 */

#include "eint.h"


/*
 * VIC Interrupt Channel Configuration.
 *
 * Defines the Vectored Interrupt Controller channel number
 * assigned to External Interrupt 0 (EINT0).
 *
 * EINT0 VIC Channel : 14.
 *
 * The VIC uses interrupt channel numbers to identify
 * different interrupt sources connected to the controller.
 *
 * This channel number is used during interrupt vector
 * configuration and interrupt enable operations.
 *
 * The U suffix indicates an unsigned integer constant.
 */

#define EINT0_VIC_CHANNEL 14U


/*
 * Global Menu Request Flag.
 *
 * Declares a global variable used for communication between
 * the EINT0 Interrupt Service Routine and the main application.
 *
 * Initial Value : 0U.
 *
 * Functional Operation:
 * 0U : No menu request is pending.
 * 1U : An EINT0 interrupt has generated a menu request.
 *
 * The volatile qualifier prevents the compiler from assuming
 * that this variable remains unchanged during program execution.
 *
 * This is necessary because the variable can be modified
 * asynchronously by the interrupt service routine.
 *
 * The main application can periodically check this flag
 * and perform the requested menu operation.
 *
 * Note:
 * Only a short flag-setting operation is performed inside
 * the ISR. Actual menu processing is handled outside the ISR.
 */

volatile unsigned int menuRequest = 0U;


/*
 * Function Name : EINT0_ISR
 *
 * Description:
 * Interrupt Service Routine (ISR) for External Interrupt 0.
 *
 * Execution Condition:
 * This function is automatically invoked by the processor
 * when the configured EINT0 interrupt occurs and is accepted
 * by the interrupt controller.
 *
 * Interrupt Source:
 * EINT0 on P0.1.
 *
 * Trigger Condition:
 * Falling-edge transition on the configured EINT0 input.
 *
 * Working:
 * 1. Sets the menuRequest flag to indicate a menu request.
 * 2. Clears the pending EINT0 interrupt flag.
 * 3. Notifies the VIC that interrupt servicing is complete.
 *
 * Function Attribute:
 * __irq indicates that this function is an interrupt handler
 * using the interrupt return mechanism supported by the
 * ARM toolchain.
 *
 * Return Type:
 * void : Does not return an application-level value.
 *
 * Design Consideration:
 * ISR execution should be kept short to minimize interrupt
 * latency and allow the processor to resume normal execution
 * as quickly as possible.
 */

void EINT0_ISR(void) __irq
{
    // Set the global menu request flag to indicate that
    // an external interrupt has occurred.
    //
    // The main application monitors this flag and performs
    // the menu-entry operation outside the interrupt context.
    //
    // Setting a flag instead of executing the complete menu
    // logic inside the ISR reduces interrupt servicing time.

    menuRequest = 1U;


    // Clear the EINT0 interrupt flag by writing 1 to bit 0
    // of the External Interrupt Flag Register (EXTINT).
    //
    // Hardware Operation:
    // EXTINT bit 0 corresponds to the EINT0 interrupt source.
    //
    // Writing 1 clears the pending interrupt flag.
    // This prevents the previously serviced interrupt event
    // from remaining pending in the external interrupt controller.
    //
    // Note:
    // EXTINT uses write-one-to-clear behavior for its interrupt flags.

    EXTINT = 1U;


    // Signal the Vectored Interrupt Controller (VIC) that
    // the current interrupt service routine has completed.
    //
    // Writing zero to VICVectAddr indicates the end of
    // interrupt servicing and allows the VIC to process
    // other pending interrupt requests.
    //
    // This operation is required when using the VIC
    // vectored interrupt mechanism.

    VICVectAddr = 0U;
}


/*
 * Function Name : EINT0_Init
 *
 * Description:
 * Initializes and enables the External Interrupt 0 peripheral
 * using the LPC2148 Vectored Interrupt Controller.
 *
 * Arguments:
 * None.
 *
 * Return Type:
 * void : Does not return any value.
 *
 * Initialization Sequence:
 *
 * 1. Configure P0.1 as EINT0 alternate function.
 * 2. Configure external interrupt trigger mode.
 * 3. Configure falling-edge polarity.
 * 4. Clear any pending EINT0 interrupt flag.
 * 5. Configure the interrupt as an IRQ source.
 * 6. Register the EINT0 ISR in VIC vector slot 0.
 * 7. Enable the selected VIC vector slot.
 * 8. Enable the EINT0 interrupt channel.
 *
 * Note:
 * This function must be called during system initialization
 * before expecting the EINT0 push-button to generate
 * interrupt requests.
 */

void EINT0_Init(void)
{
    // Configure P0.1 pin function selection.
    //
    // Each LPC2148 pin uses two bits in its corresponding
    // PINSEL register to select its alternate functionality.
    //
    // For P0.1, the function-selection bits are PINSEL0[3:2].
    //
    // Clear both bits initially to remove the previous
    // pin-function configuration.
    //
    // Bitwise operation:
    // ~(3U << 2) generates a mask that clears bits [3:2]
    // while preserving the remaining PINSEL0 bits.

    PINSEL0 &= ~(3U << 2);


    // Configure P0.1 as External Interrupt 0 (EINT0).
    //
    // Setting PINSEL0 bits [3:2] to binary 11 selects
    // the EINT0 alternate function on P0.1.
    //
    // Pin Function Selection:
    // PINSEL0[3:2] = 00 : GPIO functionality.
    // PINSEL0[3:2] = 01 : Alternate Function 1.
    // PINSEL0[3:2] = 10 : Alternate Function 2.
    // PINSEL0[3:2] = 11 : EINT0 functionality.
    //
    // After this configuration, P0.1 operates as an
    // external interrupt input instead of a normal GPIO pin.

    PINSEL0 |=  (3U << 2);


    // Configure the EINT0 trigger mode using the External
    // Interrupt Mode Register (EXTMODE).
    //
    // Setting bit 0 selects edge-sensitive interrupt operation.
    //
    // EXTMode bit 0:
    // 0 : Level-sensitive interrupt.
    // 1 : Edge-sensitive interrupt.
    //
    // Edge-sensitive operation allows the interrupt to be
    // generated by a signal transition rather than by
    // maintaining a particular input logic level.

    EXTMODE |= 1U;


    // Configure the EINT0 interrupt polarity using EXTPOLAR.
    //
    // Clearing bit 0 selects falling-edge detection
    // because EINT0 has already been configured
    // for edge-sensitive operation.
    //
    // EXTPOLAR bit 0:
    // 0 : Falling-edge triggered interrupt.
    // 1 : Rising-edge triggered interrupt.
    //
    // Therefore, the interrupt is generated when the
    // EINT0 input transitions from HIGH to LOW.
    //
    // Hardware Note:
    // The push-button circuit must provide the required
    // electrical signal transition for falling-edge detection.

    EXTPOLAR &= ~1U;


    // Clear any previously pending EINT0 interrupt request.
    //
    // Writing 1 to EXTINT bit 0 clears the EINT0 interrupt flag.
    //
    // This ensures that an old pending interrupt does not
    // cause an unexpected interrupt immediately after
    // enabling the interrupt channel.
    //
    // EXTINT uses write-one-to-clear behavior.

    EXTINT = 1U;


    // Configure EINT0 as an IRQ interrupt rather than an FIQ interrupt.
    //
    // VICIntSelect is the interrupt type selection register.
    //
    // Clearing bit 14 selects IRQ operation for VIC channel 14.
    //
    // VICIntSelect bit:
    // 0 : IRQ interrupt.
    // 1 : FIQ interrupt.
    //
    // IRQ is commonly used for normal peripheral interrupt
    // handling in embedded applications.
    //
    // The remaining interrupt channel configurations
    // are preserved by the bitwise AND operation.

    VICIntSelect &= ~(1U << EINT0_VIC_CHANNEL);


    // Register the EINT0 Interrupt Service Routine address
    // in the first vectored interrupt address slot of the VIC.
    //
    // VICVectAddr0 stores the address of the ISR associated
    // with VIC vector slot 0.
    //
    // Type Casting:
    // The function address is converted to unsigned long
    // to match the register-width representation expected
    // by the LPC2148 ARM toolchain.
    //
    // When EINT0 generates an interrupt, the VIC uses this
    // registered address to transfer control to EINT0_ISR.
    //
    // Note:
    // This assumes the conventional 32-bit ARM target and
    // compatible Keil compiler configuration.

    VICVectAddr0 = (unsigned long)EINT0_ISR;


    // Configure the VIC vector control register for vector slot 0.
    //
    // VICVectCntl0 contains:
    // Bit 5     : Vector slot enable bit.
    // Bits [4:0]: VIC interrupt channel number.
    //
    // (1U << 5) enables vector slot 0.
    // EINT0_VIC_CHANNEL selects interrupt channel 14.
    //
    // Therefore, this configuration enables vector slot 0
    // and associates it with the EINT0 interrupt source.
    //
    // The VIC can now dispatch EINT0 interrupts through
    // the registered ISR address.

    VICVectCntl0 = (1U << 5) | EINT0_VIC_CHANNEL;


    // Enable the EINT0 interrupt channel in the VIC.
    //
    // Setting bit 14 in VICIntEnable enables the corresponding
    // interrupt source.
    //
    // Once enabled, an EINT0 interrupt request can be accepted
    // by the VIC and dispatched to the configured ISR,
    // provided the processor interrupt state permits IRQ handling.
    //
    // Writing a 1 to the selected bit enables the interrupt channel.
    // Other interrupt enable bits are not affected by this write
    // because VICIntEnable uses write-one-to-set behavior.

    VICIntEnable = (1U << EINT0_VIC_CHANNEL);
}
```