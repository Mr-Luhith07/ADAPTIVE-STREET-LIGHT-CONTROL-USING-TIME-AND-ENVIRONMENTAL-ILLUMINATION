```c
/***************************************************************
 * FILE NAME   : MENU.H
 * PROJECT     : ADAPTIVE STREET LIGHT CONTROL SYSTEM
 * MCU         : LPC2129 / LPC2148
 *
 * DESCRIPTION :
 * This header file provides the public function declarations
 * for the menu module used in the Adaptive Street Light Control
 * System.
 *
 * The menu module allows the user to access the RTC settings
 * through the keypad and modify time, date and street-light
 * operating boundaries.
 *
 * It also declares the background service function responsible
 * for maintaining the normal street-light operation while the
 * user interacts with the menu.
 *
 * NOTE:
 * This file contains function declarations only.
 * The actual function definitions and implementation logic
 * are available in menu.c.
 ***************************************************************/


#ifndef MENU_H
/* Prevents multiple inclusion of this header file.
   The macro MENU_H is defined when this file is included for
   the first time. If another source file includes menu.h again,
   the declarations inside this header are skipped.
   This avoids duplicate declaration-related compilation issues. */

#define MENU_H
/* Defines the MENU_H macro to indicate that this header file
   has already been included in the current compilation unit. */


/***************************************************************
 * FUNCTION NAME : RTC_Edit_Menu
 *
 * DESCRIPTION   :
 * Displays the main RTC settings menu and allows the user
 * to select and modify the available system settings.
 *
 * The menu provides options to:
 * 1. Edit RTC time.
 * 2. Edit RTC date and day.
 * 3. Configure street-light ON/OFF time boundaries.
 * 4. Exit the settings menu.
 *
 * The function uses the keypad to receive user selections
 * and the LCD to display menu options and status messages.
 *
 * It is typically invoked when the EINT0 push-button generates
 * a menu request in the main application.
 *
 * PARAMETERS    : None.
 *
 * RETURN VALUE  : None (void).
 *
 * IMPLEMENTATION:
 * The complete function definition is available in menu.c.
 ***************************************************************/
void RTC_Edit_Menu(void);


/***************************************************************
 * FUNCTION NAME : BackgroundTasks
 *
 * DESCRIPTION   :
 * Performs the background operations required to maintain
 * normal street-light system functionality.
 *
 * The function typically performs the following operations:
 *
 * 1. Reads the current time from the RTC.
 * 2. Reads the LDR sensor through the ADC interface.
 * 3. Executes the street-light control logic using the
 *    current RTC hour and minute.
 *
 * It is passed as a callback function to the keypad input
 * routine so that these operations can be serviced while
 * the program waits for user input.
 *
 * This approach provides cooperative background servicing.
 * It does not create a separate thread or hardware interrupt.
 *
 * PARAMETERS    : None.
 *
 * RETURN VALUE  : None (void).
 *
 * IMPLEMENTATION:
 * The complete function definition is available in menu.c.
 ***************************************************************/
void BackgroundTasks(void);


/***************************************************************
 * END OF HEADER FILE
 ***************************************************************/

#endif
/* Ends the MENU_H header guard. */
```