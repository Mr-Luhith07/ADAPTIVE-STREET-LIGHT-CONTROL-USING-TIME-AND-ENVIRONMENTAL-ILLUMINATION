```c
/*
 * File Name   : adc_defines.h
 * Description : ADC0 configuration and register definitions for LPC2148.
 *
 * Purpose:
 * This header file contains the compile-time configuration parameters,
 * ADC clock settings, register bit positions, conversion-result
 * definitions and timeout settings required by the ADC driver.
 *
 * The definitions provided in this file are used by adc.c to configure
 * and control the ADC0 peripheral.
 *
 * Hardware Details:
 * Microcontroller : LPC2148
 * Peripheral      : ADC0
 * ADC Resolution  : 10-bit
 * ADC Clock       : 3 MHz
 * Peripheral Clock: 15 MHz
 * Reference Voltage: 3.3V
 *
 * Note:
 * Centralizing hardware-specific configuration parameters in this
 * file improves code readability, maintainability and reusability.
 */


/*
 * Header Guard:
 *
 * Prevents multiple inclusions of this header file within the same
 * compilation unit.
 *
 * ADC_DEFINES_H is defined during the first inclusion.
 * Subsequent inclusions are skipped by the preprocessor, preventing
 * repeated macro definitions.
 */

#ifndef ADC_DEFINES_H
#define ADC_DEFINES_H


/*
 * ADC Clock Frequency Configuration.
 *
 * Defines the operating clock frequency supplied to the ADC peripheral.
 *
 * Value : 3,000,000 Hz (3 MHz).
 *
 * The ADC clock must remain within the operating frequency limits
 * specified in the LPC2148 datasheet to ensure reliable conversion.
 *
 * The U suffix indicates that the constant is unsigned.
 */

#define ADC_CLK             3000000U


/*
 * Peripheral Clock (PCLK) Configuration.
 *
 * Defines the peripheral clock frequency supplied to the ADC0 peripheral.
 *
 * Value : 15,000,000 Hz (15 MHz).
 *
 * PCLK is derived from the processor clock configuration through
 * the peripheral clock divider settings.
 *
 * This value is used to calculate the ADC clock divider.
 *
 * Note:
 * The configured value must match the actual PCLK supplied to ADC0.
 */

#define ADC_PCLK            15000000U


/*
 * ADC Clock Divider Calculation.
 *
 * Configures the ADC clock divider using the peripheral clock
 * and the required ADC operating frequency.
 *
 * LPC2148 ADC clock calculation:
 *
 * ADC Clock = PCLK / (CLKDIV + 1)
 *
 * Rearranging the equation:
 *
 * CLKDIV = (PCLK / ADC Clock) - 1
 *
 * Substituting the configured values:
 *
 * CLKDIV = (15,000,000 / 3,000,000) - 1
 *        = 5 - 1
 *        = 4
 *
 * The calculated value is programmed into AD0CR bits [15:8]
 * by the ADC initialization and conversion functions.
 *
 * This ensures that the ADC peripheral receives the required
 * operating clock frequency.
 */

#define ADC_CLKDIV          ((ADC_PCLK / ADC_CLK) - 1U)


/*
 * ADC Power-Down Control Bit Position.
 *
 * Defines the bit position of the PDN (Power Down) control bit
 * in the ADC Control Register (AD0CR).
 *
 * Bit Position : 21.
 *
 * Setting this bit to 1 powers up the ADC peripheral.
 * Clearing this bit places the ADC peripheral in power-down mode.
 *
 * Usage:
 * (1U << ADC_PDN_BIT)
 *
 * This bit must be set before performing ADC conversions.
 */

#define ADC_PDN_BIT         21U


/*
 * ADC Conversion Start Bit Position.
 *
 * Defines the starting bit position of the START field
 * in the ADC Control Register (AD0CR).
 *
 * Bit Position : 24.
 *
 * The START field occupies bits [26:24].
 *
 * Setting the START field to 001 initiates an immediate
 * software-controlled ADC conversion.
 *
 * Clearing the START field to 000 removes the software
 * conversion-start request.
 *
 * Usage:
 * (1U << ADC_START_BIT)
 *
 * This definition is used by the ADC driver to initiate
 * and clear the conversion-start command.
 */

#define ADC_START_BIT       24U


/*
 * ADC Conversion Completion Bit Position.
 *
 * Defines the bit position of the DONE status flag
 * in the ADC Global Data Register (AD0GDR).
 *
 * Bit Position : 31.
 *
 * Hardware Function:
 * The ADC hardware sets this bit to 1 when the conversion
 * is completed and the result is available.
 *
 * The ADC driver monitors this bit using polling to determine
 * whether the conversion process has finished.
 *
 * Usage:
 * (AD0GDR & (1U << ADC_DONE_BIT))
 *
 * A set DONE bit indicates conversion completion.
 */

#define ADC_DONE_BIT        31U


/*
 * ADC Result Field Right-Shift Position.
 *
 * Defines the number of bit positions required to shift
 * the ADC conversion result into the least significant
 * bit positions.
 *
 * Shift Value : 6.
 *
 * The 10-bit ADC conversion result is available in
 * AD0GDR bits [15:6].
 *
 * Right-shifting the register value by 6 positions moves
 * the conversion result into bits [9:0].
 *
 * This allows the driver to extract the digital result
 * using a bitwise mask.
 */

#define ADC_RESULT_SHIFT    6U


/*
 * ADC Result Extraction Mask.
 *
 * Defines the bit mask used to isolate the 10-bit ADC
 * conversion result from the ADC Global Data Register.
 *
 * Mask Value : 0x3FF (Binary: 11 1111 1111).
 *
 * A 10-bit ADC provides 1024 possible digital output levels.
 *
 * Minimum Digital Value : 0.
 * Maximum Digital Value : 1023.
 *
 * The mask removes unwanted status and control bits
 * after the ADC result has been shifted.
 *
 * Usage:
 * (AD0GDR >> ADC_RESULT_SHIFT) & ADC_RESULT_MASK
 */

#define ADC_RESULT_MASK     0x3FFU


/*
 * ADC Reference Voltage Configuration.
 *
 * Defines the reference voltage used for converting
 * the digital ADC result into an equivalent analog voltage.
 *
 * Reference Voltage : 3.3 Volts.
 *
 * Voltage Calculation:
 *
 * Analog Voltage = (Digital ADC Value * ADC_VREF) / 1023
 *
 * The reference voltage represents the full-scale input
 * voltage used for the ADC conversion.
 *
 * Note:
 * The configured value must match the actual ADC reference
 * voltage supplied to the microcontroller.
 *
 * The F suffix indicates a floating-point constant.
 */

#define ADC_VREF            3.3F


/*
 * ADC Software Timeout Configuration.
 *
 * Defines the maximum number of polling-loop iterations
 * permitted while waiting for ADC conversion completion.
 *
 * Timeout Count : 100000 iterations.
 *
 * Purpose:
 * Prevents the processor from waiting indefinitely if the ADC
 * hardware does not indicate conversion completion.
 *
 * The ADC driver decrements this counter during polling.
 *
 * If the counter reaches zero before the DONE flag is detected,
 * the conversion is treated as a timeout failure.
 *
 * Note:
 * This is an iteration-based software timeout and does not
 * represent a fixed time duration in microseconds or milliseconds.
 * Its actual duration depends on processor frequency,
 * compiler optimization and generated instructions.
 */

#define ADC_TIMEOUT         100000U


/*
 * End of ADC_DEFINES_H header guard.
 *
 * Marks the end of the protected section of this header file.
 * Prevents repeated inclusion of ADC configuration definitions.
 */

#endif
```