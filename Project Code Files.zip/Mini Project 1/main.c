```c
/*
 *==============================================================================
 * File Name    : main.c
 * Project Name : Adaptive Street Light Control System
 * Target MCU   : LPC2148 (ARM7TDMI-S)
 * Development  : Keil �Vision
 *
 * Description:
 *   This file contains the main application program of the Adaptive
 *   Street Light Control System.
 *
 *   It acts as the central controller of the complete embedded system
 *   by coordinating the RTC, LDR sensor, LCD, keypad, external interrupt
 *   and street-light control modules.
 *
 * System Operating Principle:
 *
 *   The street lights are controlled based on TWO independent conditions:
 *
 *     1. RTC SCHEDULE:
 *        Determines whether the current time falls within the configured
 *        street-light operating schedule.
 *
 *     2. LDR DARKNESS:
 *        Determines whether the surrounding environment is sufficiently dark.
 *
 *   STREET LIGHT ON CONDITION:
 *
 *        RTC Schedule Active  AND  LDR Darkness Detected
 *
 *   If both conditions are satisfied, the street lights are switched ON.
 *   Otherwise, the street lights are switched OFF.
 *
 * User Interface:
 *   - LCD       : Displays current time, date, day and LDR information.
 *   - Keypad    : Allows the user to enter RTC configuration values.
 *   - EINT0     : External push-button interrupt used to request the
 *                 RTC/settings menu.
 *
 * Main Responsibilities:
 *   1. Initialize all required hardware drivers.
 *   2. Initialize the RTC and establish the initial day setting.
 *   3. Monitor the EINT0 menu request flag.
 *   4. Read the current RTC time, date and day.
 *   5. Read the LDR sensor through the ADC.
 *   6. Execute the street-light control logic.
 *   7. Display real-time system information on the LCD.
 *   8. Continuously repeat the monitoring and control operations.
 *
 * Module Dependencies:
 *   LPC214x.h     - LPC2148 microcontroller register definitions.
 *   types.h       - Project-specific data type definitions.
 *   delay.h       - Software delay functions.
 *   lcd.h         - LCD driver interface.
 *   lcd_defines.h - LCD commands and GPIO pin definitions.
 *   kpm.h         - Matrix keypad driver interface.
 *   rtc.h         - Real-Time Clock driver interface.
 *   ldr.h         - LDR application interface.
 *   streetlight.h - Street-light control interface.
 *   eint.h        - External interrupt interface.
 *   menu.h        - RTC/settings menu interface.
 *
 *==============================================================================
 */


/*==============================================================================
 * HEADER FILE INCLUSIONS
 *==============================================================================
 *
 * Include the required header files to access the microcontroller
 * registers, data types, driver functions and application interfaces.
 */


/*
 * Provides the LPC2148 microcontroller register definitions.
 *
 * Allows access to hardware registers such as GPIO, PINSEL, RTC,
 * VIC and other on-chip peripheral registers.
 */
#include <LPC214x.h>


/*
 * Provides project-specific data types.
 *
 * Examples:
 *   u8  - 8-bit unsigned integer.
 *   u16 - 16-bit unsigned integer.
 *   u32 - 32-bit unsigned integer.
 *   s32 - 32-bit signed integer.
 *   f32 - 32-bit floating-point type.
 */
#include "types.h"


/*
 * Provides software delay function declarations.
 *
 * Used for:
 *   - LCD startup waiting periods.
 *   - Display message intervals.
 *   - Main-loop execution delay.
 */
#include "delay.h"


/*
 * Provides LCD driver function declarations.
 *
 * Used for:
 *   - Initializing the LCD.
 *   - Sending commands.
 *   - Displaying strings and numeric values.
 *   - Displaying RTC information.
 */
#include "lcd.h"


/*
 * Provides LCD command and GPIO pin definitions.
 *
 * Examples:
 *   CLEAR_LCD
 *   GOTO_LINE1_POS0
 *   GOTO_LINE2_POS0
 *
 * These macros improve readability by avoiding direct hexadecimal
 * command values in the application program.
 */
#include "lcd_defines.h"


/*
 * Provides the matrix keypad driver interface.
 *
 * Used by the RTC/settings menu to receive user key presses.
 */
#include "kpm.h"


/*
 * Provides Real-Time Clock function declarations.
 *
 * Used for:
 *   - RTC initialization.
 *   - Reading current time.
 *   - Reading current date.
 *   - Reading the current day.
 *   - Displaying RTC information.
 */
#include "rtc.h"


/*
 * Provides the LDR application-layer interface.
 *
 * Used to initialize the LDR measurement module and obtain
 * the latest ambient-light condition.
 */
#include "ldr.h"


/*
 * Provides street-light control function declarations.
 *
 * Used to initialize the street-light output pins and execute
 * the automatic street-light ON/OFF decision.
 */
#include "streetlight.h"


/*
 * Provides the external interrupt interface.
 *
 * Used to initialize EINT0 and access the menuRequest flag
 * updated by the external interrupt service routine.
 */
#include "eint.h"


/*
 * Provides RTC/settings menu function declarations.
 *
 * Used to enter the user configuration menu when the EINT0
 * push-button generates a menu request.
 */
#include "menu.h"


/*==============================================================================
 * FUNCTION NAME : main
 *==============================================================================
 *
 * Description:
 *   Main entry point of the Adaptive Street Light Control System.
 *
 * Parameters:
 *   void - No input parameters.
 *
 * Return Value:
 *   int - Standard C main function return type.
 *
 * Working:
 *   1. Declares variables required to store RTC information.
 *   2. Initializes all hardware drivers and application modules.
 *   3. Displays the system startup message.
 *   4. Continuously reads RTC and LDR information.
 *   5. Checks for external interrupt menu requests.
 *   6. Executes street-light control logic.
 *   7. Updates the LCD with current system information.
 *
 * Execution:
 *   The main application continuously executes inside an infinite loop.
 *   This allows the system to monitor environmental conditions and
 *   update the street-light outputs continuously.
 */
int main(void)
{

    /*==========================================================================
     * LOCAL VARIABLES - RTC INFORMATION
     *==========================================================================
     *
     * These variables temporarily store the time, date and day values
     * retrieved from the RTC module.
     *
     * The RTC driver updates these variables through pointer arguments.
     *
     * u32 is used to store the numeric RTC values.
     */


    /*
     * hr  - Stores the current hour value.
     * min - Stores the current minute value.
     * sec - Stores the current second value.
     *
     * These values are obtained through RTC_GetTime().
     */
    u32 hr, min, sec;


    /*
     * date  - Stores the current day of the month.
     * month - Stores the current month.
     * year  - Stores the current year.
     * day   - Stores the current day-of-week value.
     *
     * These values are obtained through RTC_GetDate()
     * and RTC_GetDay().
     */
    u32 date, month, year, day;


    /*==========================================================================
     * HARDWARE AND DRIVER INITIALIZATION
     *==========================================================================
     *
     * Initialize all required peripherals and application modules
     * before entering the continuous monitoring loop.
     *
     * Initialization should be completed before the application
     * starts accessing the corresponding hardware.
     */


    /*
     * Initialize the LCD module.
     *
     * Configures the LCD GPIO pins and sends the required initialization
     * commands to the LCD controller.
     *
     * After successful initialization, the LCD is ready to display
     * characters, strings and numerical information.
     */
    InitLCD();


    /*
     * LCD HARDWARE VERIFICATION CODE
     *
     * The following commented-out statements can be temporarily enabled
     * during hardware testing to verify whether the LCD is working.
     *
     * Expected operation:
     *   1. Display the text "Working".
     *   2. Wait for approximately one second.
     *   3. Clear the LCD display.
     *
     * These statements are commented out during normal application
     * execution to avoid displaying the temporary test message.
     */

    // To check if LCD is in working condition or not.

    /*
    StrLCD("Working");
    delay_ms(1000);
    CmdLCD(CLEAR_LCD);
    */


    /*
     * Initialize the 4x4 matrix keypad.
     *
     * Configures the keypad row pins as GPIO outputs and
     * column pins as GPIO inputs.
     *
     * The keypad is used by the RTC/settings menu to receive
     * user input for changing configuration values.
     */
    InitKPM();


    /*
     * Initialize the Real-Time Clock peripheral.
     *
     * Configures the RTC operating parameters and enables the
     * RTC according to the RTC driver implementation.
     *
     * After initialization, the RTC can maintain and provide
     * the current time and date information.
     */
    RTC_Init();


    /*
     * Initialize the LDR application module.
     *
     * Calls the ADC initialization function required for measuring
     * the analog voltage produced by the LDR sensor circuit.
     *
     * This prepares the ADC for subsequent LDR_Read() operations.
     */
    LDR_Init();


    /*
     * Initialize the street-light control module.
     *
     * Configures the GPIO pins connected to the street-light
     * control outputs.
     *
     * The module is responsible for controlling the street lights
     * according to the RTC schedule and LDR darkness condition.
     */
    StreetLight_Init();


    /*
     * Initialize the external interrupt EINT0.
     *
     * Configures the external interrupt input pin and its
     * corresponding VIC interrupt channel.
     *
     * When the configured push-button event occurs:
     *   1. EINT0 generates an interrupt.
     *   2. The EINT0 ISR executes.
     *   3. The ISR sets menuRequest to indicate that the menu
     *      must be opened by the main application.
     *
     * Note:
     *   The interrupt service routine should perform only the
     *   necessary short interrupt-handling operations.
     *   The actual menu processing is performed in main context.
     */
    EINT0_Init();


    /*==========================================================================
     * INITIAL RTC CONFIGURATION
     *==========================================================================
     *
     * The following commented-out function calls can be used to
     * initialize the RTC with a specific time and date.
     *
     * They are currently disabled, so these values are not written
     * to the RTC during normal execution.
     */


    /*
     * Optional initial time configuration.
     *
     * RTC_SetTime(hour, minute, second)
     *
     * Example:
     *   18 hours, 30 minutes and 0 seconds.
     *
     * Enable this call only when the application needs to set
     * a predefined startup time.
     */
    //RTC_SetTime(18U, 30U, 0U);


    /*
     * Optional initial date configuration.
     *
     * RTC_SetDate(date, month, year)
     *
     * Example:
     *   16 November 2026.
     *
     * This call is currently disabled.
     */
    //RTC_SetDate(16U, 11U, 2026U);


    /*
     * Set the initial day-of-week value in the RTC.
     *
     * The value 1U is passed to the RTC driver.
     *
     * The exact day represented by 1U depends on the day-number
     * convention defined in the RTC module.
     *
     * This call initializes the day value according to the
     * application's configured day-number mapping.
     */
    RTC_SetDay(1U);


    /*==========================================================================
     * SYSTEM STARTUP MESSAGE
     *==========================================================================
     *
     * Display a startup message after initializing the required
     * hardware and application modules.
     *
     * This provides a visual indication that the system has
     * completed its initialization sequence.
     */


    /*
     * Clear the LCD before displaying the startup message.
     *
     * CLEAR_LCD removes the previously displayed characters and
     * returns the cursor to the home position.
     */
    CmdLCD(CLEAR_LCD);


    /*
     * Display the project title on the first LCD line.
     *
     * The string "STREET LIGHT" identifies the application.
     */
    StrLCD("STREET LIGHT");


    /*
     * Move the LCD cursor to the first position of the second line.
     *
     * GOTO_LINE2_POS0 corresponds to the DDRAM starting address
     * of the second line on a typical 16x2 LCD.
     */
    CmdLCD(GOTO_LINE2_POS0);


    /*
     * Display the system startup status.
     *
     * Indicates that the application has reached the ready state.
     */
    StrLCD("SYSTEM READY");


    /*
     * Wait for approximately one second.
     *
     * This keeps the startup message visible before normal
     * system monitoring begins.
     */
    delay_ms(1000U);


    /*
     * Clear the startup message.
     *
     * The LCD is now ready to display live RTC and LDR information.
     */
    CmdLCD(CLEAR_LCD);


    /*==========================================================================
     * MAIN APPLICATION LOOP
     *==========================================================================
     *
     * The infinite loop continuously executes the main application.
     *
     * There is no normal termination condition because the embedded
     * system is designed to operate continuously after power-up.
     *
     * Each iteration performs:
     *
     *   1. External interrupt menu request handling.
     *   2. RTC time acquisition.
     *   3. RTC date acquisition.
     *   4. RTC day acquisition.
     *   5. LDR sensor measurement.
     *   6. Street-light control.
     *   7. LCD information update.
     *   8. A short delay before the next iteration.
     */
    while(1)
    {


        /*======================================================================
         * EINT0 MENU REQUEST HANDLING
         *======================================================================
         *
         * The EINT0 push-button is used to request entry into the
         * RTC/settings menu.
         *
         * The external interrupt service routine sets menuRequest
         * when the configured interrupt event occurs.
         *
         * The main loop checks this flag and executes the menu
         * outside the interrupt service routine.
         */


        /*
         * Check whether an EINT0 interrupt has requested the menu.
         *
         * menuRequest != 0U:
         *   Indicates that a menu request is pending.
         *
         * menuRequest == 0U:
         *   Indicates that no menu request is pending.
         */
        if(menuRequest != 0U)
        {

            /*
             * Clear the menu request flag before entering the menu.
             *
             * This acknowledges the pending request so that the
             * main loop does not repeatedly enter the menu because
             * of the same interrupt request.
             *
             * The flag can be set again by a subsequent EINT0 event.
             */
            menuRequest = 0U;


            /*
             * Enter the RTC/settings menu.
             *
             * This function handles user interaction through the
             * keypad and allows the RTC settings to be modified
             * according to the menu implementation.
             *
             * The function executes in normal application context,
             * not inside the interrupt service routine.
             */
            RTC_Edit_Menu();
        }


        /*======================================================================
         * RTC TIME ACQUISITION
         *======================================================================
         *
         * Read the current time maintained by the RTC peripheral.
         *
         * The retrieved values are stored in the local variables:
         *   hr  - Hour.
         *   min - Minute.
         *   sec - Second.
         *
         * Pointer arguments allow the RTC driver to update
         * the variables declared in main().
         */


        /*
         * Read the current RTC time.
         *
         * Arguments:
         *   &hr  - Address where the hour value is stored.
         *   &min - Address where the minute value is stored.
         *   &sec - Address where the second value is stored.
         */
        RTC_GetTime(&hr, &min, &sec);


        /*======================================================================
         * RTC DATE ACQUISITION
         *======================================================================
         *
         * Read the current calendar date from the RTC peripheral.
         *
         * Retrieved values:
         *   date  - Day of the month.
         *   month - Month number.
         *   year  - Calendar year.
         */


        /*
         * Read the current RTC date.
         *
         * Arguments:
         *   &date  - Address where the date value is stored.
         *   &month - Address where the month value is stored.
         *   &year  - Address where the year value is stored.
         */
        RTC_GetDate(&date, &month, &year);


        /*======================================================================
         * RTC DAY ACQUISITION
         *======================================================================
         *
         * Read the current day-of-week value from the RTC peripheral.
         *
         * The returned numeric value is stored in the local variable day.
         *
         * The RTC driver defines the mapping between the numeric
         * day value and the corresponding weekday.
         */
        RTC_GetDay(&day);


        /*======================================================================
         * LDR SENSOR ACQUISITION
         *======================================================================
         *
         * Read the latest analog signal from the LDR sensor through
         * the ADC peripheral.
         *
         * LDR_Read() performs the following operations:
         *
         *   1. Starts and obtains the ADC conversion.
         *   2. Updates ldrAdcValue with the digital ADC result.
         *   3. Updates ldrVoltage with the corresponding voltage.
         *   4. Checks the ADC conversion status.
         *   5. Applies the configured hysteresis thresholds.
         *   6. Updates ldrDark to indicate DARK or BRIGHT conditions.
         *
         * The updated values are used by the street-light control
         * module and LCD display logic.
         */
        LDR_Read();


        /*======================================================================
         * STREET-LIGHT CONTROL DECISION
         *======================================================================
         *
         * Execute the automatic street-light control logic using
         * the current RTC time.
         *
         * Arguments:
         *   hr  - Current RTC hour.
         *   min - Current RTC minute.
         *
         * The street-light module uses the RTC schedule and the
         * latest LDR darkness condition to determine the output state.
         *
         * Operating principle:
         *
         *   RTC schedule active AND LDR darkness detected:
         *       Street lights ON.
         *
         *   Otherwise:
         *       Street lights OFF.
         *
         * Note:
         *   The actual output decision is implemented inside
         *   StreetLight_Control().
         */
        StreetLight_Control(hr, min);


        /*======================================================================
         * LCD DISPLAY UPDATE - FIRST LINE
         *======================================================================
         *
         * Display the current RTC time and LDR sensor information.
         *
         * The first LCD line is used to display:
         *   - Current time.
         *   - LDR environmental condition.
         *   - Latest ADC digital reading.
         */


        /*
         * Display the current RTC time.
         *
         * Arguments:
         *   hr  - Current hour.
         *   min - Current minute.
         *   sec - Current second.
         *
         * RTC_DisplayTime() is responsible for formatting and
         * displaying the time on the LCD.
         */
        RTC_DisplayTime(hr, min, sec);


        /*
         * Move the LCD cursor to the position specified by:
         *
         *   GOTO_LINE1_POS0 + 10
         *
         * GOTO_LINE1_POS0 = 0x80.
         *
         * Therefore:
         *   0x80 + 10 = 0x8A.
         *
         * This selects DDRAM address 0x0A, corresponding to
         * column 10 (zero-based) of the first line on a typical
         * 16x2 LCD.
         *
         * The LDR status information is displayed from this position.
         */
        CmdLCD(GOTO_LINE1_POS0+10);


        /*
         * Check whether the LDR module has processed a successful
         * sensor reading and whether the latest ADC conversion is valid.
         *
         * Conditions:
         *
         *   ldrInitialized:
         *       At least one successful LDR reading has been processed.
         *
         *   adcValid:
         *       The most recent ADC reading was successful.
         *
         * Both conditions must be true before displaying the
         * sensor status and ADC reading as valid information.
         */
		if(ldrInitialized && adcValid)
        {

            /*
             * Check the interpreted environmental light condition.
             *
             * ldrDark = 1U:
             *   The environment is classified as DARK.
             *
             * ldrDark = 0U:
             *   The environment is classified as BRIGHT.
             */
            if(ldrDark)

                /*
                 * Display "D " to represent a DARK environment.
                 *
                 * The space after D separates the status character
                 * from the following ADC numerical value.
                 */
                StrLCD("D ");

            else

                /*
                 * Display "B " to represent a BRIGHT environment.
                 *
                 * The space after B separates the status character
                 * from the following ADC numerical value.
                 */
                StrLCD("B ");


            /*
             * Display the latest ADC digital conversion value.
             *
             * U32LCD() converts the unsigned integer into decimal
             * ASCII characters and sends them to the LCD.
             *
             * Example:
             *   If ldrAdcValue = 650, the LCD displays 650.
             */
            U32LCD(ldrAdcValue);


            /*
             * Display three spaces after the ADC value.
             *
             * Purpose:
             *   Clears leftover characters from a previous,
             *   longer ADC reading when the current value contains
             *   fewer digits.
             *
             * Example:
             *   Previous reading: 1023
             *   Current reading : 650
             *
             * The additional spaces overwrite the old trailing digit.
             */
            StrLCD("   ");
        }
        else
        {

            /*
             * Display an error indication when the LDR data
             * is not available or the latest ADC conversion fails.
             *
             * The text indicates that the sensor reading should
             * not currently be treated as valid.
             *
             * Trailing spaces help overwrite previous display contents.
             */
            StrLCD("LDR ERROR       ");
        }


        /*======================================================================
         * LCD DISPLAY UPDATE - DAY INFORMATION
         *======================================================================
         *
         * Position the LCD cursor and display the current weekday.
         *
         * The RTC_DisplayDay() function converts the numeric day value
         * into its corresponding weekday representation.
         */


        /*
         * Move the cursor to the position specified by:
         *
         *   GOTO_LINE1_POS0 + 12
         *
         * GOTO_LINE1_POS0 = 0x80.
         *
         * Therefore:
         *   0x80 + 12 = 0x8C.
         *
         * This selects DDRAM address 0x0C, corresponding to
         * column 12 (zero-based) of the first LCD line.
         */
		CmdLCD(GOTO_LINE1_POS0+12);


        /*
         * Display the current weekday.
         *
         * Argument:
         *   day - Numeric day-of-week value obtained from RTC_GetDay().
         *
         * RTC_DisplayDay() is responsible for displaying the
         * corresponding weekday text.
         */
		RTC_DisplayDay(day);


        /*======================================================================
         * LCD DISPLAY UPDATE - SECOND LINE
         *======================================================================
         *
         * Position the cursor at the beginning of the second LCD line
         * and display the current calendar date.
         */


        /*
         * Move the LCD cursor to the first position of the second line.
         *
         * GOTO_LINE2_POS0 corresponds to the DDRAM starting address
         * of the second line on a typical 16x2 LCD.
         */
        CmdLCD(GOTO_LINE2_POS0);


        /*
         * Display the current calendar date.
         *
         * Arguments:
         *   date  - Day of the month.
         *   month - Month number.
         *   year  - Calendar year.
         *
         * RTC_DisplayDate() formats and displays the date according
         * to the implementation in the RTC driver.
         *
         * Example display format may be:
         *   DD/MM/YYYY
         */
		RTC_DisplayDate(date,month,year);


        /*======================================================================
         * MAIN LOOP EXECUTION DELAY
         *======================================================================
         *
         * Introduces a short delay before starting the next
         * monitoring and display-update iteration.
         *
         * Purpose:
         *   1. Prevents excessively rapid LCD updates.
         *   2. Reduces unnecessary repeated application processing.
         *   3. Provides a small interval between successive sensor readings.
         *
         * Note:
         *   This is a blocking software delay.
         *   It does not provide precise real-time scheduling.
         */
		
        delay_ms(200U);

    }

}
```