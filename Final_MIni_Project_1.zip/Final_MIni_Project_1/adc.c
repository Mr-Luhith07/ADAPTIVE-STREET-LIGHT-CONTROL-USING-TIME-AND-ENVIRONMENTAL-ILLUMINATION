/* LPC2148 ADC0 driver.
   AD0.1 is available on P0.28. ADC clock is configured for 3 MHz
   assuming PCLK=15 MHz. */

#include <LPC214x.h>
#include "types.h"
#include "adc.h"
#include "adc_defines.h"

void Init_ADC(void)
{
    PINSEL1 &= ~(3U << 24);
    PINSEL1 |=  (1U << 24);       /* P0.28 = AD0.1 */

    AD0CR = (ADC_CLKDIV << 8) | (1U << ADC_PDN_BIT);
}

u8 Read_ADC(u8 chNo, u16 *dVal, f32 *eAR)
{
    u32 timeout;
    u32 result;

    if(chNo > 7U || dVal == 0 || eAR == 0)
        return 0U;

    AD0CR = (1U << chNo) |
            (ADC_CLKDIV << 8) |
            (1U << ADC_PDN_BIT);

    AD0CR &= ~(7U << ADC_START_BIT);
    AD0CR |=  (1U << ADC_START_BIT);

    timeout = ADC_TIMEOUT;
    while(((AD0GDR & (1U << ADC_DONE_BIT)) == 0U) && timeout > 0U)
        timeout--;

    if(timeout == 0U)
    {
        AD0CR &= ~(7U << ADC_START_BIT);
        return 0U;
    }

    result = (AD0GDR >> ADC_RESULT_SHIFT) & ADC_RESULT_MASK;
    *dVal = (u16)result;
    *eAR = ((f32)result * ADC_VREF) / 1023.0F;

    AD0CR &= ~(7U << ADC_START_BIT);
    return 1U;
}

