#ifndef STREETLIGHT_H
#define STREETLIGHT_H
#include "types.h"
extern u32 start_hour, start_min, end_hour, end_min;
u8 StreetLight_IsScheduled(u32 hour, u32 minute);
void StreetLight_Init(void);
void StreetLight_Control(u32 hour, u32 minute);
#endif

