#ifndef RTC_H
#define RTC_H
#include "types.h"
void RTC_Init(void);
void RTC_SetTime(u32 h, u32 m, u32 s);
void RTC_SetDate(u32 d, u32 m, u32 y);
void RTC_SetDay(u32 day);
void RTC_GetTime(u32 *h, u32 *m, u32 *s);
void RTC_GetDate(u32 *d, u32 *m, u32 *y);
void RTC_GetDay(u32 *day);
u8 RTC_IsLeapYear(u32 year);
u8 RTC_DaysInMonth(u32 month, u32 year);
void RTC_DisplayTime(u32 h, u32 m, u32 s);
void RTC_DisplayDate(u32 d, u32 m, u32 y); 
void RTC_DisplayDay(u32 day);
#endif

