/* Delay routines for the LPC2148 project.
   These are software delays; their accuracy depends on compiler settings
   and generated machine code. Do not use them for precise timing. */

#include "types.h"
#include "delay.h"

void delay_us(u32 dlyUS)
{
    volatile u32 count;
    while(dlyUS--)
    {
        for(count = 12U; count > 0U; count--)
        {
            /* Intentional empty loop. volatile prevents removal. */
        }
    }
}

void delay_ms(u32 dlyMS)
{
    while(dlyMS--)
        delay_us(1000U);
}

void delay_s(u32 dlyS)
{
    while(dlyS--)
        delay_ms(1000U);
}

