/* Streetlight decision module.
   Project rule: lights ON only when the RTC schedule is active AND
   the LDR reports darkness. ADC failure defaults to lights OFF. */

#include <LPC214x.h>
#include "types.h"
#include "project_config.h"
#include "streetlight.h"
#include "ldr.h"

u32 start_hour = 18U;
u32 start_min  = 30U;
u32 end_hour   = 6U;
u32 end_min    = 0U;

void StreetLight_Init(void)
{
    /* P1.24-P1.27 selected as GPIO using PINSEL2. */
    PINSEL2 &= ~(0xFFU << 16);
    IODIR1 |= LIGHT_MASK;
    IOCLR1 = LIGHT_MASK;
}

u8 StreetLight_IsScheduled(u32 hour, u32 minute)
{
    u32 now = (hour * 60U) + minute;
    u32 start = (start_hour * 60U) + start_min;
    u32 end = (end_hour * 60U) + end_min;

    if(start == end)
        return 0U;                   /* Equal boundaries = disabled */

    if(start > end)
        return ((now >= start) || (now < end)) ? 1U : 0U;

    return ((now >= start) && (now < end)) ? 1U : 0U;
}

void StreetLight_Control(u32 hour, u32 minute)
{
    if(adcValid && ldrInitialized &&
       StreetLight_IsScheduled(hour, minute) && ldrDark)
    {
        IOSET1 = LIGHT_MASK;
    }
    else
    {
        IOCLR1 = LIGHT_MASK;
    }
}

