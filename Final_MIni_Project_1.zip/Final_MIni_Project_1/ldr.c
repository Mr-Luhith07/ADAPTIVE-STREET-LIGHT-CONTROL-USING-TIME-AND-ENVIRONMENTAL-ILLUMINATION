/* LDR application layer.
   Reads AD0.1 and applies hysteresis to avoid rapid switching near
   the threshold. Adjust thresholds after observing real ADC readings. */

#include "types.h"
#include "project_config.h"
#include "adc.h"
#include "ldr.h"

u16 ldrAdcValue = 0U;
f32 ldrVoltage = 0.0F;
u8 adcValid = 0U;
u8 ldrDark = 0U;
u8 ldrInitialized = 0U;

void LDR_Init(void)
{
    Init_ADC();
}

void LDR_Read(void)
{
    adcValid = Read_ADC(ADC_CHANNEL, &ldrAdcValue, &ldrVoltage);

    if(adcValid)
    {
#if LDR_DARK_WHEN_HIGH
        if(ldrAdcValue >= LDR_DARK_THRESHOLD)
            ldrDark = 1U;
        else if(ldrAdcValue <= LDR_BRIGHT_THRESHOLD)
            ldrDark = 0U;
#else
        if(ldrAdcValue <= LDR_BRIGHT_THRESHOLD)
            ldrDark = 1U;
        else if(ldrAdcValue >= LDR_DARK_THRESHOLD)
            ldrDark = 0U;
#endif
        ldrInitialized = 1U;
    }
}

