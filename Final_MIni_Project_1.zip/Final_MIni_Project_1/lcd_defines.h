#ifndef LCD_DEFINES_H
#define LCD_DEFINES_H

#define CLEAR_LCD          0x01
#define RET_CUR_HOME       0x02
#define SHIFT_CUR_RIGHT    0x06
#define SHIFT_CUR_LEFT     0x07
#define DSP_OFF            0x08
#define DSP_ON_CUR_OFF     0x0C
#define DSP_ON_CUR_BLK     0x0E
#define SHIFT_DSP_LEFT     0x10
#define SHIFT_DSP_RIGHT    0x14
#define MODE_8BIT_2LINE    0x38
#define GOTO_LINE1_POS0    0x80
#define GOTO_LINE2_POS0    0xC0
#define GOTO_CGRAM_START   0x40

/* LCD wiring:
   D0-D7 = P0.8-P0.15
   RS    = P0.4
   EN    = P0.17
   RW    = P0.18
*/
#define LCD_DATA 8U
#define LCD_RS   4U
#define LCD_EN   17U
#define LCD_RW   18U

#endif

						   
