/* Main application: Adaptive Street Light Control.
   MCU: LPC2148
   Operation: RTC schedule active AND LDR darkness = lights ON.
   The EINT0 push-button opens the RTC/settings menu. */

#include <LPC214x.h>
#include "types.h"
#include "delay.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "kpm.h"
#include "rtc.h"
#include "ldr.h"
#include "streetlight.h"
#include "eint.h"
#include "menu.h"

int main(void)
{
    u32 hr, min, sec;
    u32 date, month, year, day;

    /* Initialize display, keypad, RTC, sensor and output drivers. */
    InitLCD();
	// To check if LCD is in working condition or not.
	/*StrLCD("Working");
	delay_ms(1000);
	CmdLCD(CLEAR_LCD);*/

    InitKPM();
    RTC_Init();
    LDR_Init();
    StreetLight_Init();
    EINT0_Init();

    /* Initial RTC values; change these through the menu or your own setup. */
    //RTC_SetTime(18U, 30U, 0U);
    //RTC_SetDate(16U, 11U, 2026U);
    RTC_SetDay(1U);

    CmdLCD(CLEAR_LCD);
    StrLCD("STREET LIGHT");
    CmdLCD(GOTO_LINE2_POS0);
    StrLCD("SYSTEM READY");
    delay_ms(1000U);
	CmdLCD(CLEAR_LCD);

    while(1)
    {
        if(menuRequest != 0U)
        {
            menuRequest = 0U;
            RTC_Edit_Menu();
        }

        RTC_GetTime(&hr, &min, &sec);
        RTC_GetDate(&date, &month, &year);
        RTC_GetDay(&day);

        LDR_Read();
        StreetLight_Control(hr, min);

        /* Line 1: current RTC time. */
        RTC_DisplayTime(hr, min, sec);
		CmdLCD(GOTO_LINE1_POS0+10);
		if(ldrInitialized && adcValid)
        {
            if(ldrDark)
                StrLCD("D ");
            else
                StrLCD("B ");

            U32LCD(ldrAdcValue);
            StrLCD("   ");
        }
        else
        {
            StrLCD("LDR ERROR       ");
        }
		
        /* Line 2: show Date, illumination state and ADC value. */
		CmdLCD(GOTO_LINE1_POS0+12);
		RTC_DisplayDay(day);

        CmdLCD(GOTO_LINE2_POS0);
		RTC_DisplayDate(date,month,year);
		
        delay_ms(200U);
    }
}

