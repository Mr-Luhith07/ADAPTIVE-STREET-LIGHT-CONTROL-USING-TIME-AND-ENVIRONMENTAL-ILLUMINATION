#ifndef KPM_DEFINES_H
#define KPM_DEFINES_H
#define ROW0 16U       /* P1.16 */
#define ROW1 17U       /* P1.17 */
#define ROW2 18U       /* P1.18 */
#define ROW3 19U       /* P1.19 */
#define COL0 20U       /* P1.20 */
#define COL1 21U       /* P1.21 */
#define COL2 22U       /* P1.22 */
#define COL3 23U       /* P1.23 */
#endif

