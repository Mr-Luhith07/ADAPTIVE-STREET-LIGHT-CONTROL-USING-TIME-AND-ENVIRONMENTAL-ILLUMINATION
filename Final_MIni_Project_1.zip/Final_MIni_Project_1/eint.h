#ifndef EINT_H
#define EINT_H
extern volatile unsigned int menuRequest;
void EINT0_Init(void);
#endif

