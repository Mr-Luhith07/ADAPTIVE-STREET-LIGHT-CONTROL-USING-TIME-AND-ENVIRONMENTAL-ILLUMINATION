#ifndef PROJECT_CONFIG_H
#define PROJECT_CONFIG_H

#define FOSC             12000000U
#define CCLK             (FOSC * 5U)       /* 60 MHz */
#define PCLK             (CCLK / 4U)       /* 15 MHz */

#define PREINT_VAL       ((PCLK / 32768U) - 1U)
#define PREFRAC_VAL      (PCLK - ((PREINT_VAL + 1U) * 32768U))

#define RTC_RST          (1U << 1)
#define RTC_ENB          (1U << 0)

#define LIGHT_PIN        24U               /* P1.24 to P1.27 */
#define LIGHT_MASK       (0x0FU << LIGHT_PIN)

#define ADC_CHANNEL      1U                /* AD0.1 on P0.28 */
#define LDR_DARK_WHEN_HIGH 1U
#define LDR_DARK_THRESHOLD 650U
#define LDR_BRIGHT_THRESHOLD 550U

#define EINT0_CHANNEL    14U               /* VIC channel for EINT0 */

#endif

