#ifndef KPM_H
#define KPM_H
#include "types.h"
void InitKPM(void);
u8 ColScan(void);
u8 RowCheck(void);
u8 ColCheck(void);
u8 KeyScan_NB(void);
u32 ReadNumWithService1(void (*service)(void));
u32 ReadNumWithService(u8 maxDigits,void (*service)(void));

#endif

