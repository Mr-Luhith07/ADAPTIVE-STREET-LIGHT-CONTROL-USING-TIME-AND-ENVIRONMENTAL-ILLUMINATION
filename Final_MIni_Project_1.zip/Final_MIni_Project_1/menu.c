/********************************************************
 MODULE  : MENU2.C
 PROJECT : ADAPTIVE STREET LIGHT CONTROL
 MCU     : LPC2129 / LPC2148

 DESCRIPTION:
 1. EINT0 enters the RTC edit menu.
 2. Keypad digits enter values.
 3. C clears the entered value.
 4. x deletes the last digit.
 5. '=' accepts the entered value.
 6. Fixed digit limits are applied.
 7. BackgroundTasks() maintains streetlight operation.
********************************************************/

#include <LPC21xx.h>

#include "types.h"
#include "rtc.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "kpm.h"
#include "delay.h"
#include "ldr.h"
#include "streetlight.h"
#include "menu.h"


/*======================================================
                  GLOBAL VARIABLES
======================================================*/

static u32 hr, min, sec;


/*======================================================
                  BACKGROUND TASKS
======================================================*/

void BackgroundTasks(void)
{
    RTC_GetTime(&hr, &min, &sec);

    LDR_Read();

    StreetLight_Control(hr, min);
}


/*======================================================
                  READ VALUE FROM KEYPAD

 message   : LCD message
 maxDigits : Maximum allowed digits
======================================================*/

static u32 ReadValue(s8 *message, u8 maxDigits)
{
    CmdLCD(CLEAR_LCD);
    CmdLCD(GOTO_LINE1_POS0);

    StrLCD(message);

    return ReadNumWithService(maxDigits, BackgroundTasks);
}


/*======================================================
             READ AND VALIDATE KEYPAD VALUE
======================================================*/

static u32 ReadValueInRange(s8 *message,
                            u32 min_value,
                            u32 max_value,
                            u8 maxDigits)
{
    u32 value;

    while(1)
    {
        value = ReadValue(message, maxDigits);

        if(value >= min_value && value <= max_value)
        {
            return value;
        }

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("INVALID VALUE");

        delay_ms(700U);
    }
}


/*======================================================
                    EDIT RTC TIME
======================================================*/

static void EditTime(void)
{
    u32 h, m, s, choice;

    RTC_GetTime(&h, &m, &s);

    while(1)
    {
        BackgroundTasks();

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("1.HOUR 2.MINUTE");

        CmdLCD(GOTO_LINE2_POS0);
        StrLCD("3.SECOND 4.EXIT");

        /* Menu selection: only one digit. */

        choice = ReadNumWithService(1U, BackgroundTasks);

        switch(choice)
        {
            case 1:

                h = ReadValueInRange("SET HOUR 0-23",
                                     0U, 23U, 2U);
                break;

            case 2:

                m = ReadValueInRange("SET MIN 0-59",
                                     0U, 59U, 2U);
                break;

            case 3:

                s = ReadValueInRange("SET SEC 0-59",
                                     0U, 59U, 2U);
                break;

            case 4:

                CmdLCD(CLEAR_LCD);
                StrLCD("EXIT T-MENU");

                delay_ms(700U);

                CmdLCD(CLEAR_LCD);
                return;

            default:

                CmdLCD(CLEAR_LCD);
                StrLCD("INVALID OPTION");

                delay_ms(700U);
                continue;
        }

        /* Preserve unmodified RTC values. */

        RTC_SetTime(h, m, s);

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("TIME UPDATED");

        delay_ms(700U);
    }
}


/*======================================================
                    EDIT RTC DATE
======================================================*/

static void EditDate(void)
{
    u32 d, m, y, dow, choice;

    /* Read existing date and day. */

    d   = DOM;
    m   = MONTH;
    y   = YEAR;
    dow = DOW;

    while(1)
    {
        BackgroundTasks();

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("1.Dt 2.MON 3.Yr");

        CmdLCD(GOTO_LINE2_POS0);
        StrLCD("4.DAY 5.EXIT");

        /* Menu selection: one digit. */

        choice = ReadNumWithService(1U, BackgroundTasks);

        switch(choice)
        {
            case 1:

                d = ReadValueInRange("SET DATE 1-31",
                                     1U, 31U, 2U);
                break;

            case 2:

                m = ReadValueInRange("SET MONTH 1-12",
                                     1U, 12U, 2U);
                break;

            case 3:

                y = ReadValueInRange("SET YEAR 1-4095",
                                     1U, 4095U, 4U);
                break;

            case 4:

                dow = ReadValueInRange("DAY 0SUN-6SAT",
                                       0U, 6U, 1U);
                break;

            case 5:

                /* Save only a valid complete date. */

                if(d >= 1U && m >= 1U && m <= 12U &&
                   y >= 1U && y <= 4095U &&
                   d <= RTC_DaysInMonth(m, y) &&
                   dow <= 6U)
                {
                    RTC_SetDate(d, m, y);
                    RTC_SetDay(dow);
                }

                CmdLCD(CLEAR_LCD);
                StrLCD("EXIT D-MENU");

                delay_ms(700U);

                CmdLCD(CLEAR_LCD);
                return;

            default:

                CmdLCD(CLEAR_LCD);
                StrLCD("INVALID OPTION");

                delay_ms(700U);
                continue;
        }

        /* Validate complete date before updating RTC. */

        if(d >= 1U && m >= 1U && m <= 12U &&
           y >= 1U && y <= 4095U &&
           d <= RTC_DaysInMonth(m, y) &&
           dow <= 6U)
        {
            RTC_SetDate(d, m, y);
            RTC_SetDay(dow);

            CmdLCD(CLEAR_LCD);
            StrLCD("DATE UPDATED");
        }
        else
        {
            CmdLCD(CLEAR_LCD);
            StrLCD("INVALID DATE");
        }

        delay_ms(700U);
    }
}


/*======================================================
              EDIT STREETLIGHT BOUNDARIES
======================================================*/

static void EditBoundaries(void)
{
    u32 sh, sm, eh, em, choice;

    /* Read existing boundary values. */

    sh = start_hour;
    sm = start_min;

    eh = end_hour;
    em = end_min;

    while(1)
    {
        BackgroundTasks();

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("1.S-H 2.S-M");

        CmdLCD(GOTO_LINE2_POS0);
        StrLCD("3.E-H 4.E-M 5.Ex");

        /* Boundary menu: one digit only. */

        choice = ReadNumWithService(1U, BackgroundTasks);

        switch(choice)
        {
            case 1:

                sh = ReadValueInRange("ON HOUR 0-23",
                                      0U, 23U, 2U);
                break;

            case 2:

                sm = ReadValueInRange("ON MIN 0-59",
                                      0U, 59U, 2U);
                break;

            case 3:

                eh = ReadValueInRange("OFF HOUR 0-23",
                                      0U, 23U, 2U);
                break;

            case 4:

                em = ReadValueInRange("OFF MIN 0-59",
                                      0U, 59U, 2U);
                break;

            case 5:

                CmdLCD(CLEAR_LCD);
                StrLCD("EXIT B-MENU");

                delay_ms(700U);

                CmdLCD(CLEAR_LCD);
                return;

            default:

                CmdLCD(CLEAR_LCD);
                StrLCD("INVALID OPTION");

                delay_ms(700U);
                continue;
        }

        /* Validate all boundary values. */

        if(sh <= 23U && eh <= 23U &&
           sm <= 59U && em <= 59U &&
           ((sh * 60U + sm) != (eh * 60U + em)))
        {
            start_hour = sh;
            start_min  = sm;

            end_hour = eh;
            end_min  = em;

            CmdLCD(CLEAR_LCD);
            StrLCD("BOUNDARY SAVED");
        }
        else
        {
            CmdLCD(CLEAR_LCD);
            StrLCD("INVALID BOUNDARY");
        }

        delay_ms(700U);
    }
}


/*======================================================
                  MAIN RTC EDIT MENU
======================================================*/

void RTC_Edit_Menu(void)
{
    u32 choice;

    while(1)
    {
        BackgroundTasks();

        CmdLCD(CLEAR_LCD);
        CmdLCD(GOTO_LINE1_POS0);
        StrLCD("1.TIME 2.DATE");

        CmdLCD(GOTO_LINE2_POS0);
        StrLCD("3.BOUND 4.EXIT");

        /* Main menu: maximum one digit. */

        choice = ReadNumWithService(1U, BackgroundTasks);

        switch(choice)
        {
            case 1:

                EditTime();
                break;

            case 2:

                EditDate();
                break;

            case 3:

                EditBoundaries();
                break;

            case 4:

                CmdLCD(CLEAR_LCD);
                StrLCD("EXIT MENU");

                delay_ms(700U);

                CmdLCD(CLEAR_LCD);
                return;

            default:

                CmdLCD(CLEAR_LCD);
                StrLCD("INVALID OPTION");

                delay_ms(700U);
                break;
        }
    }
}

