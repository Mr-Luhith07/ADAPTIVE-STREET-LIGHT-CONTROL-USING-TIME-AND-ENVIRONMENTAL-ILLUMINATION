#ifndef ADC_H
#define ADC_H
#include "types.h"
void Init_ADC(void);
u8 Read_ADC(u8 chNo, u16 *dVal, f32 *eAR);
#endif

