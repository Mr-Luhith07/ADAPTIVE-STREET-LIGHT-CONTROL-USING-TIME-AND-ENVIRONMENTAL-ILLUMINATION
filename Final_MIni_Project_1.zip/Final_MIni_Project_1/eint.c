/* External interrupt 0 driver.
   LPC2148 EINT0 is selected on P0.1 using PINSEL0 bits 2:3.
   Connect the menu push-button circuit to P0.1. */

#include <LPC214x.h>
#include "eint.h"

#define EINT0_VIC_CHANNEL 14U

volatile unsigned int menuRequest = 0U;

void EINT0_ISR(void) __irq
{
    menuRequest = 1U;
    EXTINT = 1U;             /* Clear EINT0 flag */
    VICVectAddr = 0U;        /* End of interrupt */
}

void EINT0_Init(void)
{
    PINSEL0 &= ~(3U << 2);
    PINSEL0 |=  (3U << 2);   /* P0.1 function 11 = EINT0 */

    EXTMODE |= 1U;           /* Edge-sensitive */
    EXTPOLAR &= ~1U;         /* Falling edge */
    EXTINT = 1U;             /* Clear pending EINT0 */

    VICIntSelect &= ~(1U << EINT0_VIC_CHANNEL);
    VICVectAddr0 = (unsigned long)EINT0_ISR;
    VICVectCntl0 = (1U << 5) | EINT0_VIC_CHANNEL;
    VICIntEnable = (1U << EINT0_VIC_CHANNEL);
}

