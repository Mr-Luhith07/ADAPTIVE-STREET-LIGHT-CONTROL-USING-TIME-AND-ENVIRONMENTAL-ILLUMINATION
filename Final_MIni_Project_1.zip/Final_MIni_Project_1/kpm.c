/* 4x4 matrix keypad driver.
   Rows: P1.16-P1.19 (outputs); columns: P1.20-P1.23 (inputs).
   The key map uses digits, C=clear, and '=' as the enter key. */

#include <LPC214x.h>
#include "types.h"
#include "kpm.h"
#include "kpm_defines.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "delay.h"

static const u8 KpmLUT[4][4] =
{
    {'1','2','3','/'},
    {'4','5','6','x'},
    {'7','8','9','-'},
    {'C','0','=','+'}
};

void InitKPM(void)
{
    /* Rows are outputs; columns are inputs. */
    IODIR1 |=  (0x0FU << ROW0);
    IODIR1 &= ~(0x0FU << COL0);
    IOCLR1 = (0x0FU << ROW0);
}

u8 ColScan(void)
{
    u32 mask = (1U << COL0) | (1U << COL1) |
               (1U << COL2) | (1U << COL3);
    return ((IOPIN1 & mask) == mask) ? 1U : 0U;
}

u8 RowCheck(void)
{
    u8 r = 0xFFU;

    IOCLR1 = (1U << ROW0);
    IOSET1 = (1U << ROW1) | (1U << ROW2) |
             (1U << ROW3);

    if(ColScan() == 0U)
        r = 0U;

    else
    {
        IOSET1 = (1U << ROW0);
        IOCLR1 = (1U << ROW1);
        IOSET1 = (1U << ROW2) | (1U << ROW3);

        if(ColScan() == 0U)
            r = 1U;

        else
        {
            IOSET1 = (1U << ROW0) | (1U << ROW1);
            IOCLR1 = (1U << ROW2);
            IOSET1 = (1U << ROW3);

            if(ColScan() == 0U)
                r = 2U;

            else
            {
                IOSET1 = (1U << ROW0) |
                         (1U << ROW1) |
                         (1U << ROW2);

                IOCLR1 = (1U << ROW3);

                if(ColScan() == 0U)
                    r = 3U;
            }
        }
    }

    /* Do not reset rows here.
       ColCheck() must identify the pressed column first. */

    return r;
}


u8 ColCheck(void)
{
    if((IOPIN1 & (1U << COL0)) == 0U) return 0U;
    if((IOPIN1 & (1U << COL1)) == 0U) return 1U;
    if((IOPIN1 & (1U << COL2)) == 0U) return 2U;
    if((IOPIN1 & (1U << COL3)) == 0U) return 3U;
    return 0xFFU;
}

/* READBIT is kept local to this driver to avoid a dependency on defines.h. */

u8 KeyScan_NB(void)
{
    static u8 keyReady = 1U;

    u8 row, col, key;

    if(ColScan() != 0U)
    {
        keyReady = 1U;
        return 0U;
    }

    if(keyReady == 0U)
        return 0U;

    delay_ms(20U);

    if(ColScan() != 0U)
    {
        keyReady = 1U;
        return 0U;
    }

    row = RowCheck();

    if(row > 3U)
    {
        IOCLR1 = (0x0FU << ROW0);
        return 0U;
    }

    col = ColCheck();

    /* Restore the idle row condition. */

    IOCLR1 = (0x0FU << ROW0);

    if(col > 3U)
        return 0U;

    key = KpmLUT[row][col];

    keyReady = 0U;

    return key;
}


/*=====================================================
       READ NUMBER WITH FIXED DIGIT LIMIT

       maxDigits = Maximum number of digits allowed
       service   = Background task function pointer

       C = Clear
       x = Backspace
       = = Accept
=====================================================*/

u32 ReadNumWithService(u8 maxDigits, void (*service)(void))
{
    u32 value = 0U;
    u8 key;
    u8 digitCount = 0U;

    /* Clear only the second LCD line.
       First line contains the message/menu. */

    /*CmdLCD(GOTO_LINE2_POS0);
    StrLCD("                ");
    CmdLCD(GOTO_LINE2_POS0);  */
	CmdLCD(GOTO_LINE1_POS0);

    while(1)
    {
        /* Execute background operations. */

        if(service != 0)
            service();

        key = KeyScan_NB();

        if(key == 0U)
        {
            delay_ms(10U);
            continue;
        }

        /*--------------------------------
                NUMERIC KEY PRESSED
        --------------------------------*/

        if(key >= '0' && key <= '9')
        {
            /* Accept digits only within the limit. */

            if(digitCount < maxDigits)
            {
                value = (value * 10U) +
                        (u32)(key - '0');

                digitCount++;

                /*CmdLCD(GOTO_LINE2_POS0);
                StrLCD("                ");
                CmdLCD(GOTO_LINE2_POS0); */
				CmdLCD(CLEAR_LCD);
                U32LCD(value);
            }
        }

        /*--------------------------------
                    BACKSPACE
        --------------------------------*/

        else if(key == 'x')
        {
            if(digitCount > 0U)
            {
                value = value / 10U;
                digitCount--;

                CmdLCD(GOTO_LINE1_POS0);
                StrLCD("                ");
                CmdLCD(GOTO_LINE1_POS0);
				//StrLCD("     ");
                if(digitCount > 0U)
                    U32LCD(value);
            }
        }

        /*--------------------------------
                     CLEAR
        --------------------------------*/

        else if(key == 'C')
        {
            value = 0U;
            digitCount = 0U;

            CmdLCD(GOTO_LINE1_POS0);
            StrLCD("                ");
            CmdLCD(GOTO_LINE1_POS0);
        }

        /*--------------------------------
                     ACCEPT
        --------------------------------*/

        else if(key == '=')
        {
            return value;
        }
    }
}

