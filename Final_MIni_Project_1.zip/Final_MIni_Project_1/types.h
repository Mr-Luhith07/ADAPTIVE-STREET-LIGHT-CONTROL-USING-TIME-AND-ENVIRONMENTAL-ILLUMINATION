#ifndef TYPES_H
#define TYPES_H
typedef unsigned int u32;
typedef unsigned short int u16;
typedef unsigned char u8;
typedef int s32;
typedef char s8;
typedef float f32;
#endif

