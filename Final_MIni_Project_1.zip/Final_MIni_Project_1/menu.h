#ifndef MENU_H
#define MENU_H
void RTC_Edit_Menu(void);
void BackgroundTasks(void);
#endif

