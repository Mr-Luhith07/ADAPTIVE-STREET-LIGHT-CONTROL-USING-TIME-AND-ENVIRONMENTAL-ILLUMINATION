#ifndef LCD_H
#define LCD_H
#include "types.h"
void WriteLCD(u8 dat);
void CmdLCD(u8 cmd);
void CharLCD(u8 asciiVal);
void InitLCD(void);
void StrLCD(s8 *s);
void U32LCD(u32 n);
void S32LCD(s32 n);
void F32LCD(f32 n, u8 nDP);
void BuildCGRAM(u8 *p, u8 nBytes);
#endif

