#ifndef ADC_DEFINES_H
#define ADC_DEFINES_H
#define ADC_CLK             3000000U
#define ADC_PCLK            15000000U
#define ADC_CLKDIV          ((ADC_PCLK / ADC_CLK) - 1U)
#define ADC_PDN_BIT         21U
#define ADC_START_BIT       24U
#define ADC_DONE_BIT        31U
#define ADC_RESULT_SHIFT    6U
#define ADC_RESULT_MASK     0x3FFU
#define ADC_VREF            3.3F
#define ADC_TIMEOUT         100000U
#endif

