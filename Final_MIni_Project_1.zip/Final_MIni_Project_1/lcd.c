/* 8-bit LCD driver for an HD44780-compatible display.
   Data bus: P0.8-P0.15; RS=P0.4; EN=P0.17; RW=P0.18. */

#include <LPC214x.h>
#include "types.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "delay.h"

void WriteLCD(u8 dat)
{
    /* Clear the LCD data-bus bits, then place the new byte. */
    IOCLR0 = (0xFFU << LCD_DATA);
    IOSET0 = ((u32)dat << LCD_DATA);

    IOCLR0 = (1U << LCD_RW);       /* Write operation */
    IOSET0 = (1U << LCD_EN);       /* Enable pulse */
    delay_us(1U);
    IOCLR0 = (1U << LCD_EN);
    delay_ms(2U);
}

void CmdLCD(u8 cmd)
{
    IOCLR0 = (1U << LCD_RS);       /* Command register */
    WriteLCD(cmd);
}

void CharLCD(u8 asciiVal)
{
    IOSET0 = (1U << LCD_RS);       /* Data register */
    WriteLCD(asciiVal);
}

void InitLCD(void)
{
    IODIR0 |= (0xFFU << LCD_DATA) |
              (1U << LCD_RS) |
              (1U << LCD_RW) |
              (1U << LCD_EN);

    delay_ms(20U);
    CmdLCD(0x30);
    delay_ms(5U);
    CmdLCD(0x30);
    delay_us(150U);
    CmdLCD(0x30);
    CmdLCD(MODE_8BIT_2LINE);
    CmdLCD(DSP_ON_CUR_OFF);
    CmdLCD(CLEAR_LCD);
    CmdLCD(SHIFT_CUR_RIGHT);
}

void StrLCD(s8 *s)
{
    while(*s)
        CharLCD((u8)*s++);
}

void U32LCD(u32 n)
{
    u8 digits[10];
    s32 i = 0;

    if(n == 0U)
    {
        CharLCD('0');
        return;
    }

    while(n > 0U && i < 10)
    {
        digits[i++] = (u8)((n % 10U) + '0');
        n /= 10U;
    }

    while(--i >= 0)
        CharLCD(digits[i]);
}

void S32LCD(s32 n)
{
    if(n < 0)
    {
        CharLCD('-');
        n = -n;
    }
    U32LCD((u32)n);
}

void F32LCD(f32 value, u8 nDP)
{
    u32 whole;
    u8 i;

    if(value < 0.0F)
    {
        CharLCD('-');
        value = -value;
    }

    whole = (u32)value;
    U32LCD(whole);
    CharLCD('.');

    value -= (f32)whole;
    for(i = 0; i < nDP; i++)
    {
        value *= 10.0F;
        whole = (u32)value;
        CharLCD((u8)(whole + '0'));
        value -= (f32)whole;
    }
}

void BuildCGRAM(u8 *p, u8 nBytes)
{
    u8 i;
    CmdLCD(GOTO_CGRAM_START);
    IOSET0 = (1U << LCD_RS);

    for(i = 0; i < nBytes; i++)
        WriteLCD(p[i]);

    CmdLCD(GOTO_LINE1_POS0);
}

