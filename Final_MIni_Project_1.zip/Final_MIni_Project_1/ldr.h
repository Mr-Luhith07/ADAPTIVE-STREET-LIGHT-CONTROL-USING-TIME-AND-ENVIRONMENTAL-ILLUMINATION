#ifndef LDR_H
#define LDR_H
#include "types.h"
extern u16 ldrAdcValue;
extern f32 ldrVoltage;
extern u8 adcValid;
extern u8 ldrDark;
extern u8 ldrInitialized;
void LDR_Init(void);
void LDR_Read(void);
#endif

