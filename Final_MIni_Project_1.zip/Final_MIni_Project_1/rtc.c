/* RTC driver for LPC2148.
   Uses the 32.768 kHz RTC clock and a PCLK of 15 MHz. */

#include <LPC214x.h>
#include "types.h"
#include "project_config.h"
#include "rtc.h"
#include "lcd.h"
#include "lcd_defines.h"

void RTC_Init(void)
{
    //CCR = RTC_RST;
	CCR=1<<4;
    PREINT = PREINT_VAL;
    PREFRAC = PREFRAC_VAL;
    //CCR = RTC_ENB;
	//CCR = 0x11;
	CCR=1<<0 | 1<<4;
	/*if((CCR & 0x01)==0)
	{	CCR=1<<1;
		CCR=1<<0 | 1<<4;
	}
	else
		CCR=1<<4;*/
}

void RTC_SetTime(u32 h, u32 m, u32 s)
{
    HOUR = h;
    MIN = m;
    SEC = s;
}

void RTC_SetDate(u32 d, u32 m, u32 y)
{
    DOM = d;
    MONTH = m;
    YEAR = y;
}

void RTC_SetDay(u32 day)
{
    DOW = day;
}

void RTC_GetTime(u32 *h, u32 *m, u32 *s)
{
    *h = HOUR;
    *m = MIN;
    *s = SEC;
}

void RTC_GetDate(u32 *d, u32 *m, u32 *y)
{
    *d = DOM;
    *m = MONTH;
    *y = YEAR;
}

void RTC_GetDay(u32 *day)
{
    *day = DOW;
}

u8 RTC_IsLeapYear(u32 year)
{
    if((year % 400U) == 0U) return 1U;
    if((year % 100U) == 0U) return 0U;
    if((year % 4U) == 0U) return 1U;
    return 0U;
}

u8 RTC_DaysInMonth(u32 month, u32 year)
{
    switch(month)
    {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31U;
        case 4: case 6: case 9: case 11:
            return 30U;
        case 2:
            return RTC_IsLeapYear(year) ? 29U : 28U;
        default:
            return 0U;
    }
}

void RTC_DisplayTime(u32 h, u32 m, u32 s)
{
    CmdLCD(GOTO_LINE1_POS0);
    CharLCD((u8)((h / 10U) + '0'));
    CharLCD((u8)((h % 10U) + '0'));
    CharLCD(':');
    CharLCD((u8)((m / 10U) + '0'));
    CharLCD((u8)((m % 10U) + '0'));
    CharLCD(':');
    CharLCD((u8)((s / 10U) + '0'));
    CharLCD((u8)((s % 10U) + '0'));
}

void RTC_DisplayDate(u32 d, u32 m, u32 y)
{
    CmdLCD(GOTO_LINE2_POS0);
    CharLCD((u8)((d / 10U) + '0'));
    CharLCD((u8)((d % 10U) + '0'));
    CharLCD('/');
    CharLCD((u8)((m / 10U) + '0'));
    CharLCD((u8)((m % 10U) + '0'));
    CharLCD('/');
    U32LCD(y);
}
void RTC_DisplayDay(u32 day)
{	CmdLCD(GOTO_LINE2_POS0+12);
	
	switch(day)	
	{	case 0:StrLCD("SUN");
				break;
		case 1:StrLCD("MON");
				break;
		case 2:StrLCD("TUE");
				break;
		case 3:StrLCD("WED");
				break;
		case 4:StrLCD("THU");
				break;
		case 5:StrLCD("FRI");
				break;
		case 6:StrLCD("SAT");
				break;
		default:StrLCD("INVALID DAY");
				break;
	}
}
